﻿#Script to download Node.js

# Run as admin
If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator))
{
  # Relaunch as an elevated process:
  Start-Process powershell.exe "-File",('"{0}"' -f $MyInvocation.MyCommand.Path) -Verb RunAs
  exit
}

#install Cosmos DB emulator
$download = "https://aka.ms/cosmosdb-emulator"
$file = "AzureCosmosDB.Emulator.msi"
    
Write-Host "Installing Azure Cosmos DB Emulator"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Invoke-WebRequest $download -Out $file
    
    
Start-Process -FilePath "msiexec" -ArgumentList "/qn /l* cdbe-log.txt /i E:\Resources\$file" -Wait
Remove-Item $file


