﻿# Script to install 7-zip, then download and extract Zookeeper and Kafka

#the versions targetted by this script were the latest stable versions at time of writing

# Run as admin
If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator))
{
  # Relaunch as an elevated process:
  Start-Process powershell.exe "-File",('"{0}"' -f $MyInvocation.MyCommand.Path) -Verb RunAs
  exit
}

#Check for Java
$javaEnvVar = [Environment]::GetEnvironmentVariable("JAVA_HOME")

if (-not $javaEnvVar)
{
    if (-not (Test-Path "C:\Program Files\Java"))
    {
        "Install 64-bit Java before proceeding"
        Read-Host "Press ENTER to close"
        exit
    }

    $jre = Get-ChildItem "C:\Program Files\Java" -filter "jre*"

    if (-not $jre.Name)
    {
        "Error: Could not find JRE in C:\Program Files\Java"
        Read-Host "Press ENTER to close"
        exit
    }
    [Environment]::SetEnvironmentVariable("JAVA_HOME", $jre.FullName, [EnvironmentVariableTarget]::Machine)
}

#Add JAVA_HOME\bin to PATH if it isn't already present
$pathEnvVar = [Environment]::GetEnvironmentVariable("Path")
if (-not $pathEnvVar.Contains("%JAVA_HOME%\bin"))
{
    [Environment]::SetEnvironmentVariable("Path", $env:Path + ";%JAVA_HOME%\bin;", [EnvironmentVariableTarget]::Machine)
}


#install 7-zip if it doesn't already exist
if (-not (Test-Path "C:\Program Files\7-Zip\7z.exe"))
{
    $download = "https://www.7-zip.org/a/7z1805-x64.msi"
    $file = "7z1805-x64.msi"
   
    Write-Host Installing 7-zip
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest $download -Out $file

    #& .\$file /q
    Start-Process -FilePath "msiexec" -ArgumentList "/qn /l* 7zip-log.txt /i E:\Resources\$file" -Wait
    Remove-Item $file
}


#get Zookeeper if it doesn't exist
if (-not (Test-Path "E:\Zookeeper\zookeeper-3.4.12.jar"))
{
    $target = "E:\Zookeeper"
    $download = "https://archive.apache.org/dist/zookeeper/zookeeper-3.4.12/zookeeper-3.4.12.tar.gz"
    $folder = "zookeeper-3.4.12"
    $zip = "$folder.tar.gz"
    $tar = "$folder.tar"

    Write-Host Downloading Zookeeper
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest $download -Out $zip

    # Cleaning up target dir
    Remove-Item $target -Recurse -Force -ErrorAction SilentlyContinue 

    & "c:\Program Files\7-Zip\7z.exe" e $zip
    & "c:\Program Files\7-Zip\7z.exe" x $tar

    Move-Item .\$folder $target

    Remove-Item $zip
    Remove-Item $tar
}

#get Kafka if it doesn't exist
if (-not (Test-Path "E:\Kafka\bin\windows\kafka-server-start.bat"))
{
    $target = "E:\Kafka"
    $download = "http://www-us.apache.org/dist/kafka/2.1.0/kafka_2.11-2.1.0.tgz"
    $folder = "kafka_2.11-2.1.0"
    $zip = "$folder.tgz"
    $tar = "$folder.tar"

    Write-Host Downloading Kafka
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest $download -Out $zip

    # Cleaning up target dir
    Remove-Item $target -Recurse -Force -ErrorAction SilentlyContinue 

    & "c:\Program Files\7-Zip\7z.exe" e $zip
    & "c:\Program Files\7-Zip\7z.exe" x $tar

    Move-Item .\$folder $target

    Remove-Item $zip
    Remove-Item $tar
}

#Set ZOOKEEPER_HOME
[Environment]::SetEnvironmentVariable("ZOOKEEPER_HOME", "E:\Zookeeper", [EnvironmentVariableTarget]::Machine)

#Add ZOOKEEPER_HOME\bin to PATH if it isn't already present
$pathEnvVar = [Environment]::GetEnvironmentVariable("Path")
if (-not $pathEnvVar.Contains("%ZOOKEEPER_HOME%\bin"))
{
    [Environment]::SetEnvironmentVariable("Path", $env:Path + ";%ZOOKEEPER_HOME%\bin;", [EnvironmentVariableTarget]::Machine)
}

