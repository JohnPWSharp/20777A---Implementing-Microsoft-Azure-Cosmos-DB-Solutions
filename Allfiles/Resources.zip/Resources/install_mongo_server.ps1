﻿Write-Host Setting Up MongoDB

$mongoDbPath = "E:\MongoDB" 
$mongoDbConfigPath = "$mongoDbPath\mongod.cfg"
$url = "http://downloads.mongodb.org/win32/mongodb-win32-x86_64-2008plus-ssl-3.6.5.zip" 
$zipFile = "$mongoDbPath\mongo.zip" 
$unzippedFolderContent ="$mongoDbPath\mongodb-win32-x86_64-2008plus-ssl-3.6.5"

if ((Test-Path -path $mongoDbPath) -eq $True) 
{ 
  write-host "Directories already created"
} else {
    md $mongoDbPath 
    md "$mongoDbPath\log" 
    md "$mongoDbPath\data" 
    md "$mongoDbPath\data\db"
}

[System.IO.File]::AppendAllText("$mongoDbConfigPath", "dbpath=E:\MongoDB\data\db`r`n")
[System.IO.File]::AppendAllText("$mongoDbConfigPath", "logpath=E:\MongoDB\log\mongo.log`r`n")
[System.IO.File]::AppendAllText("$mongoDbConfigPath", "smallfiles=true`r`n")

Write-Host Downloading MongoDB

Invoke-WebRequest $url -Out $zipFile -TimeoutSec 60

$shellApp = New-Object -com shell.application 
$destination = $shellApp.namespace($mongoDbPath) 
$destination.Copyhere($shellApp.namespace($zipFile).items())

Copy-Item "$unzippedFolderContent\*" $mongoDbPath -recurse

Remove-Item $unzippedFolderContent -recurse -force 
Remove-Item $zipFile -recurse -force

Write-Host Installing MongoDB

& $mongoDBPath\bin\mongod.exe --config $mongoDbConfigPath --install

& Start-Service mongodb

Write-Host MongoDB Service Started