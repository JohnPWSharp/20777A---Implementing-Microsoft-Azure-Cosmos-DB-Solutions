
$target = "E:\DocumentDBStudio"
$download = "https://github.com/mingaliu/DocumentDBStudio/releases/download/0.72/AzureDocumentDBStudio0.72.zip"
$zip = "AzureDocumentDBStudio0.72.zip"

Write-Host Dowloading latest release
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Invoke-WebRequest $download -Out $zip

# Cleaning up target dir
Remove-Item $target -Recurse -Force -ErrorAction SilentlyContinue 

Expand-Archive -Path $zip -DestinationPath $target

Remove-Item $zip
