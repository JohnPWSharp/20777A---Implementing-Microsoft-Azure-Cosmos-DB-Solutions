﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;

namespace Partitioning
{
    class ClientReader
    {
        private DocumentClient client;
        private string collectionName;
        private Uri temperatureCollection;
        private string deviceKey;
        private int maxDegreesOfParallelism;
        private int clientNum;
        private int numIterations;

        public ClientReader(int clientNum)
        {
            this.clientNum = clientNum;

            // Retrieve the configuration settings
            string endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
            string primaryKey = ConfigurationManager.AppSettings["PrimaryKey"];
            string database = ConfigurationManager.AppSettings["Database"];
            this.collectionName = ConfigurationManager.AppSettings["Collection"];
            this.maxDegreesOfParallelism = int.Parse(ConfigurationManager.AppSettings["MaxDegreeOfParallelism"]);
            this.numIterations = int.Parse(ConfigurationManager.AppSettings["NumIterations"]);

            try
            {
                ConnectionPolicy policy = new ConnectionPolicy
                {
                    ConnectionMode = ConnectionMode.Direct,
                    ConnectionProtocol = Protocol.Tcp,
                    RetryOptions = new RetryOptions
                    {
                        MaxRetryAttemptsOnThrottledRequests = 50,
                        MaxRetryWaitTimeInSeconds = 120
                    }                    
                };

                // Connect to the Cosmos DB database
                this.client = new DocumentClient(new Uri(endpointUrl), primaryKey, policy);

                // Get the collection holding temperature readings
                this.temperatureCollection = UriFactory.CreateDocumentCollectionUri(database, collectionName);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Client {clientNum} connect failed with error: {e.Message}");
            }
        }

        public async Task <(int, double, double)> RunQueriesAsync()
        {
            double executionTime = 0;
            double requestCharge = 0;
            
            var rand = new Random(this.clientNum);  // Setting the seed explicitly ensures repeatability of the test

            try
            {
                for (int i = 0; i < this.numIterations; i++)
                {
                    // Select a device ID at random
                    deviceKey = $"Device {rand.Next(100)}";
                    Console.WriteLine($"Client {clientNum} reading data for {deviceKey}");

                    // Query that retrieves all documents for the specified device
                    string queryString = $"SELECT c.deviceID, c.temperature, c.date FROM {this.collectionName} c WHERE c.deviceID = @devID";
                    SqlParameterCollection parameters = new SqlParameterCollection()
                    {
                        new SqlParameter("@devID", deviceKey)
                    };

                    SqlQuerySpec querySpec = new SqlQuerySpec()
                    {
                        QueryText = queryString,
                        Parameters = parameters
                    };

                    // Capture the internal query metrics
                    FeedOptions options = new FeedOptions();
                    options.PopulateQueryMetrics = true;
                    options.MaxItemCount = -1;
                    
                    // TODO: Only select the PartitionKey property for appropriately partitioned collections
                    //options.PartitionKey = new PartitionKey(deviceKey);

                    // TODO: Enable cross-partition queries if the partition key does not match the predicate
                    options.EnableCrossPartitionQuery = true;

                    // TODO: MaxDegreeOfParallelism is only useful for cross-partition queries
                    options.MaxDegreeOfParallelism = this.maxDegreesOfParallelism;

                    // Run the query that fetches temperature documents and capture the metrics
                    var query = this.client.CreateDocumentQuery(temperatureCollection, querySpec, options).AsDocumentQuery();
                    while (query.HasMoreResults)
                    {
                        var queryResponse = await query.ExecuteNextAsync();
                        requestCharge += queryResponse.RequestCharge;
                        if (queryResponse.QueryMetrics.Count() > 0)
                        {
                            var queryMetrics = queryResponse.QueryMetrics.First().Value;
                            executionTime += queryMetrics.TotalTime.TotalMilliseconds;
                        }
                        foreach (var queryDoc in queryResponse)
                        {
                            //var values = JsonConvert.DeserializeObject(queryDoc.ToString());
                        }
                    }

                    // Queries that performs aggregate calculations over documents for the specified device
                    string maxQueryString = $"SELECT VALUE max(c.temperature) FROM {this.collectionName} c WHERE c.deviceID = @devID";
                    string minQueryString = $"SELECT VALUE min(c.temperature) FROM {this.collectionName} c WHERE c.deviceID = @devID";
                    string avgQueryString = $"SELECT VALUE avg(c.temperature) FROM {this.collectionName} c WHERE c.deviceID = @devID";
                    string countQueryString = $"SELECT VALUE count(1) FROM {this.collectionName} c WHERE c.deviceID = @devID";

                    SqlQuerySpec maxQuerySpec = new SqlQuerySpec()
                    {
                        QueryText = maxQueryString,
                        Parameters = parameters
                    };

                    SqlQuerySpec minQuerySpec = new SqlQuerySpec()
                    {
                        QueryText = minQueryString,
                        Parameters = parameters
                    };

                    SqlQuerySpec avgQuerySpec = new SqlQuerySpec()
                    {
                        QueryText = avgQueryString,
                        Parameters = parameters
                    };

                    SqlQuerySpec countQuerySpec = new SqlQuerySpec()
                    {
                        QueryText = countQueryString,
                        Parameters = parameters
                    };

                    // Run these queries and capture the metrics
                    var maxQuery = this.client.CreateDocumentQuery(temperatureCollection, maxQuerySpec, options).AsDocumentQuery();
                    var statsResponse = await maxQuery.ExecuteNextAsync();
                    requestCharge += statsResponse.RequestCharge;
                    executionTime += statsResponse.QueryMetrics.FirstOrDefault().Value.TotalTime.TotalMilliseconds;
                    var statsValues = JsonConvert.DeserializeObject<double>(statsResponse.FirstOrDefault().ToString());

                    var minQuery = this.client.CreateDocumentQuery(temperatureCollection, minQuerySpec, options).AsDocumentQuery();
                    statsResponse = await minQuery.ExecuteNextAsync();
                    requestCharge += statsResponse.RequestCharge;
                    executionTime += statsResponse.QueryMetrics.FirstOrDefault().Value.TotalTime.TotalMilliseconds;
                    statsValues = JsonConvert.DeserializeObject<double>(statsResponse.FirstOrDefault().ToString());

                    var avgQuery = this.client.CreateDocumentQuery(temperatureCollection, avgQuerySpec, options).AsDocumentQuery();
                    statsResponse = await avgQuery.ExecuteNextAsync();
                    requestCharge += statsResponse.RequestCharge;
                    executionTime += statsResponse.QueryMetrics.FirstOrDefault().Value.TotalTime.TotalMilliseconds;
                    statsValues = JsonConvert.DeserializeObject<double>(statsResponse.FirstOrDefault().ToString());

                    var countQuery = this.client.CreateDocumentQuery(temperatureCollection, countQuerySpec, options).AsDocumentQuery();
                    statsResponse = await countQuery.ExecuteNextAsync();
                    requestCharge += statsResponse.RequestCharge;
                    executionTime += statsResponse.QueryMetrics.FirstOrDefault().Value.TotalTime.TotalMilliseconds;
                    statsValues = JsonConvert.DeserializeObject<double>(statsResponse.FirstOrDefault().ToString());
                }

                // Return the execution stats
                return (this.clientNum, executionTime, requestCharge);
            }
            catch (Exception e)
            {
                Console.WriteLine($"{e}");
                Console.WriteLine($"Client {clientNum} query failed with error: {e.Message}");
                return (this.clientNum, 0, 0);
            }
        }
    }
}
