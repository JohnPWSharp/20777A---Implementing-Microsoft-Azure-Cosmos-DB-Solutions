﻿using System;
using System.Configuration;
using System.Diagnostics;
using System.Threading.Tasks;

namespace Partitioning
{
    class Program
    {
        static async Task Main(string[] args)
        {
            int numClients = int.Parse(ConfigurationManager.AppSettings["NumClients"]);

            try
            {
                // Start clients
                var driver = new ClientDriver(numClients);

                Stopwatch timer = new Stopwatch();
                timer.Start();
                var results = driver.Run();
                timer.Stop();

                // Aggregate and report the results
                double executionTime = 0;
                double requestCharge = 0;
                
                foreach (var result in results)
                {
                    executionTime += result.Value.Item1;
                    requestCharge += result.Value.Item2;
                }

                Console.WriteLine($"Processing throughput: {requestCharge / (executionTime / 1000)} RU/s");
                Console.WriteLine($"Elapsed time: {timer.ElapsedMilliseconds} ms");
                Console.WriteLine("Press any key to finish ...");
                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine($"Application failed with error: {e.Message}");
            }
        }
    }
}
