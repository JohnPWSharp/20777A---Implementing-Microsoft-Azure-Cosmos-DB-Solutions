﻿using Newtonsoft.Json;

namespace MigrateProductData
{
    // TODO: Specify fields for the ProductCategoryData subdocument
    internal class ProductCategoryData
    {

    }

    // TODO: Specify fields for the ProductDocumentData subdocument
    internal class ProductDocumentData
    {

    }

    // TODO: Specify fields for the ProductImageData subdocument
    internal class ProductImageData
    {

    }

    // TODO: Specify fields for the Product document
    internal class Product
    {
        
    }
}
