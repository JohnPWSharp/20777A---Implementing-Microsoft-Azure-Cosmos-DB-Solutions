﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Adventure_Works.Models
{
    public class ProductCategoryViewModel
    {
        public string CategoryName { get; set; }
        public IEnumerable<SelectListItem> Categories { get; set; }
    }

    public class ProductSubcategoryViewModel
    {
        public string SubcategoryName { get; set; }
        public IEnumerable<SelectListItem> Subcategories { get; set; }
    }

    public class ProductViewModel
    {
        public string SearchString { get; set; }
        public IEnumerable<Product> Products { get; set; }
        public ProductCategoryViewModel SelectableCategories { get; set; }
        public ProductSubcategoryViewModel SelectableSubcategories { get; set; }
    }
}