﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using System.Configuration;
using System.Linq.Expressions;
using System.Threading.Tasks;


namespace Adventure_Works
{
    public static class ProductsRepository<T>
    {
        private static string endpointUrl;
        private static string primaryKey;
        private static string database;
        private static string collection;
        private static DocumentClient client;

        public static void Initialize(string coll)
        {
            endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
            primaryKey = ConfigurationManager.AppSettings["PrimaryKey"];
            database = ConfigurationManager.AppSettings["Database"];
            collection = coll;
            client = new DocumentClient(new Uri(endpointUrl), primaryKey);
        }

        public static async Task<IEnumerable<T>> GetAllItemsAsync()
        {
            // Find all documents in the collection
            IDocumentQuery<T> query = client.CreateDocumentQuery<T>(
                UriFactory.CreateDocumentCollectionUri(database, collection))
                .AsDocumentQuery();

            // Return the documents as a list
            List<T> results = new List<T>();
            while (query.HasMoreResults)
            {
                results.AddRange(await query.ExecuteNextAsync<T>());
            }

            return results;
        }

        public static async Task<IEnumerable<T>> GetItemsAsync(Expression<Func<T, bool>> predicate)
        {
            // Find all documents in the collection that match the predicate
            IDocumentQuery<T> query = client.CreateDocumentQuery<T>(
                UriFactory.CreateDocumentCollectionUri(database, collection),
                new FeedOptions { EnableCrossPartitionQuery = true })
                .Where(predicate)
                .AsDocumentQuery();

            // Return the matching documents as a list
            List<T> results = new List<T>();
            while (query.HasMoreResults)
            {
                results.AddRange(await query.ExecuteNextAsync<T>());
            }

            return results;
        }
    }
}