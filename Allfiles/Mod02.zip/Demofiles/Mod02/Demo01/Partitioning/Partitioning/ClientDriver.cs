﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Partitioning
{
    class ClientDriver
    {
        private int numClients;
        private Task<(int, double, double)> [] clients;

        public ClientDriver(int numClients)
        {
            this.numClients = numClients;
            this.clients = new Task<(int, double, double)>[numClients];
        }

        public Dictionary<int, (double, double)> Run()
        {
            var results = new Dictionary<int, (double, double)>(numClients);

            for (int clientNum = 0; clientNum < this.numClients; clientNum++)
            {
                var clientReader = new ClientReader(clientNum);
                var statsTask = clientReader.RunQueriesAsync();
                clients[clientNum] = statsTask;
            }

            Task<string>.WaitAll(clients);
            foreach (var client in clients)
            {
                results[client.Result.Item1] = (client.Result.Item2, client.Result.Item3);
            }
            return results;
        }
    }
}
