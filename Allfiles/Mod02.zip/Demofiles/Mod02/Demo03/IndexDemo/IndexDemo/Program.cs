﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexDemo
{
    class Program
    {
        private static DocumentClient client;
        private static string endpointUrl;
        private static string primaryKey;
        private static string database;
        private static string collection;

        static void Main(string[] args)
        {
            try
            {
                // Retrieve the configuration settings
                endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
                primaryKey = ConfigurationManager.AppSettings["PrimaryKey"];
                database = ConfigurationManager.AppSettings["Database"];
                collection = ConfigurationManager.AppSettings["Collection"];

                // Connect to the Cosmos DB database
                client = new DocumentClient(new Uri(endpointUrl), primaryKey);

                Uri temperatureCollection = UriFactory.CreateDocumentCollectionUri(database, collection);

                // Query that retrieves all documents for the specified device
                Console.WriteLine("Enter a device ID");
                string deviceID = Console.ReadLine();
                string queryString = $"SELECT c.deviceID, c.temperature, c.time FROM {collection} c WHERE c.deviceID = @devID";
                SqlParameterCollection parameters = new SqlParameterCollection()
                {
                    new SqlParameter("@devID", deviceID)
                };

                SqlQuerySpec querySpec = new SqlQuerySpec()
                {
                    QueryText = queryString,
                    Parameters = parameters
                };

                FeedOptions options = new FeedOptions();
                // TODO: Uncomment the following statement to enable scanning
                // options.EnableScanInQuery = true;
                options.PopulateQueryMetrics = true;
                var query = client.CreateDocumentQuery<ThermometerReading>(temperatureCollection, querySpec, options).AsDocumentQuery();

                // Display the results and examine the query execution stats
                double requestCharge = 0;
                double indexLookupTime = 0;
                double indexHitRatio = 0;
                double documentLoadTime = 0;
                double runtimeExecutionTimes = 0;

                while (query.HasMoreResults)
                {
                    var queryResponse = (query.ExecuteNextAsync()).Result;
                    requestCharge += queryResponse.RequestCharge;
                    if (queryResponse.QueryMetrics.Count() > 0)
                    {
                        var queryMetrics = queryResponse.QueryMetrics.First().Value;
                        indexLookupTime += queryMetrics.QueryEngineTimes.IndexLookupTime.TotalMilliseconds;
                        indexHitRatio = queryMetrics.IndexHitRatio;
                        documentLoadTime += queryMetrics.QueryEngineTimes.DocumentLoadTime.TotalMilliseconds;
                        runtimeExecutionTimes += queryMetrics.QueryEngineTimes.RuntimeExecutionTimes.TotalTime.TotalMilliseconds;
                    }
                    foreach (var queryDoc in queryResponse)
                    {
                        var values = JsonConvert.DeserializeObject<Dictionary<string, string>>(queryDoc.ToString());
                        foreach (var item in values)
                        {
                            Console.WriteLine($"{item.Key}: {item.Value}");
                        }
                        Console.WriteLine();
                    }
                }

                Console.WriteLine($"\n Request charge: {requestCharge} RUs\n Index LookUp Time: {indexLookupTime} ms\n Index Hit Ratio: {indexHitRatio * 100}%\n Document Load Time: {documentLoadTime} ms\n Runtime Execution Time: {runtimeExecutionTimes} ms");
            }
            catch (DocumentClientException dce)
            {
                Console.WriteLine(dce.Message);
            }
            catch (AggregateException e)
            {
                foreach (var i in e.Flatten().InnerExceptions)
                {
                    Console.WriteLine($"{i.Message}");
                }
            }

            Console.WriteLine("\n\nPress any key to finish ...");
            Console.ReadKey();
        }
    }
}
