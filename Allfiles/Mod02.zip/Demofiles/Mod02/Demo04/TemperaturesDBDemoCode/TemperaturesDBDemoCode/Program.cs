﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace TemperaturesDBDemoCode
{
    class Program
    {
        static void Main(string[] args)
        {
            Worker worker = new Worker();
            worker.DoWork().Wait();
        }
    }

    class Worker
    {
        private DocumentClient client;
        private string endpointUrl;
        private string primaryKey;
        private string database;
        private string collection;

        public async Task DoWork()
        {
            // Retrieve the configuration settings
            this.endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
            this.primaryKey = ConfigurationManager.AppSettings["PrimaryKey"];
            this.database = ConfigurationManager.AppSettings["Database"];
            this.collection = ConfigurationManager.AppSettings["Collection"];

            // Connect to the Cosmos DB database
            this.client = new DocumentClient(new Uri(endpointUrl), primaryKey);

            char action = ' ';
            while (action != 'X')
            {
                try
                {
                    action = displayMenu();
                    Console.WriteLine();
                    switch (action)
                    {
                        case 'A':
                            // Find a specified temperature document
                            await FindTemperatureDocumentByID();
                            break;

                        case 'B':
                            // Find a temperature document using the untyped methods
                            await FindUntypedTemperatureDocumentByID();
                            break;

                        case 'C':
                            // Create a new document
                            await CreateTemperatureDocument();
                            break;

                        case 'D':
                            // Delete a specified document
                            await DeleteTemperatureDocument();
                            break;

                        case 'E':
                            // Update a specified document
                            await UpdateTemperatureDocument();
                            break;

                        case 'F':
                            // Generate an update conflict
                            await UpdateTemperatureDocumentWithConflict();
                            break;

                        case 'G':
                            // Create a document with an attachment
                            await CreateDocWithAttachment();
                            break;

                        case 'H':
                            // Retrieve a document with an attachment
                            await RetrieveDocWithAttachments();
                            break;

                        default:
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"{ex.Message}");
                }
            }            
        }

        private char displayMenu()
        {
            Console.WriteLine("Actions");
            Console.WriteLine("=======");
            Console.WriteLine("A: Find Temperature Document by ID using Typed Methods");
            Console.WriteLine("B: Find Temperature Document by ID using Untyped Methods");
            Console.WriteLine("C: Create a New Temperature Document");
            Console.WriteLine("D: Delete a Temperature Document");
            Console.WriteLine("E: Modify (Replace) a Temperature Document");
            Console.WriteLine("F: Generate an Update Conflict");
            Console.WriteLine("G: Create a Document with an Attachment");
            Console.WriteLine("H: Retrieve a Document with an Attachment");
            Console.WriteLine("X: Exit");

            return Char.ToUpper(Console.ReadKey().KeyChar);
        }

        private async Task FindTemperatureDocumentByID()
        {
            Console.WriteLine("Enter document ID");
            string id = Console.ReadLine();
            Uri docUri = UriFactory.CreateDocumentUri(this.database, this.collection, id);

            var documentResponse = await client.ReadDocumentAsync<ThermometerReading>(docUri, new RequestOptions()
            {
                PartitionKey = new PartitionKey(id)
            });

            // The Document property of the response contains a typed document
            Console.WriteLine(documentResponse.Document);
            Console.WriteLine();
        }

        private async Task FindUntypedTemperatureDocumentByID()
        {
            Console.WriteLine("Enter document ID");
            string id = Console.ReadLine();
            Uri docUri = UriFactory.CreateDocumentUri(this.database, this.collection, id);

            // The Document property of the response contains a JSON document
            var documentResponse = await client.ReadDocumentAsync(docUri, new RequestOptions()
            {
                PartitionKey = new PartitionKey(id)
            });

            Console.WriteLine(documentResponse.Resource);
            Console.WriteLine();

            // Parse the JSON document into a Dictionary
            var values = JsonConvert.DeserializeObject<Dictionary<string, string>>(documentResponse.Resource.ToString());
            foreach (var item in values)
            {
                Console.WriteLine($"{item.Key}: {item.Value}");
            }
        }

        private async Task CreateTemperatureDocument()
        {
            Console.Write("Enter a device ID: ");
            string deviceName = Console.ReadLine();


            // Create a temperature reading
            ThermometerReading reading = new ThermometerReading
            {
                DeviceID = deviceName,
                Temperature = new Random().NextDouble() * 100,
                Time = DateTime.UtcNow.Ticks
            };

            // Write the reading to the database
            Uri collectionUri = UriFactory.CreateDocumentCollectionUri(this.database, this.collection);
            var response = await this.client.CreateDocumentAsync(collectionUri, reading);
            Console.WriteLine($"Document created. Status code is {response.StatusCode}");
            Console.WriteLine($"ID is {response.Resource.Id}");
        }

        private async Task DeleteTemperatureDocument()
        {
            // Specify the document to be deleted
            Console.WriteLine("Enter document ID");
            string id = Console.ReadLine();
            Uri docUri = UriFactory.CreateDocumentUri(this.database, this.collection, id);

            // Delete the document
            var response = await this.client.DeleteDocumentAsync(docUri, new RequestOptions()
            {
                PartitionKey = new PartitionKey(id)
            });

            Console.WriteLine($"Document deleted. Status code is {response.StatusCode}");
        }

        private async Task UpdateTemperatureDocument()
        {
            // Fetch the doc to be updated
            Document doc = await GetDocument();

            // Change the value of a field in the document
            double temperature = doc.GetPropertyValue<double>("temperature");
            doc.SetPropertyValue("temperature", temperature + 1000);

            // Save the doc
            await SaveDocument(doc);
        }

        private async Task UpdateTemperatureDocumentWithConflict()
        {
            // Fetch the doc to be updated
            Document doc = await GetDocument();

            double temperature = doc.GetPropertyValue<double>("temperature");

            // Run two tasks that change the value of a field in the document and attemptp to save it
            Task t1 = new Task(async () =>
            {
                doc.SetPropertyValue("temperature", temperature + 1000);

                    // Save the doc
                    await SaveDocument(doc);
            });

            Task t2 = new Task(async () =>
            {
                doc.SetPropertyValue("temperature", temperature - 500);

                    // Save the doc
                    await SaveDocument(doc);
            });

            t1.Start();
            t2.Start();

            Task.WaitAll(t1, t2);
        }

        private async Task<Document> GetDocument()
        {
            // Fetch the document to be updated
            Console.WriteLine("Enter document ID");
            string id = Console.ReadLine();
            Uri docUri = UriFactory.CreateDocumentUri(this.database, this.collection, id);

            var documentResponse = await client.ReadDocumentAsync(docUri, new RequestOptions()
            {
                PartitionKey = new PartitionKey(id)
            });

            // Display the document just retrieved
            var doc = documentResponse.Resource;
            Console.WriteLine(doc.ToString());
            return doc;
        }

        private async Task SaveDocument(Document doc)
        {
            try
            {

                // Replace the document in the database with the updated doc
                RequestOptions options = new RequestOptions
                {
                    AccessCondition = new AccessCondition
                    {
                        Condition = doc.ETag,
                        Type = AccessConditionType.IfMatch
                    }
                };

                var response = await client.ReplaceDocumentAsync(doc.SelfLink, doc, options);
                Console.WriteLine($"Document replaced. Status code is {response.StatusCode}");
            }
            catch (DocumentClientException dce)
            {
                // If a conflict occured, display a message
                if (dce.StatusCode == HttpStatusCode.PreconditionFailed)
                {
                    Console.WriteLine("Update failed - another user already changed this document. Requery and try again");
                }
            }
        }
        
        private async Task CreateDocWithAttachment()
        {
            // Create a generic JSON document
            JObject doc = new JObject();
            doc.Add("Name", "Employee 1");
            doc.Add("Department", "Engineering");

            // Write the document to the database
            Uri collectionUri = UriFactory.CreateDocumentCollectionUri(this.database, this.collection);
            var response = await this.client.CreateDocumentAsync(collectionUri, doc);
            Console.WriteLine($"Document created. Status code is {response.StatusCode}");
            Console.WriteLine($"ID is {response.Resource.Id}");

            string data = "This is the attached data - pretend it is a large binary image!";
            byte[] byteArray = Encoding.ASCII.GetBytes(data);
            MemoryStream stream = new MemoryStream(byteArray);

            // Create the attachment
            var attachmentResponse = await client.CreateAttachmentAsync(response.Resource.AttachmentsLink, stream,
                new MediaOptions
                {
                    ContentType = "application/text",
                    Slug = Guid.NewGuid().ToString()
                }, 
                new RequestOptions()
                {
                    PartitionKey = new PartitionKey(response.Resource.Id)
                });

            Console.WriteLine($"Attachment created. Status code is {attachmentResponse.StatusCode}");
            Console.WriteLine($"Attachment ID is {attachmentResponse.Resource.Id}");
        }

        private async Task RetrieveDocWithAttachments()
        {
            var doc = await GetDocument();

            foreach (var attachment in client.CreateAttachmentQuery(doc.SelfLink, new FeedOptions()
            {
                PartitionKey = new PartitionKey(doc.Id)
            }))
            {
                var data = await client.ReadMediaAsync(attachment.MediaLink);
                StreamReader reader = new StreamReader(data.Media);
                string text = reader.ReadToEnd();
                Console.WriteLine($"Attachment is: {text}");
            }            
        }
    }
}
