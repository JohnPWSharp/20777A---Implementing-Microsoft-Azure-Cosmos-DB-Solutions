﻿using Newtonsoft.Json;
using System;

namespace TemperaturesDBDemoCode
{
    // Document structure for capturing and storing temperature readings
    public class ThermometerReading
    {
        [JsonProperty("id")]
        public string ID { get; set; }

        [JsonProperty("deviceID")]
        public string DeviceID { get; set; }

        [JsonProperty("temperature")]
        public double Temperature { get; set; }

        [JsonProperty("time")]
        public long Time { get; set; }

        public override string ToString()
        {
            return $"DeviceID: {DeviceID}, Temperature: {Temperature}, Time: {Time}";
        }
    }
}
