﻿using System;

namespace TableStorageOffencesLib
{
    // Functions to convert between the logical criminal records type exposed to applications and the model held in table storage
    internal static class CriminalRecordMapper
    {
        public static CriminalRecord Map(TableStorageCriminalRecord criminalRecord)
        {
            if (criminalRecord == null)
            {
                return null;
            }

            var result = new CriminalRecord(Int32.Parse(criminalRecord.RowKey))
            {
                FirstName = criminalRecord.FirstName,
                Lastname = criminalRecord.Lastname,
                Alias = criminalRecord.Alias,
                Offence = criminalRecord.Offence
            };

            return result;
        }

        public static TableStorageCriminalRecord Map(CriminalRecord criminalRecord)
        {
            if (criminalRecord == null)
            {
                return null;
            }

            var result = new TableStorageCriminalRecord(criminalRecord.CriminalRecordID)
            {
                FirstName = criminalRecord.FirstName,
                Lastname = criminalRecord.Lastname,
                Alias = criminalRecord.Alias,
                Offence = criminalRecord.Offence
            };

            return result;
        }
    }
}
