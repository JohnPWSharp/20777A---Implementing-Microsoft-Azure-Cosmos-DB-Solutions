﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace TableStorageOffencesLib
{
    // Define the operations that applications perform on criminal records
    public interface ICriminalRecordOperations
    {
        CriminalRecord GetCriminalRecord(int ID);
        CriminalRecord SaveCriminalRecord(CriminalRecord criminalRecord);
        void DeleteCriminalRecord(int ID);
    }

    public class CriminalRecordRepository : ICriminalRecordOperations
    {
        public CriminalRecord GetCriminalRecord(int ID)
        {
            try
            {
                var storedCriminalRecord = new CriminalRecordContext().Get(ID.ToString());
                return storedCriminalRecord != null ? CriminalRecordMapper.Map(storedCriminalRecord) : new CriminalRecord(ID);
            }
            catch (Exception e)
            {
                throw new CriminalRecordRepositoryException(
                    string.Format(CultureInfo.CurrentCulture, Strings.ErrorRetrievingCriminalRecordByID, ID), e);
            }
        }

        public CriminalRecord SaveCriminalRecord(CriminalRecord criminalRecord)
        {
            if (criminalRecord == null)
            {
                throw new ArgumentNullException(string.Format(CultureInfo.CurrentCulture, Strings.ErrorNullCriminalRecord));
            }

            try
            {
                new CriminalRecordContext().Save(CriminalRecordMapper.Map(criminalRecord));
                return criminalRecord;
            }
            catch (Exception e)
            {
                throw new CriminalRecordRepositoryException(
                    string.Format(CultureInfo.CurrentCulture, Strings.ErrorSavingCriminalRecord, criminalRecord.CriminalRecordID, criminalRecord.Offence), e);
            }
        }

        public void DeleteCriminalRecord(int ID)
        {
            try
            {
                var context = new CriminalRecordContext();
                var shoppingCart = context.Get(ID.ToString());
                if (shoppingCart != null)
                {
                    context.Delete(shoppingCart);
                }
            }
            catch (Exception e)
            {
                throw new CriminalRecordRepositoryException(
                    string.Format(CultureInfo.CurrentCulture, Strings.ErrorDeletingCriminalRecord, ID), e);
            }
        }
    }

    // Custom exception class for handling criminal record repository exceptions
    [Serializable]
    public class CriminalRecordRepositoryException : Exception
    {
        public CriminalRecordRepositoryException()
            : base()
        {
        }

        public CriminalRecordRepositoryException(string message)
            : base(message)
        {
        }

        public CriminalRecordRepositoryException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        protected CriminalRecordRepositoryException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }

    // Functions that read and write criminal record entities to and from table storage
    public sealed class CriminalRecordContext
    {
        private const string TableName = "CriminalRecords";
        private CloudTableClient tableClient;

        public CriminalRecordContext()
        {
            string connectionString = ConfigurationManager.AppSettings["StorageConnectionString"];

            try
            {
                this.tableClient = CloudStorageAccount.Parse(connectionString).CreateCloudTableClient();
            }
            catch
            {
                this.tableClient = null;
            }
        }

        public TableStorageCriminalRecord Get(string ID)
        {
            var table = this.tableClient.GetTableReference(TableName);
            var partitionKey = TableStorageCriminalRecord.FindPartitionKey(ID);
            TableOperation retrieveOperation = TableOperation.Retrieve<TableStorageCriminalRecord>(partitionKey, ID);
            try
            {
                TableResult retrievedResult = table.Execute(retrieveOperation);
                return (TableStorageCriminalRecord)retrievedResult.Result;
            }
            catch (System.Exception)
            {
                return null;
            }
        }

        public void Save(TableStorageCriminalRecord criminalRecord)
        {
            var table = this.tableClient.GetTableReference(TableName);
            TableOperation insertOrReplaceOperation = TableOperation.InsertOrReplace(criminalRecord);
            table.Execute(insertOrReplaceOperation);
        }

        public void Delete(TableStorageCriminalRecord criminalRecord)
        {
            var table = this.tableClient.GetTableReference(TableName);
            TableOperation deleteOperation = TableOperation.Delete(criminalRecord);
            table.Execute(deleteOperation);
        }
    }
}
