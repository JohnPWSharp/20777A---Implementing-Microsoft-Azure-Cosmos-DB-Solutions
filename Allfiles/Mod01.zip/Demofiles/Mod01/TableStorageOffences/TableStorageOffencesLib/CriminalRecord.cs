﻿using System;
using System.ComponentModel.DataAnnotations;

namespace TableStorageOffencesLib
{
    // Class used by applications to capture and display criminal offence information
    public sealed class CriminalRecord
    {
        // Data for each recorded offence
        [Required, Range(0, Int32.MaxValue)]
        public int CriminalRecordID { get; set; }

        [Required]
        public string FirstName { get; set; }

        [Required]
        public string Lastname { get; set; }

        [Required]
        public string Alias { get; set; }

        [Required]
        public string Offence { get; set; }

        public CriminalRecord(int ID) => this.CriminalRecordID = ID;
    }
}
