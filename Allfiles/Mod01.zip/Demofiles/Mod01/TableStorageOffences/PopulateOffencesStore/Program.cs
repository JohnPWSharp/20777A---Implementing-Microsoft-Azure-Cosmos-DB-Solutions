﻿using Newtonsoft.Json;
using System;
using System.IO;
using TableStorageOffencesLib;

namespace PopulateOffencesStore
{
    class Program
    {
        const string DATAFILE = @"offencesdata.json";
        static void Main(string[] args)
        {
            string line;

            if (File.Exists(DATAFILE))
            {
                StreamReader file = null;
                CriminalRecordRepository criminalRecordRepository = new CriminalRecordRepository();

                try
                {
                    int ID = 0;
                    file = new StreamReader(DATAFILE);
                    while ((line = file.ReadLine()) != null)
                    {
                        Console.WriteLine($"Read: {line}");
                        JSONCriminalRecord jsonCriminalRecord = JsonConvert.DeserializeObject<JSONCriminalRecord>(line);
                        CriminalRecord criminalRecord = new CriminalRecord(ID++)
                        {
                            FirstName = jsonCriminalRecord.FirstName,
                            Lastname = jsonCriminalRecord.Lastname,
                            Alias = jsonCriminalRecord.Alias,
                            Offence = jsonCriminalRecord.Offence
                        };
                        criminalRecordRepository.SaveCriminalRecord(criminalRecord);
                        Console.WriteLine($"Saved: {criminalRecord.CriminalRecordID}");
                    }
                }
                finally
                {
                    if (file != null)
                        file.Close();
                    Console.WriteLine("Press Enter to end program.");
                    Console.ReadKey();
                }
            }
        }
    }

    // Class for holding deserialized data read from the JSON file
    public sealed class JSONCriminalRecord
    {
        public string FirstName { get; set; }
        public string Lastname { get; set; }
        public string Alias { get; set; }
        public string Offence { get; set; }
    }
}
