﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using System;
using System.Configuration;
using System.Threading.Tasks;

namespace TemperaturesDBDemoCode
{
    class Program
    {
        static void Main(string[] args)
        {
            Worker worker = new Worker();
            worker.DoWork().Wait();
        }
    }

    class Worker
    {
        private DocumentClient client;
        private string endpointUrl;
        private string primaryKey;
        private string database;
        private string collection;

        public async Task DoWork()
        {
            // Retrieve the configuration settings
            this.endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
            this.primaryKey = ConfigurationManager.AppSettings["PrimaryKey"];
            this.database = ConfigurationManager.AppSettings["Database"];
            this.collection = ConfigurationManager.AppSettings["Collection"];

            // Connect to the Cosmos DB account
            this.client = new DocumentClient(new Uri(endpointUrl), primaryKey);

            try
            {
                // Fetch a document by using its unique ID and partition key with ReadDocumentAsync (fastest way to retrieve a document) 
                Console.WriteLine("Enter document ID");
                string id = Console.ReadLine();
                Uri docUri = UriFactory.CreateDocumentUri(this.database, this.collection, id);

                Console.WriteLine("Enter partition key (device ID)");
                string deviceID = Console.ReadLine();

                var documentResponse = await client.ReadDocumentAsync<ThermometerReading>(docUri);

                // The Document property of the response contains a typed document
                Console.WriteLine(documentResponse.Document);
                Console.WriteLine();

                // Fetch a set of documents by performing a SQL query. This query uses the index over the deviceID field
                Console.WriteLine("Enter device ID");
                deviceID = Console.ReadLine();
                string queryString = $"SELECT c.deviceID, c.temperature, c.time FROM {this.collection} c WHERE c.deviceID = @devID";
                SqlParameterCollection parameters = new SqlParameterCollection()
                {
                    new SqlParameter("@devID", deviceID)
                };

                SqlQuerySpec querySpec = new SqlQuerySpec()
                {
                    QueryText = queryString,
                    Parameters = parameters
                };

                Uri collectionUri = UriFactory.CreateDocumentCollectionUri(this.database, this.collection);
                var query = this.client.CreateDocumentQuery<ThermometerReading>(collectionUri, querySpec);

                // Run the query, and display the list of matching documents
                foreach (var doc in query)
                {
                    Console.WriteLine($"{doc.ToString()}");
                }

                Console.WriteLine("Press any key to quit.");
                Console.ReadKey();

            }
            catch (Exception ex)
            {
                Console.WriteLine($"{ex.ToString()}");
                Console.WriteLine();
                Console.WriteLine("Press any key to quit.");
                Console.ReadKey();
            }
        }
    }
}
