﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Configuration;

namespace ListOffencesData
{
    class Program
    {
        const int NUMCRIMINALRECORDS = 100;
        static void Main(string[] args)
        {
            // Query example 
            string alias = "";

            while (alias != "q")
            {
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine("Enter criminal alias to search for, or q to quit:");
                alias = Console.ReadLine();

                if (alias != "q")
                { 
                    string connectionString = ConfigurationManager.AppSettings["StorageConnectionString"];
                    CloudStorageAccount storageAccount = CloudStorageAccount.Parse(connectionString);

                    CloudTableClient tableClient = storageAccount.CreateCloudTableClient();
                    CloudTable criminalRecordsTable = tableClient.GetTableReference("CriminalRecords");

                    //Note: LINQ query to return values with the entered alias
                    var query = new TableQuery<TableStorageCriminalRecord>()
                        .Where(TableQuery.GenerateFilterCondition("Alias", QueryComparisons.Equal, alias));

                    foreach (var crim in criminalRecordsTable.ExecuteQuery(query))
                    {
                        Console.WriteLine($"{crim.FirstName}, {crim.Lastname}: {crim.Offence}");
                
                    }
                }
            }
        }
    }
}
