﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Globalization;

namespace ListOffencesData
{
    // Class containing offence information that can be written to Azure Table Storage
    public sealed class TableStorageCriminalRecord : TableEntity
    {
        private static int numberOfPartitions = 13;

        public string FirstName { get; set; }

        public string Lastname { get; set; }

        public string Alias { get; set; }

        public string Offence { get; set; }

        public TableStorageCriminalRecord()
        {
        }

        public TableStorageCriminalRecord(int ID)
        {
            // Identify the offence record based on the ID
            base.RowKey = ID.ToString();

            // Determine the partition key using the offence ID and the number of partitions
            base.PartitionKey = FindPartitionKey(base.RowKey);
        }

        // Find the partition for the offence. 
        // Offence records are partitioned based on the offence ID.
        // The partitioning strategy attempts to distribute offence records evenly across partitions
        public static string FindPartitionKey(string ID)
        {
            if (string.IsNullOrWhiteSpace(ID))
            {
                throw new ArgumentException(string.Format(CultureInfo.CurrentCulture, Strings.ErrorNullOffence));
            }

            return string.Format("Offence_{0:000}", (Math.Abs(ID.GetHashCode()) % numberOfPartitions) + 1);
        }
    }
}
