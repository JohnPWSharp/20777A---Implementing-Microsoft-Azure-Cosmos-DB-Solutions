﻿using Microsoft.Azure.CosmosDB.BulkExecutor;
using Microsoft.Azure.CosmosDB.BulkExecutor.BulkImport;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace BulkImportSample
{
    class Program
    {
        private static string dataFile;
        private static int numThreads;

        static void Main(string[] args)
        {
            dataFile = ConfigurationManager.AppSettings["DataFile"];
            numThreads = int.Parse(ConfigurationManager.AppSettings["NumThreads"]);

            var data = new List<FlightDelayDoc>(350000);
            populateData(data, dataFile);

            // Delete and setup so can run straight away
            ClearCollection().Wait();

            char action = ' ';
            while (action != 'X')
            {
                try
                {
                    action = displayMenu();
                    Console.WriteLine();
                    switch (action)
                    {
                        case 'A':
                            ImportUsingParallelThreads(data).Wait();
                            break;

                        case 'B':
                            ImportUsingBulkExecutorLibrary(data).Wait();
                            break;

                        case 'C':
                            ClearCollection().Wait();
                            break;

                        default:
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"{ex.ToString()}");
                }
            }
        }

        private static void populateData(List<FlightDelayDoc> data, string dataFile)
        {
            // Cache the data to be used (held in a CSV file), ready to upload to Cosmos DB
            Console.WriteLine("Caching data to upload");
            using (TextFieldParser parser = new TextFieldParser(dataFile))
            {
                parser.Delimiters = new String[] { "," };
                parser.ReadLine(); // skip the header row

                while (!parser.EndOfData)
                {
                    int tempValue;
                    string[] fileData = parser.ReadFields();
                    FlightDelayDoc doc = new FlightDelayDoc
                    {
                        ID = Guid.NewGuid().ToString(),
                        Year = int.TryParse(fileData[0], out tempValue) ? tempValue : 0,
                        Month = int.TryParse(fileData[1], out tempValue) ? tempValue : 0,
                        DayOfMonth = int.TryParse(fileData[2], out tempValue) ? tempValue : 0,
                        DayOfWeek = int.TryParse(fileData[3], out tempValue) ? tempValue : 0,
                        DepTime = int.TryParse(fileData[4], out tempValue) ? tempValue : 0,
                        CRSDepTime = int.TryParse(fileData[5], out tempValue) ? tempValue : 0,
                        ArrTime = int.TryParse(fileData[6], out tempValue) ? tempValue : 0,
                        CRSArrTime = int.TryParse(fileData[7], out tempValue) ? tempValue : 0,
                        UniqueCarrier = fileData[8],
                        FlightNum = int.TryParse(fileData[9], out tempValue) ? tempValue : 0,
                        TailNum = fileData[10],
                        ActualElapsedTime = int.TryParse(fileData[11], out tempValue) ? tempValue : 0,
                        CRSElapsedTime = int.TryParse(fileData[12], out tempValue) ? tempValue : 0,
                        AirTime = int.TryParse(fileData[13], out tempValue) ? tempValue : 0,
                        ArrDelay = int.TryParse(fileData[14], out tempValue) ? tempValue : 0,
                        DepDelay = int.TryParse(fileData[15], out tempValue) ? tempValue : 0,
                        Origin = fileData[16],
                        Dest = fileData[17],
                        Distance = int.TryParse(fileData[18], out tempValue) ? tempValue : 0,
                        TaxiIn = int.TryParse(fileData[19], out tempValue) ? tempValue : 0,
                        TaxiOut = int.TryParse(fileData[20], out tempValue) ? tempValue : 0,
                        Cancelled = (int.TryParse(fileData[21], out tempValue) ? tempValue : 0) == 1,
                        CancellationCode = fileData[22],
                        Diverted = (int.TryParse(fileData[23], out tempValue) ? tempValue : 0) == 1,
                        CarrierDelay = int.TryParse(fileData[24], out tempValue) ? tempValue : 0,
                        WeatherDelay = int.TryParse(fileData[25], out tempValue) ? tempValue : 0,
                        NASDelay = int.TryParse(fileData[26], out tempValue) ? tempValue : 0,
                        SecurityDelay = int.TryParse(fileData[27], out tempValue) ? tempValue : 0,
                        LateAircraftDelay = int.TryParse(fileData[28], out tempValue) ? tempValue : 0
                    };
                    data.Add(doc);
                }
                Console.WriteLine();
                Console.WriteLine("Data ready");
            }
        }

        private static char displayMenu()
        {
            Console.WriteLine();
            Console.WriteLine("Actions");
            Console.WriteLine("=======");
            Console.WriteLine("A: Import Documents using Parallel Threads");
            Console.WriteLine("B: Import Documents using the BulkExecutor Library");
            Console.WriteLine("C: Clear the Sample Collection");
            Console.WriteLine("X: Exit");

            return Char.ToUpper(Console.ReadKey().KeyChar);
        }

        private static async Task ImportUsingParallelThreads(List<FlightDelayDoc> data)
        {
            try
            {
                // Start uploading delay data documents individually, using parallel threads
                var driver = new DelayDataUploadDriver(numThreads, data);
                Stopwatch timer = new Stopwatch();
                timer.Start();
                driver.Run().Wait();
                timer.Stop();
                Console.WriteLine($"A: Time taken: {timer.ElapsedMilliseconds} ms");
            }
            catch (Exception e)
            {
                Trace.WriteLine($"Application failed with error: {e.Message}");
            }
        }

        private static async Task ImportUsingBulkExecutorLibrary(List<FlightDelayDoc> data)
        {
            try
            {
                var endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
                var primaryKey = ConfigurationManager.AppSettings["PrimaryKey"];
                var database = ConfigurationManager.AppSettings["Database"];
                var collection = ConfigurationManager.AppSettings["Collection"];

                // Connect to the Cosmos DB database
                var client = new DocumentClient(new Uri(endpointUrl), primaryKey);
                
                // Set retry options high during initialization (default values).
                client.ConnectionPolicy.RetryOptions.MaxRetryWaitTimeInSeconds = 30;
                client.ConnectionPolicy.RetryOptions.MaxRetryAttemptsOnThrottledRequests = 9;

                DocumentCollection docCollection = client.CreateDocumentCollectionQuery(UriFactory.CreateDatabaseUri(database))
                    .Where(c => c.Id == collection).AsEnumerable().FirstOrDefault();
                IBulkExecutor bulkExecutor = new BulkExecutor(client, docCollection);
                await bulkExecutor.InitializeAsync();

                // Set retries to 0 to pass complete control to bulk executor.
                client.ConnectionPolicy.RetryOptions.MaxRetryWaitTimeInSeconds = 0;
                client.ConnectionPolicy.RetryOptions.MaxRetryAttemptsOnThrottledRequests = 0;

                // Start uploading delay data documents using the BulkExecutor library
                Stopwatch timer = new Stopwatch();
                timer.Start();
                BulkImportResponse bulkImportResponse = null;
                do
                {
                    bulkImportResponse = await bulkExecutor.BulkImportAsync(
                                    documents: data,
                                    enableUpsert: true,
                                    disableAutomaticIdGeneration: true,
                                    maxConcurrencyPerPartitionKeyRange: null,
                                    maxInMemorySortingBatchSize: null);
                }
                while (bulkImportResponse.NumberOfDocumentsImported < data.Count);
                timer.Stop();
                Console.WriteLine($"B: Time taken: {timer.ElapsedMilliseconds} ms");
            }
            catch (Exception e)
            {
                Trace.WriteLine($"Application failed with error: {e.Message}");
            }
        }

        private static async Task ClearCollection()
        {
            try
            {
                var endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
                var primaryKey = ConfigurationManager.AppSettings["PrimaryKey"];
                var database = ConfigurationManager.AppSettings["Database"];
                var collection = ConfigurationManager.AppSettings["Collection"];
                var throughput = int.Parse(ConfigurationManager.AppSettings["Throughput"]);

                // Connect to the Cosmos DB database
                var client = new DocumentClient(new Uri(endpointUrl), primaryKey);

                Console.WriteLine();
                Console.WriteLine("C: Collection deleted");

                // Delete the existing collection (if it exists)
                try
                {
                    Uri collectionUri = UriFactory.CreateDocumentCollectionUri(database, collection);
                    await client.DeleteDocumentCollectionAsync(collectionUri);
                }
                catch
                {
                    // Do nothing - resource probably doesn't exist anyway, so ignore errors when deleting it
                }

                // Recreate the collection - with a PartitionKey of tailnum
                Uri databaseUri = UriFactory.CreateDatabaseUri(database);
                DocumentCollection newCollection = new DocumentCollection
                {
                    Id = collection,
                    PartitionKey = new PartitionKeyDefinition { Paths = { "/tailnum" } }                  
                };

                RequestOptions options = new RequestOptions
                {
                    OfferThroughput = throughput
                };

                await client.CreateDocumentCollectionAsync(databaseUri, newCollection, options);

                Console.WriteLine();
                Console.WriteLine("C: Collection created.");
            }
            catch (Exception e)
            {
                Trace.WriteLine($"Application failed with error: {e.Message}");
            }
        }
    }
}
