﻿using Microsoft.Azure.Documents.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Threading.Tasks;

namespace BulkImportSample
{
    internal class DelayDataUploader
    {
        private int threadNum;
        private List<FlightDelayDoc> dataPartition;
        private string endpointUrl;
        private string primaryKey;
        private string database;
        private string collection;
        private DocumentClient client;

        internal DelayDataUploader(int threadNum, List<FlightDelayDoc> dataPartition)
        {
            this.threadNum = threadNum;
            this.dataPartition = dataPartition;
            this.endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
            this.primaryKey = ConfigurationManager.AppSettings["PrimaryKey"];
            this.database = ConfigurationManager.AppSettings["Database"];
            this.collection = ConfigurationManager.AppSettings["Collection"];

            try
            {
                // Connect to the Cosmos DB database, and set options to enable multiple retries if an upload attempt fails
                this.client = new DocumentClient(new Uri(endpointUrl), primaryKey);
                this.client.ConnectionPolicy.RetryOptions.MaxRetryWaitTimeInSeconds = 30;
                this.client.ConnectionPolicy.RetryOptions.MaxRetryAttemptsOnThrottledRequests = 9;
            }
            catch (Exception e)
            {
                Trace.WriteLine($"Thread {this.threadNum} connection failed with error: {e.Message}");
            }
        }

        internal async Task Upload()
        {

            try
            {
                // Get the collection holding delay data documents
                var delayDataCollection = UriFactory.CreateDocumentCollectionUri(database, collection);

                // Upload the delay data dosuments from the specified partition in the cache
                foreach (var doc in dataPartition)
                {
                    await this.client.CreateDocumentAsync(delayDataCollection, doc);
                }
            }
            catch (Exception e)
            {
                Trace.TraceError($"Error uploading document for thread {this.threadNum}: {e.Message}");
            }
        }
    }
}