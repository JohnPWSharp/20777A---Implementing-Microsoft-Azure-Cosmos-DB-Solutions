﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace BulkImportSample
{
    internal class DelayDataUploadDriver
    {
        private int numThreads;
        private List<FlightDelayDoc> data;
        private Task[] taskList;

        internal DelayDataUploadDriver(int numThreads, List<FlightDelayDoc> data)
        {
            this.numThreads = numThreads;
            this.data = data;
            this.taskList = new Task[this.numThreads];
        }

        internal async Task Run()
        {
            // Partition the data array according to the number of threads, and start a new thread to upload each partition
            int partitionOffset = data.Count / (numThreads);
            Task[] t = new Task[numThreads];

            for (int threadNum = 0; threadNum < this.numThreads; threadNum++)
            {
                var dataPartition = data.GetRange(threadNum * partitionOffset, partitionOffset);
                var delayDataUploader = new DelayDataUploader(threadNum, dataPartition);
                t[threadNum] =  Task.Run(() => delayDataUploader.Upload());
            }

            Task.WaitAll(t);
        }
    }
}