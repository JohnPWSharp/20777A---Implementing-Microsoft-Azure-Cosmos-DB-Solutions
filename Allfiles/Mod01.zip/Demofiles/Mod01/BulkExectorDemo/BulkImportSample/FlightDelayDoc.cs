﻿using Newtonsoft.Json;

namespace BulkImportSample
{
    public class FlightDelayDoc
    {
        [JsonProperty("id")]
        public string ID { get; set; }

        [JsonProperty("year")]
        public int Year { get; set; }

        [JsonProperty("month")]
        public int Month { get; set; }

        [JsonProperty("dayofmonth")]
        public int DayOfMonth { get; set; }

        [JsonProperty("dayofweek")]
        public int DayOfWeek { get; set; }

        [JsonProperty("deptime")]
        public int DepTime { get; set; }

        [JsonProperty("crsdeptime")]
        public int CRSDepTime { get; set; }

        [JsonProperty("arrtime")]
        public int ArrTime { get; set; }

        [JsonProperty("crsarrtime")]
        public int CRSArrTime { get; set; }

        [JsonProperty("uniquecarrier")]
        public string UniqueCarrier { get; set; }

        [JsonProperty("flightnum")]
        public int FlightNum { get; set; }

        [JsonProperty("tailnum")]
        public string TailNum { get; set; }

        [JsonProperty("actualelapsedtime")]
        public int ActualElapsedTime { get; set; }

        [JsonProperty("crselapsedtime")]
        public int CRSElapsedTime { get; set; }
        
        [JsonProperty("airtime")]
        public int AirTime { get; set; }

        [JsonProperty("arrdelay")]
        public int ArrDelay { get; set; }

        [JsonProperty("depdelay")]
        public int DepDelay { get; set; }

        [JsonProperty("origin")]
        public string Origin { get; set; }
        
        [JsonProperty("dest")]
        public string Dest { get; set; }

        [JsonProperty("distance")]
        public int Distance { get; set; }

        [JsonProperty("taxiin")]
        public int TaxiIn { get; set; }

        [JsonProperty("taxiout")]
        public int TaxiOut { get; set; }

        [JsonProperty("cancelled")]
        public bool Cancelled { get; set; }

        [JsonProperty("cancellationcode")]
        public string CancellationCode { get; set; }

        [JsonProperty("diverted")]
        public bool Diverted { get; set; }

        [JsonProperty("carrierdelay")]
        public int CarrierDelay { get; set; }

        [JsonProperty("weatherdelay")]
        public int WeatherDelay { get; set; }

        [JsonProperty("nasdelay")]
        public int NASDelay { get; set; }

        [JsonProperty("securitydelay")]
        public int SecurityDelay { get; set; }

        [JsonProperty("lateaircraftdelay")]
        public int LateAircraftDelay { get; set; }
    }
}