﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using System;
using System.Configuration;
using System.Threading.Tasks;

namespace QueryCustomers
{
    class Program
    {
        static void Main(string[] args)
        {
            Worker worker = new Worker();
            worker.DoWork().Wait();
        }
    }

    class Worker
    {
        private DocumentClient client;
        private string endpointUrl;
        private string primaryKey;
        private string database;
        private string collection;

        public async Task DoWork()
        {
            // Retrieve the configuration settings
            this.endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
            this.primaryKey = ConfigurationManager.AppSettings["PrimaryKey"];
            this.database = ConfigurationManager.AppSettings["Database"];
            this.collection = ConfigurationManager.AppSettings["Collection"];

            // Connect to the Cosmos DB database
            this.client = new DocumentClient(new Uri(endpointUrl), primaryKey);

            // Perform queries
            char action = ' ';
            while (action != 'X')
            {
                try
                {
                    action = displayMenu();
                    Console.WriteLine();
                    switch (action)
                    {
                        case 'A':
                            // Find a specified customer using the customers's ID
                            await FindCustomerDocumentByID();
                            break;

                        case 'B':
                            // Search for customers with a given last name
                            FindCustomerByLastName();
                            break;

                        default:
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"{ex.ToString()}");
                }
            }
        }

        private char displayMenu()
        {
            Console.WriteLine("Actions");
            Console.WriteLine("=======");
            Console.WriteLine("A: Find Customer by ID");
            Console.WriteLine("B: Find Customer by Last Name");
            Console.WriteLine("X: Exit");

            return Char.ToUpper(Console.ReadKey().KeyChar);
        }

        private async Task FindCustomerDocumentByID()
        {
            try
            {
                // Prompt the user for the customer's document ID
                Console.WriteLine("Enter document ID");
                string id = Console.ReadLine();

                // Construct the URI for this document
                Uri docUri = UriFactory.CreateDocumentUri(this.database, this.collection, id);

                // Fetch the document
                var documentResponse = await client.ReadDocumentAsync<CustomerInfo>(docUri);

                // Display the contents of the document
                Console.WriteLine(documentResponse.Document);
                Console.WriteLine();
            }
            catch (DocumentClientException dce)
            {
                Console.WriteLine($"{dce.Message}");
            }
        }

        private void FindCustomerByLastName()
        {
            try
            {
                // Prompt the user for the last name
                Console.WriteLine("Enter last name");
                string lastName = Console.ReadLine();

                // Construct a query to find matching customers
                string queryString = $"SELECT * FROM {this.collection} c WHERE c.lastname = @lastname";
                SqlParameterCollection parameters = new SqlParameterCollection()
                {
                    new SqlParameter("@lastname", lastName)
                };

                SqlQuerySpec querySpec = new SqlQuerySpec()
                {
                    QueryText = queryString,
                    Parameters = parameters
                };

                // Specify the collection to run the query against
                Uri collectionUri = UriFactory.CreateDocumentCollectionUri(this.database, this.collection);
                var query = this.client.CreateDocumentQuery<CustomerInfo>(collectionUri, querySpec);

                // Run the query, and display the list of matching customers
                foreach (var doc in query)
                {
                    Console.WriteLine($"{doc.ToString()}");
                }
            }
            catch (DocumentClientException dce)
            {
                Console.WriteLine($"{dce.Message}");
            }
        }
    }
}
