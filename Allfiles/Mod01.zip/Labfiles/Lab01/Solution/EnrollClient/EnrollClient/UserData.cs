﻿using Newtonsoft.Json;

namespace EnrollClient
{
    public class UserData
    {
        [JsonProperty("username")]
        public string UserName { get; set; }

        [JsonProperty("password")]
        public string Password { get; set; }
    }
}
