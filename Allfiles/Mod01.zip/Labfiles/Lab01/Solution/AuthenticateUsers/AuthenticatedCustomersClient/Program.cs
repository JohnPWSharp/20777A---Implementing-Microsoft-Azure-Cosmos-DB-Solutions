﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace AuthenticatedCustomersClient
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                do
                {
                    // Prompt the user for their credentials
                    Console.WriteLine("User name: ");
                    string userName = Console.ReadLine();
                    Console.WriteLine("Password: ");
                    string password = Console.ReadLine();

                    DoWork(userName, password).Wait();

                    Console.WriteLine();
                    Console.WriteLine("Type q to quite, or any key to login again");

                } while (Char.ToUpper(Console.ReadKey().KeyChar) != 'Q');
            }
            catch (AggregateException e)
            {
                foreach (var i in e.Flatten().InnerExceptions)
                {
                    Console.WriteLine($"{i.Message}");
                }
                Console.ReadKey();
            }
        }

        static async Task DoWork(string userName, string password)
        {
            // TODO: Use the Web API to authenticate the user and obtain a collection of security tokens
            HttpClient httpClient = new HttpClient();
            httpClient.BaseAddress = new Uri("http://localhost:50281/");
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));

            HttpResponseMessage response = await httpClient.GetAsync($"api/Authenticate?userName={userName}&password={password}");

            if (response.IsSuccessStatusCode)
            {
                // TODO: If the user was successfuly authenticated, retrieve the resource token from the response
                Stream tokenStream = await response.Content.ReadAsStreamAsync();
                StreamReader reader = new StreamReader(tokenStream);
                var token = await Task.Factory.StartNew(() =>
                    JsonConvert.DeserializeObject<string>(reader.ReadToEnd()));

                // TODO: Connect to the Cosmos DB account using the resource token
                string endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
                DocumentClient client = new DocumentClient(new Uri(endpointUrl), token);

                // TODO: Read data from the collection
                string database = ConfigurationManager.AppSettings["Database"];
                string collection = ConfigurationManager.AppSettings["Collection"];
                Uri collectionUri = UriFactory.CreateDocumentCollectionUri(database, collection);
                var query = client.CreateDocumentQuery<CustomerInfo>(collectionUri);

                foreach (var doc in query)
                {
                    Console.WriteLine();
                    Console.WriteLine($"{doc.ToString()}");
                }

                // TODO: Attempt to write to the collection
                CustomerInfo user = new CustomerInfo
                {
                    CustomerID = new Random().Next(),
                    FirstName = "Brand",
                    MiddleName = "New",
                    LastName = "Customer"
                };

                await client.CreateDocumentAsync(collectionUri, user);
                Console.WriteLine();
                Console.WriteLine("Document added");

            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("Authorization failed");
            }
        }
    }
}
