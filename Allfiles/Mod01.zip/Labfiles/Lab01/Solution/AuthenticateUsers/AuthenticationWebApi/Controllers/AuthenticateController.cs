﻿using AuthenticationWebApi.Models;
using Microsoft.Azure.Documents.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Http;

namespace AuthenticationWebApi.Controllers
{
    public class AuthenticateController : ApiController
    {
        private Dictionary<string, string> users = null;
        private DocumentClient client = null;

        public AuthenticateController()
        {
            // Create a client for connecting to the CosmosDB account
            string endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
            string primaryKey = ConfigurationManager.AppSettings["PrimaryKey"];
            client = new DocumentClient(new Uri(endpointUrl), primaryKey);

            // TODO: Retrieve the usernames and passwords from the security database
            string securityDatabase = ConfigurationManager.AppSettings["SecurityDatabase"];
            string securityCollection = ConfigurationManager.AppSettings["SecurityCollection"];
            Uri securityCollectionUri = UriFactory.CreateDocumentCollectionUri(securityDatabase, securityCollection);
            var query = client.CreateDocumentQuery<UserData>(securityCollectionUri, new FeedOptions
            {
                EnableCrossPartitionQuery = true
            });

            // TODO: Populate the users Dictionary from the username/password database
            users = new Dictionary<string, string>(query.Count());
            foreach (var user in query)
            {
                users[user.UserName] = user.Password;
            }
        }

        [HttpGet]
        public async Task<IHttpActionResult> Authenticate(string userName, string password)
        {
            // Validate the user's credentials against the dictionary of user accounts and password
            if (users.ContainsKey(userName) && string.Compare(users[userName], password) == 0)
            {
                // User is valid. 
                // TODO: Get the resource token(s) from the permission feed in the database
                string database = ConfigurationManager.AppSettings["Database"];
                string collection = ConfigurationManager.AppSettings["Collection"];
                var permissionsUri = UriFactory.CreateUserUri(database, userName);
                var permissions = await client.ReadPermissionFeedAsync(permissionsUri);

                // TODO: Find the resource token for the specified user
                Regex expression = new Regex($"{userName}-.");
                string resourceToken = null;
                foreach (var permission in permissions)
                {
                    var matching = expression.Matches(permission.Id);
                    if (matching.Count > 0)
                    {
                        resourceToken = permission.Token;
                        return Ok(resourceToken); ;
                    }
                }

                // TODO: If there was no token for the specified partition, then return HTTP status code 401 (Unauthorized)
                return Unauthorized();

            }

            // TODO: If the user does not exist in the dictionary, or the password is wrong, return HTTP status code 401 (Unauthorized)
            return Unauthorized();
        }
    }
}