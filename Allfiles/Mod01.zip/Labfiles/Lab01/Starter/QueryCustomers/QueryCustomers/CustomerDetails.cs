﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace QueryCustomers
{
    public class AddressInfo
    {
        [JsonProperty("addressline1")]
        public string AddressLine1 { get; set; }

        [JsonProperty("addressline2")]
        public string AddressLine2 { get; set; }

        [JsonProperty("city")]
        public string City { get; set; }

        [JsonProperty("stateprovince")]
        public string StateProvince { get; set; }

        [JsonProperty("countryregion")]
        public string CountryRegion { get; set; }

        [JsonProperty("postalcode")]
        public string PostalCode { get; set; }

        public override string ToString() => $"{AddressLine1}, {AddressLine2}, {City}, {StateProvince}, {CountryRegion}, {PostalCode}";
    }

    public class CustomerInfo
    {
        [JsonProperty("id")]
        public string ID { get; set; }

        [JsonProperty("customerid")]
        public int CustomerID { get; set; }

        [JsonProperty("title")]
        public string Title { get; set; }

        [JsonProperty("firstname")]
        public string FirstName { get; set; }

        [JsonProperty("middlename")]
        public string MiddleName { get; set; }

        [JsonProperty("lastname")]
        public string LastName { get; set; }

        [JsonProperty("suffix")]
        public string Suffix { get; set; }

        [JsonProperty("companyname")]
        public string CompanyName { get; set; }

        [JsonProperty("salesperson")]
        public string SalesPerson { get; set; }

        [JsonProperty("emailaddress")]
        public string EmailAddress { get; set; }

        [JsonProperty("phone")]
        public string Phone { get; set; }

        [JsonProperty("addresses")]
        public List<AddressInfo> Addresses { get; set; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"{CustomerID}: {Title} {FirstName} {MiddleName} {LastName} {Suffix}{Environment.NewLine}");
            sb.Append($"{CompanyName}, {EmailAddress}, {Phone}{Environment.NewLine}");
            sb.Append($"Contact {SalesPerson}{Environment.NewLine}");
            sb.Append($"Addresses:{Environment.NewLine}");
            foreach (AddressInfo addr in Addresses)
            {
                sb.Append($"{addr}{Environment.NewLine}");
            }

            return sb.ToString();
        }
    }
}
