﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using System;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace EnrollClient
{
    class UserEnroller
    {
        public HttpStatusCode NotFound { get; private set; }

        public async Task CreateUser(string userName, string password, char permission)
        {
            // Retrieve the configuration settings
            string endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
            string primaryKey = ConfigurationManager.AppSettings["PrimaryKey"];
            string database = ConfigurationManager.AppSettings["Database"];
            string collection = ConfigurationManager.AppSettings["Collection"];
            string securityDatabase = ConfigurationManager.AppSettings["SecurityDatabase"];
            string securityCollection = ConfigurationManager.AppSettings["SecurityCollection"];

            // TODO: Connect to the Cosmos DB account

            // TODO: Check whether the user already exists

            if (result.Count == 0)
            {
                // TODO: If the user doesn't exist, then create it

                try
                {
                    await client.CreateUserAsync(UriFactory.CreateDatabaseUri(database), databaseUser);
                    Console.WriteLine("User added to Customer database");
                }
                catch (SystemException e)
                {
                    Console.WriteLine($"Error adding user {e.Message}");
                }

                // TODO: Record the user's name and password in the security database (used for authenticating the user when they log in)

                try
                {
                    await client.CreateDocumentAsync(securityCollectionUri, userData);
                    Console.WriteLine("Security settings stored");
                }
                catch (SystemException e)
                {
                    Console.WriteLine($"Error storing security details {e.Message}");
                }

            }

            // TODO: Set the user's permission on the specified database and collection

            try
            {
                await client.CreatePermissionAsync(UriFactory.CreateUserUri(database, userName), collectionPermission);
                await VerifyUser(client, userName, database);
                Console.WriteLine("Permission verified");
            }
            catch (SystemException e)
            {
                Console.WriteLine($"Error checking permissions {e.Message}");
            }

        }

        // Display the permissions currently assigned to the user
        public async Task VerifyUser(DocumentClient client, string userName, string database)
        {
            FeedResponse<Permission> permissionFeed = await client.ReadPermissionFeedAsync(UriFactory.CreateUserUri(database, userName));
            foreach (Permission perm in permissionFeed)
            {
                Console.WriteLine($"Mode: {perm.PermissionMode}{Environment.NewLine}Resource: {perm.ResourceLink}{Environment.NewLine}ID: {perm.Id}{Environment.NewLine}Token: {perm.Token}");
            }
        }
    }
}
