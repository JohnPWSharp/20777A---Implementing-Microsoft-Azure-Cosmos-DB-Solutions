﻿using Microsoft.Azure.Documents.Client;
using System;
using System.Configuration;

namespace EnrollClient
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                do
                {
                    // Prompt for the permission data to use
                    Console.Write("User name: ");
                    string userName = Console.ReadLine();
                    Console.Write("Password: ");
                    string password = Console.ReadLine();

                    ConsoleKeyInfo permission;
                    do
                    {
                        Console.Write("Permission R(ead)/A(ll): ");
                        permission = Console.ReadKey();
                        Console.WriteLine();
                    } while (Char.ToUpper(permission.KeyChar) != 'R' && Char.ToUpper(permission.KeyChar) != 'A');

                    // Create the user with the specified permission
                    UserEnroller enroller = new UserEnroller();
                    enroller.CreateUser(userName, password, permission.KeyChar).Wait();

                    Console.WriteLine();
                    Console.WriteLine("Press q to quit, any other key to add a new user");
                    
                } while (Char.ToUpper(Console.ReadKey().KeyChar) != 'Q');


            }
            catch (Exception e)
            {
                Console.WriteLine($"{e.Message}");
                Console.ReadKey();
            }
        }
    }
}
