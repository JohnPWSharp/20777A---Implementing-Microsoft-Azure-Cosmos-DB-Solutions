﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace AuthenticatedCustomersClient
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                do
                {
                    // Prompt the user for their credentials
                    Console.WriteLine("User name: ");
                    string userName = Console.ReadLine();
                    Console.WriteLine("Password: ");
                    string password = Console.ReadLine();

                    DoWork(userName, password).Wait();

                    Console.WriteLine();
                    Console.WriteLine("Type q to quite, or any key to login again");

                } while (Char.ToUpper(Console.ReadKey().KeyChar) != 'Q');
            }
            catch (AggregateException e)
            {
                foreach (var i in e.Flatten().InnerExceptions)
                {
                    Console.WriteLine($"{i.Message}");
                }
                Console.ReadKey();
            }
        }

        static async Task DoWork(string userName, string password)
        {
            // TODO: Use the Web API to authenticate the user and obtain a collection of security tokens

            if (response.IsSuccessStatusCode)
            {
                // TODO: If the user was successfuly authenticated, retrieve the resource token from the response

                // TODO: Connect to the Cosmos DB account using the resource token

                // TODO: Read data from the collection

                // TODO: Attempt to write to the collection

                // Document added
                Console.WriteLine();
                Console.WriteLine("Document added");

            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("Authorization failed");
            }
        }
    }
}
