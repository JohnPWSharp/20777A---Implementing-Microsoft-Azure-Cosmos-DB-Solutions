﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;

namespace MongoDBCustomers
{
    class Program
    {
        static void Main(string[] args)
        {
            // Retrieve the configuration settings
            string address = ConfigurationManager.AppSettings["Address"];
            int port = int.Parse(ConfigurationManager.AppSettings["Port"]);
            string database = ConfigurationManager.AppSettings["Database"];
            string collection = ConfigurationManager.AppSettings["Collection"];
            string username = ConfigurationManager.AppSettings["Username"];
            string password = ConfigurationManager.AppSettings["Password"];

            try
            {
                // Connect to the MongoDB database
                var client = new MongoClient(new MongoClientSettings
                {
                    Server = new MongoServerAddress(address, port),
                    ServerSelectionTimeout = TimeSpan.FromSeconds(10),
                    Credential = MongoCredential.CreateCredential(database, username, password)
                });

                // Get the collection holding CustomerInfo documents
                var mongoDB = client.GetDatabase(database);
                var customerCollection = mongoDB.GetCollection<CustomerInfo>(collection);

                // Retrieve the customer data from SQL Server
                var sqlDB = new jssqldbEntities();
                var custQuery = from c in sqlDB.Customers
                                where c.CustomerID > 1000
                                select c;

                foreach (var customer in custQuery)
                {
                    Trace.WriteLine($"Adding {customer.FirstName}, {customer.LastName}");
                    CustomerInfo info = new CustomerInfo
                    {
                        CustomerID = customer.CustomerID,
                        Title = customer.Title,
                        FirstName = customer.FirstName,
                        MiddleName = customer.MiddleName,
                        LastName = customer.LastName,
                        Suffix = customer.Suffix,
                        CompanyName = customer.CompanyName,
                        SalesPerson = customer.SalesPerson,
                        EmailAddress = customer.EmailAddress,
                        Phone = customer.Phone,
                        Addresses = new List<AddressInfo>()
                    };

                    // Find the address(es) for the current customer
                    var addrs = from a in sqlDB.Addresses
                                join j in sqlDB.CustomerAddresses
                                on a.AddressID equals j.AddressID
                                where j.CustomerID == customer.CustomerID
                                select new { a.AddressLine1, a.AddressLine2, a.City, a.CountryRegion, a.PostalCode, a.StateProvince};

                    foreach (var addr in addrs)
                    {
                        info.Addresses.Add(new AddressInfo
                        {
                            AddressLine1 = addr.AddressLine1,
                            AddressLine2 = addr.AddressLine2,
                            City = addr.City,
                            CountryRegion = addr.CountryRegion,
                            PostalCode = addr.PostalCode,
                            StateProvince = addr.StateProvince
                        });
                    }

                    // Add the CustomerInfo document to the MongoDB database
                   customerCollection.InsertOneAsync(info).Wait();
                }
            }
            catch (Exception e)
            {
                Trace.WriteLine($"Program failed with error: {e.Message}");
            }
        }
    }
}
