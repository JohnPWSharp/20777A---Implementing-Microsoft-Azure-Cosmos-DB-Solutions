﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.Collections.Generic;

namespace MongoDBCustomers
{
    public class AddressInfo
    {
        [BsonElement("addressline1")]
        public string AddressLine1 { get; set; }

        [BsonElement("addressline2")]
        public string AddressLine2 { get; set; }

        [BsonElement("city")]
        public string City { get; set; }

        [BsonElement("stateprovince")]
        public string StateProvince { get; set; }

        [BsonElement("countryregion")]
        public string CountryRegion { get; set; }

        [BsonElement("postalcode")]
        public string PostalCode { get; set; }
    }

    public class CustomerInfo
    {
        [BsonId]
        public ObjectId ID { get; set; }

        [BsonElement("customerid")]
        public int CustomerID { get; set; }

        [BsonElement("title")]
        public string Title { get; set; }

        [BsonElement("firstname")]
        public string FirstName { get; set; }

        [BsonElement("middlename")]
        public string MiddleName { get; set; }

        [BsonElement("lastname")]
        public string LastName { get; set; }

        [BsonElement("suffix")]
        public string Suffix { get; set; }

        [BsonElement("companyname")]
        public string CompanyName { get; set; }

        [BsonElement("salesperson")]
        public string SalesPerson { get; set; }

        [BsonElement("emailaddress")]
        public string EmailAddress { get; set; }

        [BsonElement("phone")]
        public string Phone { get; set; }

        [BsonElement("addresses")]
        public List<AddressInfo> Addresses { get; set; }
    }
}
