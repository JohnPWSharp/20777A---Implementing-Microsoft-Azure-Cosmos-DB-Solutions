﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;

namespace TestTrigger
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string endpointUrl;
        private string primaryKey;
        private string database;
        private string collection;
        private string trigger;
        private DocumentClient client;

        public MainWindow()
        {
            InitializeComponent();

            // Retrieve the configuration settings
            this.endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
            this.primaryKey = ConfigurationManager.AppSettings["PrimaryKey"];
            this.database = ConfigurationManager.AppSettings["Database"];
            this.collection = ConfigurationManager.AppSettings["Collection"];
            this.trigger = ConfigurationManager.AppSettings["Trigger"];

            try
            {
                // Connect to the Cosmos DB database
                this.client = new DocumentClient(new Uri(endpointUrl), primaryKey);

                // Initialize the documentText text box
                documentText.Text = "{" + Environment.NewLine + $"\"id\": \"{Guid.NewGuid()}\"," + Environment.NewLine + Environment.NewLine + Environment.NewLine + Environment.NewLine + "}";
            }
            catch (Exception ex)
            {
                message.Text = $"{ex.ToString()}";
            }
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            // Clear any error messages currently displayed
            message.Text = "";

            // Read the document text entered by the user and convert it into a JSON object 
            var document = JObject.Parse(documentText.Text);

            // Create the document and fire the trigger to validate the Ticks field
            try
            {
                // Get the Uri of the Temperatures collection
                Uri documentCollectionUri = UriFactory.CreateDocumentCollectionUri(this.database, this.collection);

                // Specify that the create document API call should invoke the Pre trigger
                var options = new RequestOptions
                {
                    PreTriggerInclude = new List<string> { this.trigger }
                };

                // Create the document and get the response
                var reply = await this.client.CreateDocumentAsync(documentCollectionUri, document, options);

                // Parse the JSON document into a Dictionary
                var values = JsonConvert.DeserializeObject<Dictionary<string, string>>(reply.Resource.ToString());

                // Display the document in the documentText text box
                StringBuilder builder = new StringBuilder();
                builder.Append("{" + Environment.NewLine);
                foreach (var item in values)
                {
                    // Ignore system properties that start with the '_' character
                    if (item.Key.First() != '_')
                    {
                        builder.Append($"\"{item.Key}\": \"{item.Value}\",{Environment.NewLine}");
                    }
                }
                builder.Append("}");
                documentText.Text = builder.ToString();
            }
            catch (DocumentClientException dce)
            {
                Regex errMsgPattern = new Regex(@".*(?<error>Error:.*)\\r\\nStack.*");
                Match errMsgMatch = errMsgPattern.Match(dce.Message);
                if (errMsgMatch.Success)
                {
                    message.Text = errMsgMatch.Groups["error"].Value;
                }
                else
                {
                    message.Text = $"{dce.Message}";
                }
            }
            catch (Exception ex)
            {
                message.Text = $"{ex.Message}";
            }
        }
    }
}
