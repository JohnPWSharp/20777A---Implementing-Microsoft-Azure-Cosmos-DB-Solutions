﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Adventure_Works.Models
{
    public class CustomerName
    {
        // Define properties
        [JsonProperty("title")]
        public string Title { get; set; }

        [JsonProperty("firstname")]
        public string FirstName { get; set; }

        [JsonProperty("middlename")]
        public string MiddleName { get; set; }

        [JsonProperty("lastname")]
        public string LastName { get; set; }
    }

    public class Customer : DocumentType
    {
        // Define properties
        [JsonProperty("partitionkey")]
        public string CustomerID { get; set; }

        [JsonProperty("name")]
        public CustomerName CustomerName { get; set; }

        [JsonProperty("discountrate")]
        public int DiscountRate { get; set; }
    }
}