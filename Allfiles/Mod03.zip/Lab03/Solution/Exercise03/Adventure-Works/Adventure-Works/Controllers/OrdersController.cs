﻿using Adventure_Works.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace Adventure_Works.Controllers
{
    public class OrdersController : Controller
    {
        #region helper methods for finding and caching orders

        // Locate and cache the orders for the currently logged in customer
        private async Task<List<ShoppingCartOrder>> GetOrdersForCustomerAsync(Customer customer)
        {
            // Find the orders for the customer
            var orders = await Repository<ShoppingCartOrder>.GetItemsAsync(
                o => o.DocType == nameof(ShoppingCartOrder) && o.IsShoppingCartOrOrder == Constants.ORDER && o.CustomerID == customer.CustomerID);

            // Cache the orders in the Session
            var ordersList = orders.ToList();
            Session["orders"] = ordersList;

            // Return the list of orders
            return ordersList;
        }

        // Find the specified order in the Session cache
        private async Task<ShoppingCartOrder> FindOrderAsync(string orderID)
        {
            var orders = Session["orders"] as List<ShoppingCartOrder>;

            // Find the order with the specified order id and return it (or null if the order is not found)
            if (orders != null)
            {
                return orders.Find(o => string.Compare(o.ShoppingCartOrderID, orderID) == 0);
            }

            // If the orders collection is not present in the cache, return null
            return null;
        }

        // Locate and cache the backorders for the currently logged in customer
        private async Task<List<ProductBackorder>> GetBackordersForCustomerAsync(Customer customer)
        {
            // Find the backorders for the customer
            var backorders = await Repository<ProductBackorder>.GetItemsAsync(
                b => b.DocType == nameof(ProductBackorder) &&  b.CustomerID == customer.CustomerID);

            // Cache the backorders in the Session
            var backordersList = backorders.ToList();
            Session["backorders"] = backordersList;

            // Return the list of backorders
            return backordersList;
        }

        // Find the specified backorder in the Session cache
        private async Task<ProductBackorder> FindBackorderAsync(string backorderID)
        {
            var backorders = Session["backorders"] as List<ProductBackorder>;

            // Find the backorders with the specified order id and return it (or null if the order is not found)
            if (backorders != null)
            {
                return backorders.Find(b => string.Compare(b.BackorderID, backorderID) == 0);
            }

            // If the backorders collection is not present in the cache, return null
            return null;
        }
        #endregion

        // Method that fetches and displays the orders for the customer
        [ActionName("ViewOrders")]
        [HttpGet]
        public async Task<ActionResult> ViewOrdersAsync()
        {
            // Check whether the user has logged in
            if (Session["customer"] == null)
            {
                // If not, then get them to log in
                Session["ReturnData"] = new { ReturnURL = "ViewOrders", Controller = "Orders" };
                return View("Login");
            }

            // Retrieve the orders for the customer
            var orders = await GetOrdersForCustomerAsync(Session["customer"] as Customer);

            // Fetch and cache the backorders as well
            await GetBackordersForCustomerAsync(Session["customer"] as Customer);

            // Display the orders
            return View(orders);
        }

        // Method that cancels an order
        [ActionName("CancelOrder")]
        [HttpPost]
        public async Task<ActionResult> CancelOrderAsync(string orderID)
        {
            // Retrieve the order from the Session cache
            var orderToCancel = await FindOrderAsync(orderID);

            // Change the status of the order
            if (orderToCancel != null)
            {
                // Only cancel orders that are marked as "in progress". Orders already cancelled or delivered cannot be updated
                if (string.Compare(orderToCancel.OrderStatus, Constants.INPROGRESS) == 0)
                {
                    orderToCancel.OrderStatus = Constants.CANCELLED;

                    // TODO: Save the order, and fire AuditOrder post-trigger
                    if (1==0)
                    {
                        StringBuilder message = new StringBuilder($"Order {orderID} cancelled");

                        // Find any backorders for the order and cancel them as well
                        foreach (var orderItem in orderToCancel.OrderItems)
                        {
                            if (orderItem.BackorderReference != null)
                            {
                                // Retrieve the backorder from the Session cache
                                var backorderToCancel = await FindBackorderAsync(orderItem.BackorderReference);

                                // Only cancel backorders that are "in progress"
                                if (string.Compare(backorderToCancel.BackorderStatus, Constants.INPROGRESS) == 0)
                                {
                                    // Change the status of the backorder
                                    backorderToCancel.BackorderStatus = Constants.CANCELLED;

                                    // TODO: Save the backorder, and fire the AuditOrder post-trigger
                                    
                                }
                            }
                        }
                        TempData["itemMessage"] = message.ToString();
                    }
                }
            }
            else
            {
                TempData["itemMessage"] = $"Order {orderID} not found";
            }

            // Display the orders again
            return View("ViewOrders", Session["orders"]);
        }

        // Method that displays the details of an order
        [ActionName("OrderDetails")]
        [HttpPost]
        public async Task<ActionResult> OrderDetailsAsync(string orderID)
        {
            /// Retrieve the order from the Session cache
            var order = await FindOrderAsync(orderID);

            // Display the details page
            return View(order.OrderItems);
        }

        // Method that fetches and displays the backorders for the customer
        [ActionName("ViewBackorders")]
        [HttpGet]
        public async Task<ActionResult> ViewBackordersAsync()
        {
            // Check whether the user has logged in
            if (Session["customer"] == null)
            {
                // If not, then get them to log in
                Session["ReturnData"] = new { ReturnURL = "ViewBackorders", Controller = "Orders" };
                return View("Login");
            }

            // Retrieve the backorders for the customer
            var backorders = await GetBackordersForCustomerAsync(Session["customer"] as Customer);

            // Fetch and cache the orders as well
            await GetOrdersForCustomerAsync(Session["customer"] as Customer);

            // Display the backorders
            return View(backorders);
        }

        // Method that displays the details of a backorder
        [ActionName("BackorderDetails")]
        [HttpGet]
        public async Task<ActionResult> BackorderDetailsAsync(string backorderID)
        { 
            // Retrieve the backorder from the Session cache
            var backorder = await FindBackorderAsync(backorderID);

            // Display the details page
            return View(backorder);
        }

        // Method that cancels a backorder
        [ActionName("CancelBackorder")]
        [HttpPost]
        public async Task<ActionResult> CancelBackorderAsync(string backorderID)
        {
            // Retrieve the backorder from the Session cache
            var backorderToCancel = await FindBackorderAsync(backorderID);

            // Change the status of the backorder
            if (backorderToCancel != null)
            {
                if (string.Compare(backorderToCancel.BackorderStatus, Constants.INPROGRESS) == 0)
                {
                    // Only cancel backorders that are marked as "in progress". Backorders already cancelled or delivered cannot be updated
                    backorderToCancel.BackorderStatus = Constants.CANCELLED;

                    // TODO: Save the backorder, and fire the AuditOrder post-trigger
                    
                }
            }
            else
            {
                TempData["itemMessage"] = $"Backorder {backorderID} not found";
            }

            // Display the orders again
            return View("ViewBackorders", Session["backorders"]);
        }
    }
}