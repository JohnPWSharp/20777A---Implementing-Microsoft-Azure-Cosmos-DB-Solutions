﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Adventure_Works.Models
{
    public class OrderItem
    {
        // TODO: Define properties
        
    }

    public class ShoppingCartOrder : DocumentType
    {
        // TODO: Define properties
        
    }
}