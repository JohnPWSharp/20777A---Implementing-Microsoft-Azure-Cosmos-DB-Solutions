﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DeleteDocs
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string endpointUrl;
        private string primaryKey;
        private string database;
        private string collection;
        private string storedProc;
        private DocumentClient client;

        public MainWindow()
        {
            InitializeComponent();

            // Retrieve the configuration settings
            this.endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
            this.primaryKey = ConfigurationManager.AppSettings["PrimaryKey"];
            this.database = ConfigurationManager.AppSettings["Database"];
            this.collection = ConfigurationManager.AppSettings["Collection"];
            this.storedProc = ConfigurationManager.AppSettings["StoredProc"];

            try
            {
                // Connect to the Cosmos DB database
                this.client = new DocumentClient(new Uri(endpointUrl), primaryKey);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.ToString()}", "Exception", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            // Read the user input (should really be validated as well)
            var deviceID = this.selectedDevice.Text;
            var date = this.selectedDate.SelectedDate;

            try
            {
                // Get the URI of the deleteOldDocs stored procedure
                Uri storedProcUri = UriFactory.CreateStoredProcedureUri(this.database, this.collection, this.storedProc);

                // Run the stored procedure - specify the partition identified by the deviceID value
                var options = new RequestOptions
                {
                    PartitionKey = new PartitionKey(deviceID)
                };

                var storedProcResults = await this.client.ExecuteStoredProcedureAsync<DeleteOldDocsResponse>(storedProcUri, options, deviceID, date.Value.ToString("dd MMM yyyy"));

                // Display the number of docs deleted
                this.numDeleted.Text = $"Documents Deleted: {storedProcResults.Response.Deleted}";

                // Display the cost (RUs) of running the stored procedure
                this.cost.Text = $"Cost: {storedProcResults.RequestCharge} RUs";

                // Check for a continuation token, and enable the "Delete More" button if necessary
                if (storedProcResults.Response.Continuation)
                {
                    this.deleteMore.IsEnabled = true;
                }
                else
                {
                    // Finished: Disable the "Delete More" button
                    this.deleteMore.IsEnabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.ToString()}", "Exception", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
