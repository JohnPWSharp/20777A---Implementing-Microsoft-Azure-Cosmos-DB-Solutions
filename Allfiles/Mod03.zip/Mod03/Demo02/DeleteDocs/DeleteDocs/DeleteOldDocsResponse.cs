﻿using Newtonsoft.Json;

namespace DeleteDocs
{
    class DeleteOldDocsResponse
    {
        [JsonProperty("deleted")]
        public int Deleted { get; set; }

        [JsonProperty("continuation")]
        public bool Continuation { get; set; }

    }
}
