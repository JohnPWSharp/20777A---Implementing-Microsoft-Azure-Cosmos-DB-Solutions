﻿using Newtonsoft.Json;

namespace ProductCatalogPerformance
{
    public abstract class DocumentType
    {
        [JsonProperty("doctype")]
        string DocType { get; set; }

        [JsonProperty("ttl")]
        public int TimeToLive { get; set; } = -1;

        public DocumentType()
        {
            this.DocType = this.GetType().Name;
        }
    }
}
