﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductCatalogPerformance
{
    class Program
    {
        static void Main(string[] args)
        {
            Worker worker = new Worker();
            worker.DoWork().Wait();
        }
    }

    class Worker
    {
        private DocumentClient gatewayClient;
        private DocumentClient directClient;
        private DocumentClient client;
        private string endpointUrl;
        private string primaryKey;
        private string database;
        private string collection;
        private bool enableLogging = true;
        private bool showResults = true;

        public async Task DoWork()
        {
            // Retrieve the configuration settings
            this.endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
            this.primaryKey = ConfigurationManager.AppSettings["PrimaryKey"];
            this.database = ConfigurationManager.AppSettings["Database"];
            this.collection = ConfigurationManager.AppSettings["Collection"];

            // Connect to the Cosmos DB database
            this.gatewayClient = new DocumentClient(new Uri(endpointUrl), primaryKey, new ConnectionPolicy { ConnectionMode = ConnectionMode.Gateway});
            this.directClient = new DocumentClient(new Uri(endpointUrl), primaryKey, new ConnectionPolicy { ConnectionMode = ConnectionMode.Direct });

            this.client = this.gatewayClient;
            

            char action = ' ';
            while (action != 'X')
            {
                try
                {
                    action = displayMenu();
                    Console.WriteLine();
                    switch (action)
                    {
                        case 'A':
                            // Find a specified document by ID
                            await FindProductDocumentByID();
                            break;

                        case 'D':
                            // 
                            await CreateProductHistories();
                            break;

                        case 'H':
                            // 
                            this.showResults = !this.showResults;
                            break;

                        case 'R':
                            // Run an arbitrary query
                            RunAQuery();
                            break;

                        case 'S':
                            // Switch connection methods
                            if (this.client.ConnectionPolicy.ConnectionMode == ConnectionMode.Gateway)
                            {
                                this.client = this.directClient;
                            }
                            else
                            {
                                this.client = this.gatewayClient;
                            }
                            break;

                        case 'T':
                            // Toggle script logging
                            this.enableLogging = !this.enableLogging;
                            break;

                        default:
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"{ex.Message}");
                }
            }
        }



        private char displayMenu()
        {
            Console.WriteLine("Actions");
            Console.WriteLine("=======");
            Console.WriteLine("A: Find a product by ID");
            Console.WriteLine("D: Create product histories");
            Console.WriteLine($"H: Show query results (currently {this.showResults.ToString()})");
            Console.WriteLine("R: Run an arbitrary query");
            Console.WriteLine($"S: Toggle connection method (currently {this.client.ConnectionPolicy.ConnectionMode.ToString()})");
            Console.WriteLine($"T: Toggle script logging (currently {this.enableLogging.ToString()})");
            Console.WriteLine("X: Exit");

            return Char.ToUpper(Console.ReadKey().KeyChar);
        }

        private void YouPressed(char input)
        {
            Console.WriteLine($"You pressed {input.ToString()}");
        }

        private async Task FindProductDocumentByID()
        {
            Console.WriteLine("Enter document ID");
            string id = Console.ReadLine();
            Console.WriteLine("Enter partition key (Subcategory)");
            string pkey = Console.ReadLine();
            Uri docUri = UriFactory.CreateDocumentUri(this.database, this.collection, id);

            var documentResponse = await client.ReadDocumentAsync<Product>(docUri, new RequestOptions { PartitionKey = new PartitionKey(pkey), EnableScriptLogging = this.enableLogging });

            // The Document property of the response contains a typed document
            if (this.showResults)
            {
                Console.WriteLine(JsonConvert.SerializeObject(documentResponse.Document));
                Console.WriteLine();
            }
            
            if (this.enableLogging)
            {
                // Write out request change and request latency
                Console.WriteLine($" Request charge: {documentResponse.RequestCharge} RUs \n Request Latency: {documentResponse.RequestLatency} ms");

                if (documentResponse.RequestDiagnosticsString.Trim().Length > 0)
                {
                    Console.WriteLine($" Diagnostic string: {documentResponse.RequestDiagnosticsString}");
                }

                Console.WriteLine();
            }

        }

        private void RunAQuery()
        {
            Console.WriteLine("Type your query");
            string queryString = Console.ReadLine();
            SqlQuerySpec querySpec = new SqlQuerySpec()
            {
                QueryText = queryString
            };

            FeedOptions queryOptions = new FeedOptions { MaxItemCount = -1, EnableCrossPartitionQuery = true, PopulateQueryMetrics = this.enableLogging };
            OutputProductResult(querySpec, queryOptions);
        }

        private void OutputProductResult(SqlQuerySpec querySpec, FeedOptions queryOptions)
        {
            var productQuery = client.CreateDocumentQuery<dynamic>(UriFactory.CreateDocumentCollectionUri(this.database, this.collection), querySpec, queryOptions).AsDocumentQuery();

            // Create local variables to aggregate metrics
            double requestCharge = 0;
            double indexLookupTime = 0;
            double indexHitRatio = 0;
            double documentLoadTime = 0;
            double runtimeExecutionTimes = 0;
            
            while (productQuery.HasMoreResults)
            {
                var queryResponse = (productQuery.ExecuteNextAsync()).Result;
                // Aggregate metrics
                requestCharge += queryResponse.RequestCharge;
                if (queryResponse.QueryMetrics.Count() > 0)
                {
                    var queryMetrics = queryResponse.QueryMetrics.First().Value;
                    indexLookupTime += queryMetrics.QueryEngineTimes.IndexLookupTime.TotalMilliseconds;
                    indexHitRatio = queryMetrics.IndexHitRatio;
                    documentLoadTime += queryMetrics.QueryEngineTimes.DocumentLoadTime.TotalMilliseconds;
                    runtimeExecutionTimes += queryMetrics.QueryEngineTimes.RuntimeExecutionTimes.TotalTime.TotalMilliseconds;
                }

                if (this.showResults)
                {
                    foreach (var queryDoc in queryResponse)
                    {
                        Console.WriteLine(JsonConvert.SerializeObject(queryDoc));
                        Console.WriteLine();
                    }
                }
            }
            
            if (this.enableLogging)
            {
                Console.WriteLine($"\nQuery: \"{querySpec.QueryText}\"\nConnection method: {client.ConnectionPolicy.ConnectionMode.ToString()}");
                //Display metrics
                Console.WriteLine($"\n Request charge: {requestCharge} RUs\n Index LookUp Time: {indexLookupTime} ms\n Index Hit Ratio: {indexHitRatio * 100}%\n Document Load Time: {documentLoadTime} ms\n Runtime Execution Time: {runtimeExecutionTimes} ms\n");
            }
        }

        private async Task CreateProductHistories()
        {
            SqlQuerySpec querySpec = new SqlQuerySpec()
            {
                QueryText = "SELECT * FROM c WHERE c.doctype = 'ProductWithPriceHistory'"
            };

            FeedOptions queryOptions = new FeedOptions { MaxItemCount = -1, EnableCrossPartitionQuery = true, PopulateQueryMetrics = this.enableLogging };
            var productWithHistoryQuery = client.CreateDocumentQuery<ProductWithHistory>(UriFactory.CreateDocumentCollectionUri(this.database, this.collection), querySpec, queryOptions).AsDocumentQuery();

            while (productWithHistoryQuery.HasMoreResults)
            {
                var queryResponse = (productWithHistoryQuery.ExecuteNextAsync()).Result;
                foreach (var queryDoc in queryResponse)
                {
                    dynamic productHistories = new System.Dynamic.ExpandoObject();
                    productHistories.productid = queryDoc.productid;
                    productHistories.pricehistory = queryDoc.pricehistory;
                    productHistories.doctype = "ProductHistories";
                    productHistories.subcategory = queryDoc.subcategory;

                    var createResponse = await client.CreateDocumentAsync(UriFactory.CreateDocumentCollectionUri(this.database, this.collection), productHistories);
                }
            }
        }
    }
}