﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriceChangePerformanceTester
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter product ID");
            string id = Console.ReadLine();

            double requestChargeUsingTrigger = 0.0;
            double requestChargeWithoutUsingTrigger = 0.0;

            Worker worker = new Worker();
            for (int i = 0; i < 100; i++)
            {
                requestChargeUsingTrigger = worker.DoWork(id, true).Result;         // Use the trigger and get the response including the performance metrics
                requestChargeWithoutUsingTrigger = worker.DoWork(id, false).Result; // Don't use the trigger
            }

            Console.WriteLine($"Total request charge using trigger: {requestChargeUsingTrigger} RUs");
            Console.WriteLine($"Total request charge without using trigger: {requestChargeWithoutUsingTrigger} RUs");
            Console.WriteLine("Press Enter to finish");
            Console.ReadLine();
        }
    }

    class Worker
    {
        private DocumentClient client;
        private string endpointUrl;
        private string primaryKey;
        private string database;
        private string collection;

        // Return the request charge for the operation being performed
        public async Task<double> DoWork(string id, bool useTrigger)
        {
            // Retrieve the configuration settings
            this.endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
            this.primaryKey = ConfigurationManager.AppSettings["PrimaryKey"];
            this.database = ConfigurationManager.AppSettings["Database"];
            this.collection = ConfigurationManager.AppSettings["Collection"];

            // Connect to the Cosmos DB account
            this.client = new DocumentClient(new Uri(endpointUrl), primaryKey);

            try
            {
                // Fetch a Product document                 
                var docUri = UriFactory.CreateDocumentUri(this.database, this.collection, $"{id}");

                var options = new RequestOptions
                {
                    PartitionKey = new PartitionKey(id)
                };

                var documentResponse = await client.ReadDocumentAsync(docUri, options);
                var document = documentResponse.Resource;
                Console.WriteLine(document);
                Console.WriteLine();

                // Update the price
                double oldPrice = double.Parse(document.GetPropertyValue<string>("listprice"));
                double newPrice = oldPrice + 0.5;
                document.SetPropertyValue("listprice", newPrice.ToString());

                // Save the doc back to the collection
                double result = 0.0;
                if (useTrigger)
                {
                    result = await SaveDocumentUsingTrigger(document);
                }
                else
                {
                    result = await SaveDocumentWithoutUsingTrigger(document);
                }
                return result;                
            }
            catch (DocumentClientException dce)
            {
                Console.WriteLine($"{dce.Message}");
                Console.ReadLine();
                return 0.0;
            }
            catch (Exception e)
            {
                Console.WriteLine($"{e.Message}");
                return 0.0;
            }
        }

        // Save the document using the trigger to add the price change history document
        // Return the request charge
        private async Task<double> SaveDocumentUsingTrigger(Document document)
        {
            var options = new RequestOptions
            {
                AccessCondition = new AccessCondition
                {
                    Condition = document.ETag,
                    Type = AccessConditionType.IfMatch
                },
                PreTriggerInclude = new List<string> { "CreatePriceHistoryDocument" }                
            };

            var updateResponse = await client.UpsertDocumentAsync(
                UriFactory.CreateDocumentCollectionUri(this.database, this.collection), document, options);
            Console.WriteLine("Document updated using trigger");
            return updateResponse.RequestCharge;
        }

        // Save the document without using the trigger
        // Create and save the price change history document manually
        // Return the request charge
        private async Task<double> SaveDocumentWithoutUsingTrigger(Document document)
        {
            var options = new RequestOptions
            {
                AccessCondition = new AccessCondition
                {
                    Condition = document.ETag,
                    Type = AccessConditionType.IfMatch
                }
            };

            var updateResponse = await client.UpsertDocumentAsync(
                UriFactory.CreateDocumentCollectionUri(this.database, this.collection), document, options);
            Console.WriteLine("Document updated without using trigger");

            var historyDocument = new Document();
            var priceDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fffffff");
            var productID = document.GetPropertyValue<string>("productid");
            historyDocument.SetPropertyValue("id", $"{productID}:Price:{priceDate}");
            historyDocument.SetPropertyValue("doctype", "ProductHistory");
            historyDocument.SetPropertyValue("subcategory", document.GetPropertyValue<string>("subcategory"));
            historyDocument.SetPropertyValue("productid", productID);
            historyDocument.SetPropertyValue("listprice", document.GetPropertyValue<string>("listprice"));
            historyDocument.SetPropertyValue("pricedate", priceDate);

            var insertResponse = await client.CreateDocumentAsync(
                UriFactory.CreateDocumentCollectionUri(this.database, this.collection), historyDocument);
            Console.WriteLine("History document added");

            return updateResponse.RequestCharge + insertResponse.RequestCharge;
        }
    }
}
