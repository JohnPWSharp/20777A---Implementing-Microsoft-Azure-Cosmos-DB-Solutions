﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace QueryPerformanceTester
{
    class Program
    {
        internal static List<Product> productInfo;
        
        static void Main(string[] args)
        {
            int numWorkers = int.Parse(ConfigurationManager.AppSettings["NumWorkers"]);
            productInfo = getProductInfo();

            var tasks = new List<Task>(numWorkers);
        
            DateTime timeStarted = DateTime.Now;

            for (int i = 0; i < numWorkers; i++)
            {                
                tasks.Add(Task.Run(() => Worker.DoWork(i)));
                Task.Delay(100).Wait();
            }
            Task.WaitAll(tasks.ToArray());

            DateTime timeEnded = DateTime.Now;
            Console.WriteLine($"Run complete: Started at {timeStarted}. Finished at {timeEnded}");
        }

        private static List<Product> getProductInfo()
        {
            using (StreamReader r = new StreamReader("products_only.json"))
            {
                string json = r.ReadToEnd();
                List<Product> products = JsonConvert.DeserializeObject<List<Product>>(json);
                return products;
            }
        }
    }

    internal static class Worker
    {
        private static DocumentClient client;
        private static string endpointUrl;
        private static string primaryKey;
        private static string database;
        private static string collectionPartitionedBySubcategory;
        private static string collectionPartitionedByProductID;
        private static string collectionPartitionedByDocType;
        private static string collectionNotPartitioned;

        private static Random rand = new Random(); // new Random(99); // Seeded for repeatability

        internal static void DoWork(int workerNum)
        {
            endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
            primaryKey = ConfigurationManager.AppSettings["PrimaryKey"];
            database = ConfigurationManager.AppSettings["Database"];
            client = new DocumentClient(new Uri(endpointUrl), primaryKey, new ConnectionPolicy { ConnectionMode = ConnectionMode.Direct});

            collectionPartitionedBySubcategory = ConfigurationManager.AppSettings["Collection"];
            collectionPartitionedByProductID = ConfigurationManager.AppSettings["Collection2"];
            collectionPartitionedByDocType = ConfigurationManager.AppSettings["Collection3"];
            collectionNotPartitioned = ConfigurationManager.AppSettings["Collection4"];

            int numIterations = int.Parse(ConfigurationManager.AppSettings["NumIterations"]);
            for (int i = 0; i < numIterations; i++)
            {
                Console.WriteLine($"Worker{workerNum}, Iteration {i}");
                FindProductDocuments(collectionPartitionedBySubcategory, false);
                FindProductDocuments(collectionPartitionedByProductID, false);
                FindProductDocuments(collectionPartitionedByDocType, true);
                FindProductDocuments(collectionNotPartitioned, false);
            }
        }

        private static void FindProductDocuments(string collection, bool enableCrossPartitionQuery)
        {
            int productIdx = rand.Next(Program.productInfo.Count - 1);

            string queryString = $"SELECT * FROM c WHERE c.subcategory = @subcategory AND c.productid = @productid AND (c.doctype = 'Product' OR c.doctype = 'ProductHistory')";
            SqlParameterCollection parameters = new SqlParameterCollection
            {
                new SqlParameter("@subcategory", Program.productInfo[productIdx].Subcategory),
                new SqlParameter("@productid", Program.productInfo[productIdx].ProductID)
            };

            SqlQuerySpec querySpec = new SqlQuerySpec
            {
                QueryText = queryString,
                Parameters = parameters
            };

            FeedOptions queryOptions = new FeedOptions
            {
                MaxItemCount = -1,
                EnableCrossPartitionQuery = enableCrossPartitionQuery,
                PopulateQueryMetrics = true                
            };
            OutputProductResult(querySpec, queryOptions, collection);
        }
        
        private static void OutputProductResult(SqlQuerySpec querySpec, FeedOptions queryOptions, string collection)
        {
            var productQuery = client.CreateDocumentQuery<dynamic>(UriFactory.CreateDocumentCollectionUri(database, collection), querySpec, queryOptions).AsDocumentQuery();

            // Create local variables to aggregate metrics
            double requestCharge = 0;
            double indexLookupTime = 0;
            double indexHitRatio = 0;
            double documentLoadTime = 0;
            double runtimeExecutionTimes = 0;

            while (productQuery.HasMoreResults)
            {
                var queryResponse = (productQuery.ExecuteNextAsync()).Result;

                // Aggregate metrics
                requestCharge += queryResponse.RequestCharge;
                if (queryResponse.QueryMetrics.Count() > 0)
                {
                    Console.WriteLine($"{queryResponse.Count()} documents found");
                    var queryMetrics = queryResponse.QueryMetrics.First().Value;
                    indexLookupTime += queryMetrics.QueryEngineTimes.IndexLookupTime.TotalMilliseconds;
                    indexHitRatio = queryMetrics.IndexHitRatio;
                    documentLoadTime += queryMetrics.QueryEngineTimes.DocumentLoadTime.TotalMilliseconds;
                    runtimeExecutionTimes += queryMetrics.QueryEngineTimes.RuntimeExecutionTimes.TotalTime.TotalMilliseconds;
                }
            }

            Console.WriteLine($"\nQuery: \"{querySpec.QueryText}\"\nConnection method: {client.ConnectionPolicy.ConnectionMode.ToString()}\nCollection: {collection}");
            Console.WriteLine($"\n Request charge: {requestCharge} RUs\n Index LookUp Time: {indexLookupTime} ms\n Index Hit Ratio: {indexHitRatio * 100}%\n Document Load Time: {documentLoadTime} ms\n Runtime Execution Time: {runtimeExecutionTimes} ms\n");
        }
    }
}
