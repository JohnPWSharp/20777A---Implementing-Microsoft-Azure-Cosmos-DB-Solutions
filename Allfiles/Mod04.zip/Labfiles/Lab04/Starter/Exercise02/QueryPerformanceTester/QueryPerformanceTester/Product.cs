﻿using Newtonsoft.Json;

namespace QueryPerformanceTester
{
    public class ProductCategoryData : DocumentType
    {
        [JsonProperty("subcategory")]
        public string Subcategory { get; set; }

        [JsonProperty("doctype")]
        public string DocType { get; set; }

        [JsonProperty("category")]
        public string Category { get; set; }
    }

    public class ProductDocumentData
    {
        [JsonProperty("documenttitle")]
        public string DocumentTitle { get; set; }

        [JsonProperty("documentsummary")]
        public string DocumentSummary { get; set; }

        [JsonProperty("document")]
        public string Document { get; set; }
    }

    public class ProductImageData
    {
        [JsonProperty("diagram")]
        public string Diagram { get; set; }

        [JsonProperty("thumbnail")]
        public string Thumbnail { get; set; }

        [JsonProperty("largephoto")]
        public string LargePhoto { get; set; }
    }

    public class Product : DocumentType
    {
        [JsonProperty("productid")]
        public string ProductID { get; set; }

        [JsonProperty("subcategory")]
        public string Subcategory { get; set; }

        [JsonProperty("doctype")]
        public string DocType { get; set; }

        [JsonProperty("productcategory")]
        public string Category { get; set; }

        [JsonProperty("productname")]
        public string ProductName { get; set; }

        [JsonProperty("productnumber")]
        public string ProductNumber { get; set; }

        [JsonProperty("color")]
        public string Color { get; set; }

        [JsonProperty("listprice")]
        public decimal ListPrice { get; set; }

        [JsonProperty("size")]
        public string Size { get; set; }

        [JsonProperty("weight")]
        public string Weight { get; set; }

        [JsonProperty("quantityinstock")]
        public int QuantityInStock { get; set; }

        [JsonProperty("model")]
        public string Model { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("documentation")]
        public ProductDocumentData Documentation { get; set; }

        [JsonProperty("images")]
        public ProductImageData Images { get; set; }
    }

    public class ProductHistoryData : DocumentType
    {
        [JsonProperty("id")]
        public string UniqueID { get; set; }

        [JsonProperty("doctype")]
        public string DocType { get; set; }

        [JsonProperty("subcategory")]
        public string subcategory { get; set; }

        [JsonProperty("productid")]
        public string ProductID { get; set; }

        [JsonProperty("listprice")]
        public string ListPrice { get; set; }

        [JsonProperty("pricedate")]
        public string PriceDate { get; set; }
    }

    public class ProductHistory
    {

        [JsonProperty("productid")]
        public string ProductID { get; set; }

        [JsonProperty("listprice")]
        public string ListPrice { get; set; }

        [JsonProperty("pricedate")]
        public string PriceDate { get; set; }
    }


    public class ProductWithHistory : DocumentType
    {
        [JsonProperty("id")]
        public string UniqueID { get; set; }

        [JsonProperty("productId")]
        public string ProductID { get; set; }

        [JsonProperty("subcategory")]
        public string Subcategory { get; set; }

        [JsonProperty("doctype")]
        public string DocType { get; set; }

        [JsonProperty("productcategory")]
        public string Category { get; set; }

        [JsonProperty("productname")]
        public string ProductName { get; set; }

        [JsonProperty("productnumber")]
        public string ProductNumber { get; set; }

        [JsonProperty("color")]
        public string Color { get; set; }

        [JsonProperty("listprice")]
        public decimal ListPrice { get; set; }

        [JsonProperty("size")]
        public string Size { get; set; }

        [JsonProperty("weight")]
        public string Weight { get; set; }

        [JsonProperty("quantityinstock")]
        public int QuantityInStock { get; set; }

        [JsonProperty("model")]
        public string Model { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("pricehistory")]
        public System.Collections.Generic.List<ProductHistory> PriceHistories { get; set; }
    }
}