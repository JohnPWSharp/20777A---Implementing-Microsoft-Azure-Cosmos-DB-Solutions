﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriceChangeTester
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter product ID");
            string id = Console.ReadLine();

            Worker worker = new Worker();
            for (int i = 0; i < 100; i++)
            {
                worker.DoWork(id).Wait();
            }

            Console.WriteLine("Press Enter to finish");
            Console.ReadLine();
        }
    }

    class Worker
    {
        private DocumentClient client;
        private string endpointUrl;
        private string primaryKey;
        private string database;
        private string collection;

        public async Task DoWork(string id)
        {
            // Retrieve the configuration settings
            this.endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
            this.primaryKey = ConfigurationManager.AppSettings["PrimaryKey"];
            this.database = ConfigurationManager.AppSettings["Database"];
            this.collection = ConfigurationManager.AppSettings["Collection"];

            // Connect to the Cosmos DB account
            this.client = new DocumentClient(new Uri(endpointUrl), primaryKey, null, ConsistencyLevel.BoundedStaleness);

            try
            {
                // Fetch a ProductWithPriceHistory document                 
                var docUri = UriFactory.CreateDocumentUri(this.database, this.collection, $"{id}-with-price-history");

                var options = new RequestOptions
                {
                    PartitionKey = new PartitionKey(id)
                };

                var documentResponse = await client.ReadDocumentAsync(docUri, options);
                var document = documentResponse.Resource;
                Console.WriteLine(document);
                Console.WriteLine();

                // Update the price
                double oldPrice = double.Parse(document.GetPropertyValue<string>("listprice"));
                double newPrice = oldPrice + 0.5;
                document.SetPropertyValue("listprice", newPrice.ToString());

                // Save the doc back to the collection
                options = new RequestOptions
                {
                    AccessCondition = new AccessCondition
                    {
                        Condition = document.ETag,
                        Type = AccessConditionType.IfMatch
                    },
                    PreTriggerInclude = new List<string>{ "AddPriceHistoryToDocument" }
                };

                var updateResponse = await client.UpsertDocumentAsync(
                    UriFactory.CreateDocumentCollectionUri(this.database, this.collection), document, options);
                Console.WriteLine("Document updated");

            }
            catch (DocumentClientException dce)
            {
                Console.WriteLine($"{dce.Message}");
                Console.ReadLine();
            }
        }
    }
}
