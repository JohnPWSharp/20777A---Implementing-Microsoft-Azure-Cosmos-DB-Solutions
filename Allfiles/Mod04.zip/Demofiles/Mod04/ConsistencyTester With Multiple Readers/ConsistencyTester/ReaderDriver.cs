﻿using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace ConsistencyTester
{
    internal class ReaderDriver
    {
        private List<string> readRegionNames;
        private int numRegions;

        public void Run()
        {
            // Create an array of tasks for tracking the readers
            Task[] readers = new Task[Globals.numReaders];

            // Create 'numReaders' Readers.
            for (int readerNum = 0; readerNum < Globals.numReaders; readerNum++)
            {
                string readerName = $"Reader {readerNum}";
                string readerRegion = Globals.readerRegion;
                StreamWriter readerOutputStream = new StreamWriter(Path.Combine(Globals.docPath, $"{readerName}.csv"));
                Reader reader = new Reader(readerName, readerRegion, readerOutputStream);
                readers[readerNum] = Task.Run(() => reader.StartReadingAsync());

            }
            // Wait for the readers to complete
            Task.WaitAll(readers);

            // Tell the writer to stop
            Globals.readersFinished = true;
        }
    }
}