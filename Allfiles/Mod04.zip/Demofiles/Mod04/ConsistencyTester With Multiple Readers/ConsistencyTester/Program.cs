﻿using Microsoft.Azure.Documents;
using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace ConsistencyTester
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // Start the readers driver
                var readerDriver = new ReaderDriver();
                Task readerDriverTask = Task.Run(() => readerDriver.Run());

                // Start the writer driver
                var writerDriver = new WriterDriver();
                writerDriver.RunAsync().Wait();

                // Wait for the reader driver to finish
                readerDriverTask.Wait();
            }
            catch (DocumentClientException dce)
            {
                Trace.WriteLine(dce.Message);
            }
            catch (AggregateException e)
            {
                foreach (var i in e.Flatten().InnerExceptions)
                {
                    Trace.WriteLine($"{i.Message}");
                    if (i.InnerException != null)
                    {
                        Trace.WriteLine($"{i.InnerException.Message}");
                    }
                }
            }
        }
    }
}
