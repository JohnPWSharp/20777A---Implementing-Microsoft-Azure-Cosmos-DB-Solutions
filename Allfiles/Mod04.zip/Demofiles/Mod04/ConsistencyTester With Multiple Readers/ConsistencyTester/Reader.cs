﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using System.Linq;
using System;
using System.Diagnostics;
using System.IO;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ConsistencyTester
{
    internal class Reader
    {
        private string readerName;
        private string readerRegion;
        private StreamWriter readerOutputStream;
        private DocumentClient client;
        private Uri dataCollection;

        public Reader(string readerName, string readerRegion, StreamWriter readerOutputStream)
        {
            this.readerName = readerName;
            this.readerRegion = readerRegion;
            this.readerOutputStream = readerOutputStream;

            try
            {
                // Create a client that will connect to the Cosmos DB database in the specified region
                ConnectionPolicy connectionPolicy = new ConnectionPolicy();
                connectionPolicy.PreferredLocations.Add(readerRegion);
                this.client = new DocumentClient(new Uri(Globals.endpointUrl), Globals.primaryKey, connectionPolicy);

                // Get the collection holding the data
                this.dataCollection = UriFactory.CreateDocumentCollectionUri(Globals.database, Globals.collection);
            }
            catch (Exception e)
            {
                Trace.WriteLine($"{readerName} failed with error: {e.Message}");
            }                
        }

        internal async Task StartReadingAsync()
        {
            // Wait for the writer to signal that it is ready
            Trace.WriteLine($"{readerName} waiting");
            var rand = new Random(99);  // Seeded for repeatability

            this.readerOutputStream.WriteLine("Time,Iteration,Name,Writer Read Region,DocID,Value");
            Globals.writerReady.WaitOne();
            await WaitForCollection();

            // Query the data 'numIterations' times
            for (int n = 0; n < Globals.numIterations; n++)
            {
                Trace.WriteLine($"{readerName}: Iteration {n}");

                // Select a doc
                var doc1 = rand.Next(Globals.numDocs);

                // Create a query to retrieve the document
                string queryString = $"SELECT * FROM {Globals.collection} c WHERE c.docid = 'doc{doc1}'";

                var options = new FeedOptions
                {
                    ConsistencyLevel = Globals.GetConsistencyLevel(),
                    SessionToken = Globals.sessionToken
                };

                var query = this.client.CreateDocumentQuery(Globals.collectionUri, queryString, options).AsDocumentQuery();

                // Run the query
                var queryResponse = await query.ExecuteNextAsync();
                var doc = queryResponse.First();

                // Output the results
                var now = DateTime.UtcNow.Ticks;
                this.readerOutputStream.WriteLine($"{now},{n},{this.readerName},{this.readerRegion},{doc.docid},{doc.value}");
                Trace.WriteLine($"Document {doc.docid} read by {this.readerName}, value is {doc.value}");
            }

            this.readerOutputStream.Close();
        }

        internal async Task WaitForCollection()
        {
            // Wait for the new collection to be copied to the local replica
            ResourceResponse<DocumentCollection> collResult = null;
            do
            {
                Trace.WriteLine("Waiting for collection");
                Task.Delay(5000).Wait();
                try
                {
                    collResult = await this.client.ReadDocumentCollectionAsync(Globals.collectionUri);
                }
                catch (Exception)
                {

                }
            }
            while (collResult == null || collResult.StatusCode != System.Net.HttpStatusCode.OK);
        }
    }
}