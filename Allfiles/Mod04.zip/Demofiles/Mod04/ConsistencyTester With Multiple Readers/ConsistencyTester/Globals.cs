﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using System;
using System.Configuration;
using System.Threading;

namespace ConsistencyTester
{
    // Global vars shared by readers and writers
    internal static class Globals
    {
        internal static int numIterations = Int32.Parse(ConfigurationManager.AppSettings["NumIterations"]);
        internal static int numDocs = Int32.Parse(ConfigurationManager.AppSettings["NumDocs"]);
        internal static string docPath = @"E:\Demofiles\Mod04";
        internal static string endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
        internal static string primaryKey = ConfigurationManager.AppSettings["PrimaryKey"];
        internal static string database = ConfigurationManager.AppSettings["Database"];
        internal static string collection = ConfigurationManager.AppSettings["Collection"];
        internal static Uri collectionUri = UriFactory.CreateDocumentCollectionUri(database, collection);
        internal static string writerReadRegion = ConfigurationManager.AppSettings["WriterReadRegion"];
        internal static bool createDocs = (ConfigurationManager.AppSettings["CreateDocs"] == "true");
        internal static int numReaders = Int32.Parse(ConfigurationManager.AppSettings["NumReaders"]);
        internal static string readerRegion = ConfigurationManager.AppSettings["ReaderRegion"];
        internal static ManualResetEvent writerReady = new ManualResetEvent(false);
        internal static bool readersFinished = false;
        internal static string sessionToken = string.Empty;

        internal static ConsistencyLevel GetConsistencyLevel()
        {
            switch (ConfigurationManager.AppSettings["ConsistencyLevel"])
            {
                case "BoundedStaleness": return ConsistencyLevel.BoundedStaleness;
                case "Session": return ConsistencyLevel.Session;
                case "ConsistentPrefix": return ConsistencyLevel.ConsistentPrefix;
                default: return ConsistencyLevel.Eventual;
            }
        }
    }
}
