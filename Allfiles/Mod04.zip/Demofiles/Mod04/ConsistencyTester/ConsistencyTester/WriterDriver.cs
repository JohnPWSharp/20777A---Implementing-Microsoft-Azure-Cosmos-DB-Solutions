﻿using System.IO;
using System.Threading.Tasks;

namespace ConsistencyTester
{
    internal class WriterDriver
    {
        public async Task RunAsync()
        {
            string writerName = $"Writer";
            StreamWriter writerOutputStream = new StreamWriter(Path.Combine(Globals.docPath, $"{writerName}.csv"));
            Writer writer = new Writer(writerName, writerOutputStream);

            if (Globals.createDocs)
            {
                await writer.CreateDataAsync();
            }

            await writer.StartWritingAsync();
        }
    }
}