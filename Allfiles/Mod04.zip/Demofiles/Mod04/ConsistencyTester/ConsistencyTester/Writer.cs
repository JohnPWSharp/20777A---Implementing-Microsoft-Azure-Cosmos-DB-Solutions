﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using Newtonsoft.Json.Linq;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsistencyTester
{
    internal class Writer
    {
        private string writerName;
        private StreamWriter writerOutputStream;
        private DocumentClient client;
        private Uri dataCollection;
        
        public Writer(string writerName, StreamWriter writerOutputStream)
        {
            this.writerName = writerName;
            this.writerOutputStream = writerOutputStream;

            try
            {
                // Create a client that will connect to the Cosmos DB database in the specified region
                ConnectionPolicy connectionPolicy = new ConnectionPolicy();
                connectionPolicy.PreferredLocations.Add(Globals.writerReadRegion);
                this.client = new DocumentClient(new Uri(Globals.endpointUrl), Globals.primaryKey, connectionPolicy);

                // Get the collection holding the data
                this.dataCollection = UriFactory.CreateDocumentCollectionUri(Globals.database, Globals.collection);
            }
            catch (Exception e)
            {
                Trace.WriteLine($"{writerName} failed with error: {e.Message}");
            }
        }

        internal async Task StartWritingAsync()
        {
            Trace.WriteLine($"{writerName} starting");
            var rand = new Random(99);  // Seeded for repeatability

            // Output a header listing the fields at the top of the file recording the work done            
            this.writerOutputStream.WriteLine("Time,Iteration,Name,Writer Read Region,DocID,New Value,Old Values");

            // Iterate 'numIterations' times
            for (int n = 0; n < Globals.numIterations; n++)
            {
                // Select a doc
                var doc1 = rand.Next(Globals.numDocs);
                
                // Create a query to retrieve the document
                string queryString = $"SELECT * FROM {Globals.collection} c WHERE c.docid = 'doc{doc1}'";

                // Repeatedly run the query until the data retrieved stabilizes
                dynamic prevValue = null, currentValue = null, doc = null;
                StringBuilder versions = new StringBuilder();
                do
                {
                    var options = new FeedOptions
                    {
                        ConsistencyLevel = Globals.GetConsistencyLevel()
                    };
                    var query = this.client.CreateDocumentQuery(Globals.collectionUri, queryString, options).AsDocumentQuery();
                    var queryResponse = await query.ExecuteNextAsync();
                    
                    // Get the doc
                    doc = queryResponse.First();

                    // Save the value from the doc and record the "version" history for each iteration of the query
                    prevValue = currentValue;
                    currentValue = doc.value;

                    if (currentValue != prevValue)
                    {
                        versions.Append($",{currentValue}");
                    }
                }
                while (currentValue != prevValue);
                
                // Update the value in the doc
                doc.value++;
                                
                try
                {
                    // Save the doc
                    ResourceResponse<Document> upsertResponse = await this.client.UpsertDocumentAsync(Globals.collectionUri, doc);

                    // Record the stats
                    var now = DateTime.UtcNow.Ticks;
                    this.writerOutputStream.WriteLine($"{now},{n},{this.writerName},{Globals.writerReadRegion},{doc.docid},{doc.value}{versions.ToString()}");
                    Trace.WriteLine($"Document {doc.docid} updated, new value is {doc.value}");
                }
                catch (AggregateException e)
                {
                    foreach (var i in e.Flatten().InnerExceptions)
                    {
                        Trace.WriteLine($"{i.Message}");
                        if (i.InnerException != null)
                        {
                            Trace.WriteLine($"{i.InnerException.Message}");
                        }
                    }
                    Trace.WriteLine($"Reading from: {this.client.ReadEndpoint}, writing to: {this.client.WriteEndpoint}");
                }
            }            
            this.writerOutputStream.Close();
        }

        internal async Task CreateDataAsync()
        {
            Trace.WriteLine($"{writerName} dropping existing collection");
            try
            {
                await this.client.DeleteDocumentCollectionAsync(Globals.collectionUri);
            }
            catch (Exception)
            {
                // Ignore any exceptions - the collection might not exist
            }

            Trace.WriteLine($"{writerName} creating new collection");
            await this.client.CreateDocumentCollectionAsync(UriFactory.CreateDatabaseUri(Globals.database),
                new DocumentCollection
                {
                    Id = Globals.collection
                },
                new RequestOptions
                {
                    OfferThroughput = 2000,
                    ConsistencyLevel = Globals.GetConsistencyLevel()
                });

            await WaitForCollection();

            // Create n test  documents, with fields "docid" and "value". Give each document an initial value of 0
            for (int n = 0; n < Globals.numDocs; n++)
            {
                Trace.WriteLine($"{writerName} adding document {n}");
                var doc = new JObject();
                doc.Add("docid", $"doc{n}");
                doc.Add($"value", 0);

                // Save the doc to the database
                Trace.WriteLine($"Saving doc {doc}");
                await this.client.UpsertDocumentAsync(Globals.collectionUri, doc);
            }
        }

        internal async Task WaitForCollection()
        {
            // Wait for the new collection to be copied to the local replica
            ResourceResponse<DocumentCollection> collResult = null;
            do
            {
                Trace.WriteLine("Waiting for collection");
                Task.Delay(5000).Wait();
                try
                {
                    collResult = await this.client.ReadDocumentCollectionAsync(Globals.collectionUri);
                }
                catch (Exception)
                {

                }
            }
            while (collResult == null || collResult.StatusCode != System.Net.HttpStatusCode.OK);
        }
    }
}