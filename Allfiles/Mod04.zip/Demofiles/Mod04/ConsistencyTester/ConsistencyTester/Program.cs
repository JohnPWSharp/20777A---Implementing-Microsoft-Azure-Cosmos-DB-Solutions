﻿using Microsoft.Azure.Documents;
using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace ConsistencyTester
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // Start the writer driver
                var writerDriver = new WriterDriver();
                writerDriver.RunAsync().Wait();
            }
            catch (DocumentClientException dce)
            {
                Trace.WriteLine(dce.Message);
            }
            catch (AggregateException e)
            {
                foreach (var i in e.Flatten().InnerExceptions)
                {
                    Trace.WriteLine($"{i.Message}");
                    if (i.InnerException != null)
                    {
                        Trace.WriteLine($"{i.InnerException.Message}");
                    }
                }
            }
        }
    }
}
