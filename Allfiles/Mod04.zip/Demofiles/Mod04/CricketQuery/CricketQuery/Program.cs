﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Linq;
using System;
using System.Configuration;
using System.Diagnostics;
using System.Threading.Tasks;

namespace CricketQuery
{
    class Program
    {
        static void Main(string[] args)
        {
            string endpointURL = ConfigurationManager.AppSettings.Get("EndpointUrl");
            string key = ConfigurationManager.AppSettings.Get("PrimaryKey");

            Console.WriteLine("Which mode? (1 = Single thread with complete metrics, 2 = Multiple threads with elapsed times only)");
            ConsoleKeyInfo mode = Console.ReadKey();
            Console.WriteLine();

            while (mode.KeyChar != '1' && mode.KeyChar != '2')
            {
                mode = Console.ReadKey();
                Console.WriteLine();
            }

            Console.WriteLine($"mode {mode.KeyChar} selected. Please wait ...");

            int numWorkers = (mode.KeyChar == '1') ? 1 : int.Parse(ConfigurationManager.AppSettings.Get("NumWorkers"));
            bool printMode = false;
            bool.TryParse(ConfigurationManager.AppSettings.Get("PrintMode"), out printMode);

            Queries.Initialize(endpointURL, key);

            // start 'numWorker' readers
            Task[] tasks = new Task[numWorkers];
            for (int workerCount = 0; workerCount < numWorkers; workerCount++)
            {
                tasks[workerCount] = Task.Run(() => {
                    Worker worker = new Worker();
                    worker.DoWork(mode.KeyChar, printMode);
                });
            }

            Task.WaitAll(tasks);
        }
    }

    internal class Worker
    {
        internal void DoWork(char mode, bool printMode)
        {
            try
            {
                IDocumentQuery<dynamic> data = null;
                foreach (var collection in Queries.collections)
                {

                    TextWriterTraceListener traceListener = new TextWriterTraceListener($@"{ConfigurationManager.AppSettings.Get("TraceFolder")}\{collection}.txt");
                    Trace.Listeners.Add(traceListener);

                    Trace.WriteLine("");
                    Trace.WriteLine("");
                    Trace.WriteLine($"Performance stats using collection {collection}");
                    Trace.WriteLine("=====================================================================");
                    Trace.WriteLine("");
                    Trace.WriteLine("");

                    data = Queries.FindByHomeTeam("England", "T20", collection);
                    Process(data, printMode, mode, "Find T20 games for England at home");

                    // Repeat each query to reduce the effects of warm-up, caching, etc
                    data = Queries.FindByHomeTeam("England", "T20", collection);
                    Process(data, printMode, mode, "Find T20 games for England at home");

                    data = Queries.FindByAwayTeam("England", "T20", collection);
                    Process(data, printMode, mode, "Find T20 games for England away");

                    data = Queries.FindByAwayTeam("England", "T20", collection);
                    Process(data, printMode, mode, "Find T20 games for England away");

                    data = Queries.FindByTeams("England", "Australia", "ODI", collection);
                    Process(data, printMode, mode, "Find ODIs played in England between England and Australia");

                    data = Queries.FindByTeams("England", "Australia", "ODI", collection);
                    Process(data, printMode, mode, "Find ODIs played in England between England and Australia");

                    data = Queries.FindByCity("Nottingham", collection);
                    Process(data, printMode, mode, "Find all games played in Nottingham");

                    data = Queries.FindByCity("Nottingham", collection);
                    Process(data, printMode, mode, "Find all games played in Nottingham");

                    data = Queries.FindByMatchType("T20", collection);
                    Process(data, printMode, mode, "Find all T20 games");

                    data = Queries.FindByMatchType("T20", collection);
                    Process(data, printMode, mode, "Find all T20 games");

                    Trace.WriteLine("");
                    Trace.WriteLine("");
                    Trace.Listeners.Remove(traceListener);
                }
            }
            catch (DocumentClientException dce)
            {
                Trace.WriteLine(dce.Message);
            }
            catch (AggregateException e)
            {
                foreach (var i in e.Flatten().InnerExceptions)
                {
                    Trace.WriteLine($"{i.Message}");
                    if (i.InnerException != null)
                    {
                        Trace.WriteLine($"{i.InnerException.Message}");
                    }
                }
            }
        }

        private void Process(IDocumentQuery<dynamic> data, bool print, char mode, string message)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            while (data.HasMoreResults)
            {
                var records = data.ExecuteNextAsync().Result;
                foreach (var record in records)
                {
                    if (print)
                        Trace.WriteLine($"{record}\n");
                }

                if (mode == '1')
                {
                    var metrics = records.QueryMetrics;
                    Trace.WriteLine($"Query: {message}");
                    Trace.WriteLine("---------------------------------------------------------------");
                    Trace.WriteLine("");
                    foreach (var metric in metrics)
                    {
                        Trace.WriteLine($"{metric}");
                    }
                    Trace.WriteLine("");
                    Trace.WriteLine("");
                }
            }
            sw.Stop();
            if (mode == '2')
            {
                Trace.WriteLine($"Query: {message}, Elapsed Time: {sw.ElapsedMilliseconds} ms");
            }
        }
    }
}
