﻿using Microsoft.Azure.Documents.Linq;
using System;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using System.Timers;

namespace CricketQuery
{
    class Program
    {
        private static bool printMode = false;
        private static int workerNum = 0;
        private static int maxWorkers;
        internal static int numErrors = 0;
        private static Timer timer = new Timer();

        static void Main(string[] args)
        {
            string endpointURL = ConfigurationManager.AppSettings.Get("EndpointUrl");
            string key = ConfigurationManager.AppSettings.Get("PrimaryKey");
            maxWorkers = int.Parse(ConfigurationManager.AppSettings.Get("MaxWorkers"));
            bool.TryParse(ConfigurationManager.AppSettings.Get("PrintMode"), out printMode);

            Queries.Initialize(endpointURL, key);

            // Start an auto-repeating timer that starts an instance of the worker
            timer.Interval = int.Parse(ConfigurationManager.AppSettings.Get("TimerInterval"));
            timer.Elapsed += RunWorker;
            timer.AutoReset = true;
            timer.Enabled = true;

            Console.WriteLine("Press the Enter key to exit the program at any time... ");
            Console.ReadLine();            
        }

        private static void RunWorker(Object source, ElapsedEventArgs e)
        {
            if (++workerNum > maxWorkers)
            {
                timer.Enabled = false;
                Task.Delay(60000).Wait();
                Trace.WriteLine($"Error count {numErrors}");
                Environment.Exit(0);
            }
            else
            {
                Worker worker = new Worker(workerNum);
                worker.DoWork(printMode);
            }
        }
    }

    internal class Worker
    {
        private int workerNum;
        private StreamWriter outputStream;

        internal Worker(int workerNum)
        {
            Trace.WriteLine($"Starting worker {workerNum}");
            this.workerNum = workerNum;
            outputStream = new StreamWriter(Path.Combine(@"E:\Demofiles\Mod04", $"{Queries.collection}-{Queries.GetConsistencyLevel()}-worker{workerNum}.txt"));
            outputStream.WriteLine("Execution Time\tResponse Time\tNumber of Docs\tTotal Size\tCharge\tBurst Throughput\tQuery");
        }

        internal void DoWork(bool printMode)
        {            
            IDocumentQuery<dynamic> data = null;

            try
            {
                data = Queries.FindByHomeTeam("England", "T20");
                Process(data, printMode, $"Worker {this.workerNum}: Find T20 games for England at home");
                data = Queries.FindByHomeTeam("England", "T20");
                Process(data, printMode, $"Worker {this.workerNum}: Find T20 games for England at home");

                data = Queries.FindByAwayTeam("England", "T20");
                Process(data, printMode, $"Worker {this.workerNum}: Find T20 games for England away");
                data = Queries.FindByAwayTeam("England", "T20");
                Process(data, printMode, $"Worker {this.workerNum}: Find T20 games for England away");

                data = Queries.FindByTeams("England", "Australia", "ODI");
                Process(data, printMode, $"Worker {this.workerNum}: Find ODIs played in England between England and Australia");
                data = Queries.FindByTeams("England", "Australia", "ODI");
                Process(data, printMode, $"Worker {this.workerNum}: Find ODIs played in England between England and Australia");

                data = Queries.FindByCity("Nottingham");
                Process(data, printMode, $"Worker {this.workerNum}: Find all games played in Nottingham");
                data = Queries.FindByCity("Nottingham");
                Process(data, printMode, $"Worker {this.workerNum}: Find all games played in Nottingham");

                data = Queries.FindByMatchType("T20");
                Process(data, printMode, $"Worker {this.workerNum}: Find all T20 games");
                data = Queries.FindByMatchType("T20");
                Process(data, printMode, $"Worker {this.workerNum}: Find all T20 games");
            }

            catch (AggregateException e)
            {
                foreach (var ex in e.Flatten().InnerExceptions)
                {
                    Trace.WriteLine($"{ex.Message}");
                    if (ex.InnerException != null)
                    {
                        Trace.WriteLine($"{ex.InnerException.Message}");
                    }
                }
                Program.numErrors++;
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex.Message);
                Program.numErrors++;
            }
            
            this.outputStream.Close();
        }

        private void Process(IDocumentQuery<dynamic> data, bool print, string message)
        {
            var executionTimeMS = 0.0;
            var charge = 0.0;
            var numDocs = 0L;
            var docsSize = 0L;

            Stopwatch stopwatch = new Stopwatch();
            while (data.HasMoreResults)
            {
                stopwatch.Start();
                var records = data.ExecuteNextAsync().Result;
                stopwatch.Stop();
                if (print)
                {
                    foreach (var record in records)
                    {

                        Trace.WriteLine($"{record}\n");
                    }
                }

                charge += records.RequestCharge;
                var metrics = records.QueryMetrics;

                foreach (var metric in metrics)
                {
                    executionTimeMS += metric.Value.TotalTime.TotalMilliseconds;

                    numDocs += metric.Value.RetrievedDocumentCount;
                    docsSize += metric.Value.RetrievedDocumentSize;
                }
            }

            Trace.WriteLine($"Query: {message}, Execution Time: {executionTimeMS} ms, Response Time: {stopwatch.ElapsedMilliseconds} ms, Number of Docs: {numDocs}, Total Size: {docsSize}, Charge: {charge} RU, Burst Throughput: {charge/executionTimeMS*1000} RU/s");
            this.outputStream.WriteLine($"{executionTimeMS}\t\t{stopwatch.ElapsedMilliseconds}\t\t{numDocs}\t\t{docsSize}\t\t{charge}\t{charge / executionTimeMS * 1000}\t{message}");
        }
    }
}
