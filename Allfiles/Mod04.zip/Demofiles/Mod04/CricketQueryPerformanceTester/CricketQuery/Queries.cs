﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using System;
using System.Configuration;

namespace CricketQuery
{
    internal static class Queries
    {
        private static DocumentClient client;
        private static FeedOptions queryOptions = new FeedOptions { MaxItemCount = -1, EnableCrossPartitionQuery = true, MaxDegreeOfParallelism = -1, PopulateQueryMetrics = true, EnableScanInQuery = true, ConsistencyLevel = GetConsistencyLevel() };
        private static string database = ConfigurationManager.AppSettings.Get("Database");

        internal static string collection = ConfigurationManager.AppSettings.Get("Collection");

        internal static void Initialize(string endpointURL, string key)
        {
            client = new DocumentClient(new Uri(endpointURL), key, new ConnectionPolicy
            {
                RetryOptions = new RetryOptions
                {
                    MaxRetryAttemptsOnThrottledRequests = Int32.Parse(ConfigurationManager.AppSettings.Get("MaxQueryRetries")),
                    MaxRetryWaitTimeInSeconds = Int32.Parse(ConfigurationManager.AppSettings.Get("MaxQueryRetryWaitTime"))
                }
            });
        }

        internal static IDocumentQuery<dynamic> FindByHomeTeam(string homeTeam, string matchType)
        {
            return client.CreateDocumentQuery<dynamic>(
                UriFactory.CreateDocumentCollectionUri(database, collection), new SqlQuerySpec
                {
                    QueryText = $"SELECT c.info FROM c WHERE c.info.hometeam = @homeTeam AND c.info.match_type = @matchType",
                    Parameters = new SqlParameterCollection()
                    {
                        new SqlParameter("@homeTeam", homeTeam),
                        new SqlParameter("@matchType", matchType)
                    }
                }, queryOptions).AsDocumentQuery();
        }

        internal static IDocumentQuery<dynamic> FindByAwayTeam(string awayTeam, string matchType)
        {
            return client.CreateDocumentQuery<dynamic>(
                UriFactory.CreateDocumentCollectionUri(database, collection), new SqlQuerySpec
                {
                    QueryText = $"SELECT c.info FROM c WHERE c.info.awayteam = @awayTeam AND c.info.match_type = @matchType",
                    Parameters = new SqlParameterCollection()
                    {
                        new SqlParameter("@awayTeam", awayTeam),
                        new SqlParameter("@matchType", matchType)
                    }
                }, queryOptions).AsDocumentQuery();
        }

        internal static IDocumentQuery<dynamic> FindByTeams(string homeTeam, string awayTeam, string matchType)
        {
            return client.CreateDocumentQuery<dynamic>(
                UriFactory.CreateDocumentCollectionUri(database, collection), new SqlQuerySpec
                {
                    QueryText = $"SELECT c.info FROM c WHERE c.info.hometeam = @homeTeam AND c.info.awayteam = @awayTeam AND c.info.match_type = @matchType",
                    Parameters = new SqlParameterCollection()
                    {
                        new SqlParameter("@homeTeam", homeTeam),
                        new SqlParameter("@awayTeam", awayTeam),
                        new SqlParameter("@matchType", matchType)
                    }
                }, queryOptions).AsDocumentQuery();
        }

        internal static IDocumentQuery<dynamic> FindByCity(string city)
        {
            return client.CreateDocumentQuery<dynamic>(
                UriFactory.CreateDocumentCollectionUri(database, collection), new SqlQuerySpec
                {
                    QueryText = $"SELECT c.info FROM c WHERE c.info.city = @city",
                    Parameters = new SqlParameterCollection()
                    {
                        new SqlParameter("@city", city)
                    }
                }, queryOptions).AsDocumentQuery();
        }

        internal static IDocumentQuery<dynamic> FindByMatchType(string matchType)
        {
            return client.CreateDocumentQuery<dynamic>(
                UriFactory.CreateDocumentCollectionUri(database, collection), new SqlQuerySpec
                {
                    QueryText = $"SELECT c.info FROM c WHERE c.info.match_type = @matchType",
                    Parameters = new SqlParameterCollection()
                    {                        
                        new SqlParameter("@matchType", matchType)
                    }
                }, queryOptions).AsDocumentQuery();
        }
        
        internal static ConsistencyLevel GetConsistencyLevel()
        {
            switch (ConfigurationManager.AppSettings["ConsistencyLevel"])
            {
                case "Strong": return ConsistencyLevel.Strong;
                case "BoundedStaleness": return ConsistencyLevel.BoundedStaleness;
                case "Session": return ConsistencyLevel.Session;
                case "ConsistentPrefix": return ConsistencyLevel.ConsistentPrefix;
                default: return ConsistencyLevel.Eventual;
            }
        }
    }
}
