﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PlaceOrders
{
    // Constants shared throughout the app

    public static class Constants
    {
        public const string SHOPPINGCART = "ShoppingCart";
        public const string ORDER = "Order";
        public const string INPROGRESS = "In progress";
        public const string DELIVERED = "Delivered";
        public const string CANCELLED = "Cancelled";

        // Method that converts from ticks (stored in date/time fields in the database) into a readable date/time string
        public static string TicksToDate(long ticks)
        {
            if (ticks < 0)
            {
                throw new Exception("ticks must be non-negative");
            }

            // Create a Date object using the number of milliseconds
            var tickDateTime = new DateTime(ticks);

            // Return the Date as a readble string, formatted using the current locale
            return tickDateTime.ToString();
        }
    }
}