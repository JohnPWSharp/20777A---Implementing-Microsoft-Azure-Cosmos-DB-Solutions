

object Options {
    // Change options to match your configuration
  val Endpoint = "https://eh01.documents.azure.com:443/"
  val MasterKey = "nmSmULxMenmuz3Mwten35Zr4udFKdbdKA1bltWLSnbT3Un57hgFDMWxmpP2VGYwKf19z5lZIcLXDlhE1YrhHrA=="
  val Database = "flightdelays"
  val ReadCollection = "delaydata"
  val WriteCollection = "delaysbyselectedairline"
  val AppName = "FlightAnalysisApp"
}