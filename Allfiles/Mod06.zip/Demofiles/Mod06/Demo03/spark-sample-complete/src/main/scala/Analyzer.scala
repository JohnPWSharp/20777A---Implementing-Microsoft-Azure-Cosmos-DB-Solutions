import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import com.microsoft.azure.cosmosdb.spark.config._
import com.microsoft.azure.cosmosdb.spark.schema._
import org.apache.spark.sql._

object Analyzer {
     def main (arg: Array[String]): Unit = {
       
       // Configure the connection for reading from the database
       val sqlConfig = Config(Map("Endpoint" -> Options.Endpoint,
         "Masterkey" -> Options.MasterKey,
         "Database" -> Options.Database,
         "Collection" -> Options.ReadCollection,
         "SamplingRatio" -> "1.0"))

       // Create collection connection
       val sqlContext = SparkSession.builder().appName(Options.AppName).getOrCreate()
       val dfReader = sqlContext.read
       val collection = dfReader.cosmosDB(sqlConfig)
       collection.createOrReplaceTempView("c")

       // Run a query
       val query = "SELECT c.Year, c.Month, c.DayOfMonth, c.Origin, c.Dest, c.UniqueCarrier, c.ArrDelay, c.DepDelay, c.CarrierDelay, c.WeatherDelay, c.nASDelay, c.SecurityDelay, c.LateAircraftDelay FROM c WHERE c.UniqueCarrier = 'AA'"
       val data = sqlContext.sql(query)

       // DO SOME OTHERS AS PER THE LAB DESIGN DOC
       
       // Save the results in another collection (overwrite the collection if it already exists)
       val writeConfig = Config(Map("Endpoint" -> Options.Endpoint,
         "Masterkey" -> Options.MasterKey,
         "Database" -> Options.Database,
         "Collection" -> Options.WriteCollection,
         "WritingBatchSize" -> "100"))
       data.write.cosmosDB(writeConfig)
     } 
}