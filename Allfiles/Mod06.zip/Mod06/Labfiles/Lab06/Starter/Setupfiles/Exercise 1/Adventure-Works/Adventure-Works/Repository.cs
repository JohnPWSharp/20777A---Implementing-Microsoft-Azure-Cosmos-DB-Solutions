﻿using Adventure_Works.Models;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Threading.Tasks;

// TODO: Add namespaces containing Search functionality



namespace Adventure_Works
{
    public static class Repository<T> where T : DocumentType
    {
        private static string endpointUrl;
        private static string primaryKey;
        private static string database;
        private static string collection;
        private static DocumentClient client;

        // TODO: Define fields to support connecting to the Azure Search Service


        public static void Initialize(string coll)
        {
            endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
            primaryKey = ConfigurationManager.AppSettings["PrimaryKey"];
            database = ConfigurationManager.AppSettings["Database"];
            collection = coll;
            client = new DocumentClient(new Uri(endpointUrl), primaryKey);

            // TODO: Initialize the connection to the Azure Search Service
            
        }

        public static async Task<IEnumerable<T>> GetAllItemsAsync()
        {
            // Find all documents in the collection
            // Additionally, qualify the type of the document to ensure that only those that match the type parameter "T" are retrieved
            IDocumentQuery<T> query = client.CreateDocumentQuery<T>(
                UriFactory.CreateDocumentCollectionUri(database, collection),
                new FeedOptions { EnableCrossPartitionQuery = true })
                .Where(t => t.DocType == typeof(T).Name)
                .AsDocumentQuery();

            // Return the documents as a list
            List<T> results = new List<T>();
            while (query.HasMoreResults)
            {
                results.AddRange(await query.ExecuteNextAsync<T>());
            }

            return results;
        }

        public static async Task<IEnumerable<T>> GetItemsAsync(Expression<Func<T, bool>> predicate)
        {
            // Find all documents in the collection that match the predicate
            // Additionally, qualify the type of the document to ensure that only those that match the type parameter "T" are retrieved
            IDocumentQuery<T> query = client.CreateDocumentQuery<T>(
                UriFactory.CreateDocumentCollectionUri(database, collection),
                new FeedOptions { EnableCrossPartitionQuery = true })
                .Where(predicate).Where(t => t.DocType == typeof(T).Name)
                .AsDocumentQuery();

            // Return the matching documents as a list
            List<T> results = new List<T>();
            while (query.HasMoreResults)
            {
                results.AddRange(await query.ExecuteNextAsync<T>());
            }

            return results;
        }

        // TODO: Use Azure Search to find items that match the specified search string
        public static async Task<IEnumerable<T>> SearchForItemsAsync(string searchString, bool advanced)
        {
            // TODO: If this is not an advanced query, enclose the search string in quotes to ensure that Azure Search treats it as a literal rather than a query expression
            
            // TODO:  Specify that the search should only return the id and partitionkey fields of the document from the index
            
            // TODO: Find the ids of all documents that match the search string
            
            // TODO: Iterate through the results, and construct a list of matching documents from the Cosmos DB database
            List<T> docs = new List<T>();
            foreach (var result in searchResults.Results)
            {
                // TODO: Construct the document URI for the document 
            
                // TODO: Extract the partition key from the index
            
                // TODO: Fetch the document and add it to the list
            
            }

            // TODO: Return the list of documents identified by the search
            throw new NotImplementedException();
        }

        // TODO: Use Azure Search to suggest items from the index that match a specified search term
        public static async Task<List<string>> GetSuggestions(string term)
        {
            // TODO: Specify the Suggestion parameters: enable fuzzy searching, fetch the top 10 results, and add highlighting
           
            // TODO: Retrieve suggestions from the Azure Search service
            
            // TODO: Return the suggestions as a list of strings
            throw new NotImplementedException();            
        }

        public static async Task<bool> CreateItemAsync(T item, int ttl = -1)
        {
            // Add the new document to the collection, and set the TTL
            Uri collectionUri = UriFactory.CreateDocumentCollectionUri(database, collection);
            item.TimeToLive = ttl;
            var response = await client.CreateDocumentAsync(collectionUri, item);

            // Examine the status of the response, to determine whether the document was created successfully or not
            return response.StatusCode ==  HttpStatusCode.Created;
        }

        public static async Task<int> IncrementNumericValueInDocumentAsync(string docID, string property, int value, string partitionKey = null)
        {
            // Fetch the doc to be updated
            Uri docUri = UriFactory.CreateDocumentUri(database, collection, docID);
            var options = partitionKey == null ? null : new RequestOptions
            {
                PartitionKey = new PartitionKey(partitionKey)
            };

            var response = await client.ReadDocumentAsync(docUri, options);
            var doc = response.Resource;

            // Change the value of the specified property
            var propVal = doc.GetPropertyValue<int>(property);
            propVal += value;
            doc.SetPropertyValue(property, propVal);

            // Attempt to write the modified document back to the database
            // If another user modifies the same doc at the same time, this code will throw an exception back to the caller where it should be handled
            options = new RequestOptions
            {
                AccessCondition = new Microsoft.Azure.Documents.Client.AccessCondition
                {
                    Condition = doc.ETag,
                    Type = AccessConditionType.IfMatch
                }
            };
            response = await client.ReplaceDocumentAsync(doc.SelfLink, doc, options);

            // Return the new value of the property that was updated
            return propVal;
        }
    
        // Insert/update an item in the collection and optionally provide lists of pre- and post-triggers to run
        public static async Task<bool> UpsertItemAsync(T item, List<string> preTriggers = null, List<string> postTriggers = null, int ttl = -1)
        {
            // Obtain the Uri of the collection
            Uri collectionUri = UriFactory.CreateDocumentCollectionUri(database, collection);

            // Set the TTL of the document
            item.TimeToLive = ttl;

            // Specify the triggers to be invoked (if any)
            var options = new RequestOptions
            {
                PreTriggerInclude = preTriggers,
                PostTriggerInclude = postTriggers
            };

            // Add/replace the document in the collection and invoke the triggers
            var response = await client.UpsertDocumentAsync(collectionUri, item, options);

            // Examine the status of the response, to determine whether the document was created/updated successfully or not
            return response.StatusCode == HttpStatusCode.Created || 
                   response.StatusCode == HttpStatusCode.OK;
        }

        // Run a stored procedure against the collection
        public static async Task<dynamic> ExecuteStoredProcAsync(string storedProc, string partitionKey = null, params dynamic[] paramList)
        {
            // Get the URI of the stored procedure
            Uri storedProcUri = UriFactory.CreateStoredProcedureUri(database, collection, storedProc);

            // Specify the partition identified by the partitionKey parameter
            var options = partitionKey == null ? null : new RequestOptions
            {
                PartitionKey = new PartitionKey(partitionKey)
            };

            // Run the stored procedure
            var storedProcResults = await client.ExecuteStoredProcedureAsync<dynamic>(storedProcUri, options, paramList);

            // Pass back the results of the stored procedure
            return storedProcResults.Response;
        }
    }
}