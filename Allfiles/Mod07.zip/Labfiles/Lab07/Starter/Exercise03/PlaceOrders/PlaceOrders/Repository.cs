﻿using Microsoft.Azure.CosmosDB.BulkExecutor;
using Microsoft.Azure.CosmosDB.BulkExecutor.BulkImport;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Threading.Tasks;


namespace PlaceOrders
{
    public static class Repository<T> where T : DocumentType
    {
        private static string endpointUrl;
        private static string primaryKey;
        private static string database;
        private static string collection;
        private static DocumentClient client;

        public static void Initialize(string coll)
        {
            endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
            primaryKey = ConfigurationManager.AppSettings["PrimaryKey"];
            database = ConfigurationManager.AppSettings["Database"];
            collection = coll;
            client = new DocumentClient(new Uri(endpointUrl), primaryKey);
        }

        public static async Task<IEnumerable<T>> GetAllItemsAsync()
        {
            // Find all documents in the collection
            // Additionally, qualify the type of the document to ensure that only those that match the type parameter "T" are retrieved
            IDocumentQuery<T> query = client.CreateDocumentQuery<T>(
                UriFactory.CreateDocumentCollectionUri(database, collection),
                new FeedOptions { EnableCrossPartitionQuery = true })
                .Where(t => t.DocType == typeof(T).Name)
                .AsDocumentQuery();

            // Return the documents as a list
            List<T> results = new List<T>();
            while (query.HasMoreResults)
            {
                results.AddRange(await query.ExecuteNextAsync<T>());
            }

            return results;
        }

        public static async Task<IEnumerable<T>> GetItemsAsync(Expression<Func<T, bool>> predicate)
        {
            // Find all documents in the collection that match the predicate
            // Additionally, qualify the type of the document to ensure that only those that match the type parameter "T" are retrieved
            IDocumentQuery<T> query = client.CreateDocumentQuery<T>(
                UriFactory.CreateDocumentCollectionUri(database, collection),
                new FeedOptions { EnableCrossPartitionQuery = true })
                .Where(predicate).Where(t => t.DocType == typeof(T).Name)
                .AsDocumentQuery();

            // Return the matching documents as a list
            List<T> results = new List<T>();
            while (query.HasMoreResults)
            {
                results.AddRange(await query.ExecuteNextAsync<T>());
            }

            return results;
        }

        public static async Task<bool> CreateItemAsync(T item, int ttl = -1)
        {
            // Add the new document to the collection, and set the TTL
            Uri collectionUri = UriFactory.CreateDocumentCollectionUri(database, collection);
            item.TimeToLive = ttl;
            var response = await client.CreateDocumentAsync(collectionUri, item);

            // Examine the status of the response, to determine whether the document was created successfully or not
            return response.StatusCode ==  HttpStatusCode.Created;
        }

        public static async Task<bool> DeleteAllItemAsync()
        {
            // Note: This method only works for orders
            if (typeof(T).Name != "ShoppingCartOrder")
            {
                return false;
            }

            try
            {
                IDocumentQuery<T> query = client.CreateDocumentQuery<T>(
                    UriFactory.CreateDocumentCollectionUri(database, collection),
                    new FeedOptions { EnableCrossPartitionQuery = true })
                    .Where(t => t.DocType == typeof(T).Name)
                    .AsDocumentQuery();

                while (query.HasMoreResults)
                {
                    var batch = await query.ExecuteNextAsync<T>();
                    foreach (var item in batch)
                    {
                        Uri documentUri = UriFactory.CreateDocumentUri(database, collection, (item as dynamic).ShoppingCartOrderID);
                        Console.WriteLine($"Deleting document {documentUri}");
                        await client.DeleteDocumentAsync(
                            documentUri,
                            new RequestOptions
                            {
                                PartitionKey = new PartitionKey((item as dynamic).CustomerID)
                            });
                    }
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static async Task<int> IncrementNumericValueInDocumentAsync(string docID, string property, int value, string partitionKey = null)
        {
            // Fetch the doc to be updated
            Uri docUri = UriFactory.CreateDocumentUri(database, collection, docID);
            var options = partitionKey == null ? null : new RequestOptions
            {
                PartitionKey = new PartitionKey(partitionKey)
            };

            var response = await client.ReadDocumentAsync(docUri, options);
            var doc = response.Resource;

            // Change the value of the specified property
            var propVal = doc.GetPropertyValue<int>(property);
            propVal += value;
            doc.SetPropertyValue(property, propVal);

            // Attempt to write the modified document back to the database
            // If another user modifies the same doc at the same time, this code will throw an exception back to the caller where it should be handled
            options = new RequestOptions
            {
                AccessCondition = new AccessCondition
                {
                    Condition = doc.ETag,
                    Type = AccessConditionType.IfMatch
                }
            };
            response = await client.ReplaceDocumentAsync(doc.SelfLink, doc, options);

            // Return the new value of the property that was updated
            return propVal;
        }
    
        // Insert/update an item in the collection and optionally provide lists of pre- and post-triggers to run
        public static async Task<bool> UpsertItemAsync(T item, List<string> preTriggers = null, List<string> postTriggers = null, int ttl = -1)
        {
            // Obtain the Uri of the collection
            Uri collectionUri = UriFactory.CreateDocumentCollectionUri(database, collection);

            // Set the TTL of the document
            item.TimeToLive = ttl;

            // Specify the triggers to be invoked (if any)
            var options = new RequestOptions
            {
                PreTriggerInclude = preTriggers,
                PostTriggerInclude = postTriggers
            };

            // Add/replace the document in the collection and invoke the triggers
            var response = await client.UpsertDocumentAsync(collectionUri, item, options);

            // Examine the status of the response, to determine whether the document was created/updated successfully or not
            return response.StatusCode == HttpStatusCode.Created || 
                   response.StatusCode == HttpStatusCode.OK;
        }

        // Run a stored procedure against the collection
        public static async Task<dynamic> ExecuteStoredProcAsync(string storedProc, string partitionKey = null, params dynamic[] paramList)
        {
            // Get the URI of the stored procedure
            Uri storedProcUri = UriFactory.CreateStoredProcedureUri(database, collection, storedProc);

            // Specify the partition identified by the partitionKey parameter
            var options = partitionKey == null ? null : new RequestOptions
            {
                PartitionKey = new PartitionKey(partitionKey)
            };

            // Run the stored procedure
            var storedProcResults = await client.ExecuteStoredProcedureAsync<dynamic>(storedProcUri, options, paramList);

            // Pass back the results of the stored procedure
            return storedProcResults.Response;
        }

        // Bulk upload the documents in the specified list to the database
        public static async Task BulkUploadAsync(List<T> data)
        {
            DocumentCollection docCollection = client.CreateDocumentCollectionQuery(UriFactory.CreateDatabaseUri(database))
                    .Where(c => c.Id == collection).AsEnumerable().FirstOrDefault();
            IBulkExecutor bulkExecutor = new BulkExecutor(client, docCollection);
            await bulkExecutor.InitializeAsync();
            BulkImportResponse bulkImportResponse = null;
            do
            {
                bulkImportResponse = await bulkExecutor.BulkImportAsync(
                                    documents: data,
                                    enableUpsert: true,
                                    disableAutomaticIdGeneration: true,
                                    maxConcurrencyPerPartitionKeyRange: null,
                                    maxInMemorySortingBatchSize: null);
            }
            while (bulkImportResponse.NumberOfDocumentsImported < data.Count);
        }
    }
}