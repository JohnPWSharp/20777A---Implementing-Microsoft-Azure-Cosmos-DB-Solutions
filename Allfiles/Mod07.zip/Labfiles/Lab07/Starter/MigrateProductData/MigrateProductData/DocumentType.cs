﻿using Newtonsoft.Json;

namespace MigrateProductData
{
    public abstract class DocumentType
    {
        [JsonProperty("doctype")]
        public string DocType { get; set; }

        [JsonProperty("ttl")]
        public int TimeToLive { get; set; } = -1;

        public DocumentType()
        {
            this.DocType = this.GetType().Name;
        }
    }
}
