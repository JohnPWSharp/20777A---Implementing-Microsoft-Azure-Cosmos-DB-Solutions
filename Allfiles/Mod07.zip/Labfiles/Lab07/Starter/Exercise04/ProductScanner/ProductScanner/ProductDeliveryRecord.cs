﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;

namespace ProductScanner
{
    // Document structure for recording product deliveries
    class ProductDeliveryRecord
    {
        [JsonProperty("id")]
        public string ID { get; set; }

        [JsonProperty("productnumber")]
        public string ProductNumber { get; set; }

        [JsonProperty("volumedelivered")]
        public int Volume { get; set; }

        [JsonProperty("time")]
        public DateTime Time { get; set; }

        public override string ToString()
        {
            return $"Product: {ProductNumber}, Volume: {Volume}, Time: {Time}";
        }
    }
}
