﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.Devices.Client;
using Newtonsoft.Json;
using System.Configuration;
using System.Diagnostics;
using System.IO;

namespace ProductScanner
{
    class Program
    {
        static void Main(string[] args)
        {
            // Retrieve the configuration settings
            string deviceConnectionString = ConfigurationManager.AppSettings["DeviceConnectionString"];
            string deviceID = ConfigurationManager.AppSettings["DeviceID"];
            DeviceClient client = null;

            // Retrieve and cache product numbers
            List<string> productNumbers = getProductNumbers();

            try
            {
                // Connect to the IoT hub
                client = DeviceClient.CreateFromConnectionString($"{deviceConnectionString};DeviceId={deviceID}", TransportType.Mqtt);
            }
            catch (Exception e)
            {
                Trace.WriteLine($"Device {deviceID} failed with error: {e.Message}");
            }

            Random rnd = new Random();

            while (true)
            {
                try
                {
                    // Create a product delivery record
                    var deliveryRecord = new ProductDeliveryRecord
                    {
                        ID = Guid.NewGuid().ToString(),
                        ProductNumber = productNumbers[rnd.Next(0, productNumbers.Count - 1)],
                        Volume = rnd.Next(1, 100),
                        Time = DateTime.UtcNow
                    };

                    Trace.TraceInformation($"{deliveryRecord.ToString()}");

                    // Send the reading to the IoT hub
                    var messageString = JsonConvert.SerializeObject(deliveryRecord);
                    var message = new Message(Encoding.ASCII.GetBytes(messageString));
                    Task.Run(() => client.SendEventAsync(message)).Wait();

                    // Sleep for a five seconds before generating the next product delivery record
                    Task.Delay(5000).Wait();
                }
                catch (Exception e)
                {
                    Trace.TraceError($"Error recording product delivery: {e.Message}");
                }
            }
        }

        // Read the product numbers from the ProductNumbers.txt file and save them in a list
        private static List<string> getProductNumbers()
        {
            var productNumbers = new List<string>();
            var file = new StreamReader("ProductNumbers.txt");
            string line;
            while ((line = file.ReadLine()) != null)
            {
                productNumbers.Add(line);
            }

            return productNumbers;
        }
    }
}
