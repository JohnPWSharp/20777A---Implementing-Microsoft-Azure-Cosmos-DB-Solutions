﻿using Newtonsoft.Json;

namespace Warehouse
{
    public class OrderItem
    {
        // Define properties
        [JsonProperty("productnumber")]
        public string ProductNumber { get; set; }

        [JsonProperty("productname")]
        public string ProductName { get; set; }

        [JsonProperty("productid")]
        public string ProductID { get; set; }

        [JsonProperty("subcategory")]
        public string Subcategory { get; set; }

        [JsonProperty("numberincartorordered")]
        public int NumberInCartOrOrdered { get; set; }

        [JsonProperty("numberonbackorder")]
        public int NumberOnBackorder { get; set; }

        [JsonProperty("backorderreference")]
        public string BackorderReference { get; set; }

        [JsonProperty("unitcost")]
        public decimal UnitCost { get; set; }

        [JsonProperty("lineitemtotalcost")]
        public decimal LineItemTotalCost { get; set; }

        public override string ToString()
        {
            return $"Product: {ProductNumber} - {ProductName}, Number Ordered: {NumberInCartOrOrdered}, Number on Backorder: {NumberOnBackorder}";
        }
    }
}