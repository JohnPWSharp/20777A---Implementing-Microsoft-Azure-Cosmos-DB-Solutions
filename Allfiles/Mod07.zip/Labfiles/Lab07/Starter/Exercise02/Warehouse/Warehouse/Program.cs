﻿using Microsoft.Azure.ServiceBus;
using System;
using System.Configuration;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft;
using Newtonsoft.Json;

namespace Warehouse
{
    class Program
    {
        // Create a client that listens for incoming messages on the warehouse queue
        static QueueClient queueClient = new QueueClient(ConfigurationManager.AppSettings["ServiceBusConnectionString"], ConfigurationManager.AppSettings["WarehouseQueue"]);

        static void Main(string[] args)
        {
            Console.WriteLine("Messages Sent to Warehouse:");
            Console.WriteLine();

            // Register a handler for the warehouse queue
            queueClient.RegisterMessageHandler(ProcessWarehouseMessagesAsync, new MessageHandlerOptions(ExceptionReceivedHandler)
            {
                AutoComplete = false,
                MaxConcurrentCalls = 1
            });

            // Wait for messages to appear on the queue. They will be processed by the message handler
            Console.WriteLine("Press Enter to finish ...");
            Console.ReadLine();
        }

        // Handle any exceptions that might occur when receiving messages
        private static Task ExceptionReceivedHandler(ExceptionReceivedEventArgs exceptionReceivedEventArgs)
        {
            Console.WriteLine($"Message handler encountered an exception {exceptionReceivedEventArgs.Exception}.");
            var context = exceptionReceivedEventArgs.ExceptionReceivedContext;
            Console.WriteLine("Exception context for troubleshooting:");
            Console.WriteLine($"- Endpoint: {context.Endpoint}");
            Console.WriteLine($"- Entity Path: {context.EntityPath}");
            Console.WriteLine($"- Executing Action: {context.Action}");
            return Task.CompletedTask;
        }

        // Process messages as they appear on the warehouse queue
        private static async Task ProcessWarehouseMessagesAsync(Message warehouseMessage, CancellationToken token)
        {
            // Process the message.

            // Convert the message body into a string (it is received as an array of bytes)
            string rawWarehouseMessage = Encoding.UTF8.GetString(warehouseMessage.Body);

            // Deserialize the JSON content into an OrderItem object
            var orderItem = JsonConvert.DeserializeObject<OrderItem>(rawWarehouseMessage);

            // Display the order item
            Console.WriteLine($"Received message: {orderItem}");
            Console.WriteLine();

            // Complete the message so that it is not received again.
            await queueClient.CompleteAsync(warehouseMessage.SystemProperties.LockToken);
        }
    }
}
