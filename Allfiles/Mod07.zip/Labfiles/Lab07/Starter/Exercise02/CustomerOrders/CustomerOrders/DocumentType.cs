﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerOrders
{
    // Base class for all root document types
    public abstract class DocumentType
    {
        // doctype distinugishes the different types of documents in the same collection
        [JsonProperty("doctype")]
        public string DocType { get; set; }

        // ttl of document. By default, ttl is disabled, but can be changed by setting it to a positive integer value (number of seconds)
        [JsonProperty("ttl")]
        public int TimeToLive { get; set; } = -1;

        public DocumentType()
        {
            // Initialize the doctype property
            this.DocType = this.GetType().Name;
        }
    }
}
