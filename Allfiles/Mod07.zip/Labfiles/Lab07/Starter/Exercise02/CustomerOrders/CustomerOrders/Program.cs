﻿using Microsoft.Azure.ServiceBus;
using Newtonsoft.Json;
using System;
using System.Configuration;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CustomerOrders
{
    class Program
    {
        // Create a client that listens for incoming messages on the warehouse queue
        static QueueClient queueClient = new QueueClient(ConfigurationManager.AppSettings["ServiceBusConnectionString"], ConfigurationManager.AppSettings["CustomerOrdersQueue"]);

        static void Main(string[] args)
        {
            Console.WriteLine("Messages Sent to Customer Orders Department:");
            Console.WriteLine();

            // Register a handler for the customer orders department queue
            queueClient.RegisterMessageHandler(ProcessCustomerOrdersMessagesAsync, new MessageHandlerOptions(ExceptionReceivedHandler)
            {
                AutoComplete = false,
                MaxConcurrentCalls = 1
            });

            // Wait for messages to appear on the queue. They will be processed by the message handler
            Console.WriteLine("Press Enter to finish ...");
            Console.ReadLine();
        }

        // Handle any exceptions that might occur when receiving messages
        private static Task ExceptionReceivedHandler(ExceptionReceivedEventArgs exceptionReceivedEventArgs)
        {
            Console.WriteLine($"Message handler encountered an exception {exceptionReceivedEventArgs.Exception}.");
            var context = exceptionReceivedEventArgs.ExceptionReceivedContext;
            Console.WriteLine("Exception context for troubleshooting:");
            Console.WriteLine($"- Endpoint: {context.Endpoint}");
            Console.WriteLine($"- Entity Path: {context.EntityPath}");
            Console.WriteLine($"- Executing Action: {context.Action}");
            return Task.CompletedTask;
        }

        // Process messages as they appear on the customer orders department queue
        private static async Task ProcessCustomerOrdersMessagesAsync(Message customerOrdersMessage, CancellationToken token)
        {
            // Process the message.

            // Convert the message body into a string (it is received as an array of bytes)
            string rawCustomerOrdersMessage = Encoding.UTF8.GetString(customerOrdersMessage.Body);

            // Deserialize the JSON content into an OrderItem object
            var order = JsonConvert.DeserializeObject<ShoppingCartOrder>(rawCustomerOrdersMessage);

            // Display the order
            Console.WriteLine($"Received message: {order}");
            Console.WriteLine();

            // Complete the message so that it is not received again.
            await queueClient.CompleteAsync(customerOrdersMessage.SystemProperties.LockToken);
        }
    }
}

