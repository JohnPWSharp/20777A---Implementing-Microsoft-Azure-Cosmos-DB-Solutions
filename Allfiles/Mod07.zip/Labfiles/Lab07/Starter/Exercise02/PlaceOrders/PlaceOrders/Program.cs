﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;

namespace PlaceOrders
{
    class Program
    {
        private static List<Product> products;
        private static List<Customer> customers;

        static void Main(string[] args)
        {
            // Create repositories
            Repository<Customer>.Initialize(ConfigurationManager.AppSettings["Collection"]);
            Repository<Product>.Initialize(ConfigurationManager.AppSettings["Collection"]);
            Repository<ShoppingCartOrder>.Initialize(ConfigurationManager.AppSettings["Collection"]);

            // Cache data in memory
            customers = Repository<Customer>.GetAllItemsAsync().Result.ToList();
            products = Repository<Product>.GetAllItemsAsync().Result.ToList();

            Task.Run(() => GenerateOrders());
            Console.WriteLine("Press Enter to stop ...");
            Console.ReadLine();
        }
         
        public static void GenerateOrders()
        { 
            // Generate orders
            Random rand = new Random();
            while (true)
            {
                int customerIndex = rand.Next(customers.Count); // Pick a customer at random
                Customer cust = customers[customerIndex];
                Console.WriteLine($"Generating order for {cust.CustomerName.FirstName} {cust.CustomerName.LastName}");

                ShoppingCartOrder order = new ShoppingCartOrder
                {
                    ShoppingCartOrderID = Guid.NewGuid().ToString(),
                    CustomerID = cust.CustomerID,
                    IsShoppingCartOrOrder = Constants.ORDER,
                    DatePlaced = DateTime.Now.Ticks, 
                    LastUpdated = DateTime.Now.Ticks,
                    CustomerDiscountRate = cust.DiscountRate,
                    OrderStatus = Constants.INPROGRESS,
                    OrderItems = new List<OrderItem>()
                };

                decimal orderCost = 0;
                int numOrderItems = rand.Next(10) + 1; // Up to 10 items per order
                for (int o = 0; o < numOrderItems; o++)
                {
                    int productIndex = rand.Next(products.Count); // Pick a product at random
                    Product prod = products[productIndex];
                    int numOrdered = rand.Next(5) + 1;
                    OrderItem orderItem = new OrderItem
                    {
                        ProductID = prod.ProductID,
                        ProductName = prod.ProductName,
                        ProductNumber = prod.ProductNumber,
                        Subcategory = prod.Subcategory,
                        UnitCost = prod.ListPrice,
                        NumberInCartOrOrdered = numOrdered,
                        LineItemTotalCost = numOrdered * prod.ListPrice,
                        BackorderReference = String.Empty,
                        NumberOnBackorder = 0
                    };

                    order.OrderItems.Add(orderItem);
                    orderCost += orderItem.LineItemTotalCost;
                }

                order.ItemsCost = orderCost;
                order.TotalCost = orderCost * (100 - cust.DiscountRate) / 100;
                order.NumberOfItems = numOrderItems;
                Repository<ShoppingCartOrder>.CreateItemAsync(order).Wait();
                Task.Delay(500).Wait();
            }
        }
    }
}
