﻿using System;
using System.Configuration;
using System.Diagnostics;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.Devices.Client;
using Newtonsoft.Json;

namespace CosmosDBDeviceDataCapture
{
    class TemperatureDevice
    {
        private DeviceClient client;
        private string deviceName;

        public TemperatureDevice(string deviceName)
        {
            this.deviceName = deviceName;

            // Retrieve the configuration settings
            string deviceConnectionString = ConfigurationManager.AppSettings["DeviceConnectionString"];
            string deviceID = ConfigurationManager.AppSettings["DeviceID"];

            try
            {
                // Connect to the IoT hub
                this.client = DeviceClient.CreateFromConnectionString($"{deviceConnectionString};DeviceId={deviceID}", TransportType.Mqtt);
            }
            catch (Exception e)
            {
                Trace.WriteLine($"Device {deviceName} failed with error: {e.Message}");
            }
        }

        // Generate temperature events and write them to the IoT hub
        internal async void RecordTemperatures()
        {
            Random rnd = new Random();

            while (true)
            {
                try
                {
                    // Create a temperature readings
                    ThermometerReading reading = new ThermometerReading
                    {
                        ID = Guid.NewGuid().ToString(),
                        DeviceID = this.deviceName,
                        Temperature = rnd.NextDouble() * 100,
                        Time = DateTime.UtcNow.Ticks
                    };

                    Trace.TraceInformation($"Recording: {reading.ToString()}");

                    // Send the reading to the IoT hub
                    var messageString = JsonConvert.SerializeObject(reading);
                    var message = new Message(Encoding.ASCII.GetBytes(messageString));
                    await this.client.SendEventAsync(message);

                    // Sleep for a couple of seconds before generating the next reading
                    await Task.Delay(2000);
                }
                catch (Exception e)
                {
                    Trace.TraceError($"Error recording temperature event: {e.Message}");
                }
            }
        }
    }
}
