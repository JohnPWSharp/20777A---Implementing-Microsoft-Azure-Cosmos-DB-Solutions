﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using System;
using System.Configuration;
using System.Diagnostics;
using System.Security.Authentication;
using System.Threading.Tasks;

namespace CosmosDBDeviceDataCapture
{
    class TemperatureDevice
    {
        private DocumentClient client;
        private Uri temperatureCollection;
        private string deviceName;

        public TemperatureDevice(string deviceName)
        {
            this.deviceName = deviceName;

            // Retrieve the configuration settings
            string endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
            string primaryKey = ConfigurationManager.AppSettings["PrimaryKey"];
            string database = ConfigurationManager.AppSettings["Database"];
            string collection = ConfigurationManager.AppSettings["Collection"];

            try
            {
                // Connect to the Cosmos DB database
                this.client = new DocumentClient(new Uri(endpointUrl), primaryKey);

                // Get the collection holding temperature readings
                this.temperatureCollection = UriFactory.CreateDocumentCollectionUri(database, collection);
            }
            catch (Exception e)
            {
                Trace.WriteLine($"Device {deviceName} failed with error: {e.Message}");
            }
        }

        // Generate temperature events and write them to the collection in the database
        internal async void RecordTemperatures()
        {
            Random rnd = new Random();

            while (true)
            {
                try
                {
                    // Create a temperature readings
                    ThermometerReading reading = new ThermometerReading
                    {
                        DeviceID = this.deviceName,
                        Temperature = rnd.NextDouble() * 100,
                        Time = DateTime.UtcNow.Ticks
                    };

                    Trace.TraceInformation($"Recording: {reading.ToString()}");

                    // Write the reading to the database
                    await this.client.CreateDocumentAsync(this.temperatureCollection, reading);

                    // Sleep for a couple of seconds before generating the next reading
                    await Task.Delay(2000);
                }
                catch (Exception e)
                {
                    Trace.TraceError($"Error recording temperature event: {e.Message}");
                }
            }
        }
    }
}
