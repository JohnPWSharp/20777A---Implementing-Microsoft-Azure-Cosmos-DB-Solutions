﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Adventure_Works.Models
{
    public class ProductCategoryData : DocumentType
    {
        [JsonProperty("partitionkey")]
        public string Subcategory { get; set; }

        [JsonProperty("category")]
        public string Category { get; set; }
    }

    public class ProductDocumentData
    {
        [JsonProperty("documenttitle")]
        public string DocumentTitle { get; set; }

        [JsonProperty("documentsummary")]
        public string DocumentSummary { get; set; }

        [JsonProperty("document")]
        public string Document { get; set; }
    }

    public class ProductImageData
    {
        [JsonProperty("diagram")]
        public string Diagram { get; set; }

        [JsonProperty("thumbnail")]
        public string Thumbnail { get; set; }

        [JsonProperty("largephoto")]
        public string LargePhoto { get; set; }
    }

    public class Product : DocumentType
    {
        [JsonProperty("id")]
        public string ProductID { get; set; }

        [JsonProperty("partitionkey")]
        public string Subcategory { get; set; }

        [JsonProperty("productcategory")]
        public string Category { get; set; }

        [JsonProperty("productname")]
        public string ProductName { get; set; }

        [JsonProperty("productnumber")]
        public string ProductNumber { get; set; }

        [JsonProperty("color")]
        public string Color { get; set; }

        [JsonProperty("listprice")]
        public decimal ListPrice { get; set; }

        [JsonProperty("size")]
        public string Size { get; set; }

        [JsonProperty("weight")]
        public string Weight { get; set; }

        [JsonProperty("quantityinstock")]
        public int QuantityInStock { get; set; }

        [JsonProperty("model")]
        public string Model { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("documentation")]
        public ProductDocumentData Documentation { get; set; }

        [JsonProperty("images")]
        public ProductImageData Images { get; set; }

        [JsonProperty("recommendations")]
        public List<Product> Recommendations { get; set; }
    }

    public class ProductBackorder : DocumentType
    {
        [JsonProperty("id")]
        public string BackorderID { get; set; }

        [JsonProperty("partitionkey")]
        public string Subcategory { get; set; }

        [JsonProperty("customerid")]
        public string CustomerID { get; set; }

        [JsonProperty("productid")]
        public string ProductID { get; set; }

        [JsonProperty("productname")]
        public string ProductName { get; set; }

        [JsonProperty("productnumber")]
        public string ProductNumber { get; set; }

        [JsonProperty("numberonbackorder")]
        public int NumberOnBackorder { get; set; }

        [JsonProperty("backorderstatus")]
        public string BackorderStatus { get; set; }  // "In progress", "Delivered", "Cancelled"

        [JsonProperty("backorderdate")]
        public long BackorderDate { get; set; } // Stored as ticks
    }
}