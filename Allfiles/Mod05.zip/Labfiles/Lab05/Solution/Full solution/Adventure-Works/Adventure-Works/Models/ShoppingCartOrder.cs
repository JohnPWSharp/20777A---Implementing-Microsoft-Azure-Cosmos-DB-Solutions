﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Adventure_Works.Models
{
    public class OrderItem
    {
        // Define properties
        [JsonProperty("productnumber")]
        public string ProductNumber { get; set; }

        [JsonProperty("productname")]
        public string ProductName { get; set; }

        [JsonProperty("productid")]
        public string ProductID { get; set; }

        [JsonProperty("subcategory")]
        public string Subcategory { get; set; }

        [JsonProperty("numberincartorordered")]
        public int NumberInCartOrOrdered { get; set; }

        [JsonProperty("numberonbackorder")]
        public int NumberOnBackorder { get; set; }

        [JsonProperty("backorderreference")]
        public string BackorderReference { get; set; }

        [JsonProperty("unitcost")]
        public decimal UnitCost { get; set; }

        [JsonProperty("lineitemtotalcost")]
        public decimal LineItemTotalCost { get; set; }

    }

    public class ShoppingCartOrder : DocumentType
    {
        // Define properties
        [JsonProperty("id")]
        public string ShoppingCartOrderID { get; set; }

        [JsonProperty("partitionkey")]
        public string CustomerID { get; set; }

        [JsonProperty("isshoppingcartororder")]
        public string IsShoppingCartOrOrder { get; set; }

        [JsonProperty("orderitems")]
        public List<OrderItem> OrderItems { get; set; }

        [JsonProperty("numberofitems")]
        public int NumberOfItems { get; set; }

        [JsonProperty("itemscost")]
        public decimal ItemsCost { get; set; }

        [JsonProperty("customerdiscountrate")]
        public int CustomerDiscountRate { get; set; } // Indicates % discount 

        [JsonProperty("totalcost")]
        public decimal TotalCost { get; set; }

        [JsonProperty("dateplaced")]
        public long DatePlaced { get; set; } // Stored as ticks

        [JsonProperty("orderstatus")]
        public string OrderStatus { get; set; } // "In progress", "Delivered", "Cancelled"

        [JsonProperty("lastupdated")]
        public long LastUpdated { get; set; } // Also stored as ticks

        [JsonProperty("recommendations")]
        public List<Product> Recommendations { get; set; }
    }
}