﻿using Adventure_Works.Models;
using Microsoft.Azure.Documents;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace Adventure_Works.Controllers
{

    public class ShoppingCartController : Controller
    {
        #region helper methods for managing shopping carts
        private ShoppingCartOrder GetShoppingCartForCustomer(Customer customer)
        {
            // Retrieve the shopping cart from cache, or create a new one if the cart is not cached
            var shoppingCart = Session["shoppingCart"] as ShoppingCartOrder;
            if (shoppingCart == null)
            {
                shoppingCart = new ShoppingCartOrder
                {
                    CustomerID = (Session["customer"] as Customer).CustomerID,
                    IsShoppingCartOrOrder = Constants.SHOPPINGCART,
                    OrderItems = new List<OrderItem>(),
                    ShoppingCartOrderID = Guid.NewGuid().ToString(),
                };
            }

            return shoppingCart;
        }
        #endregion

        [ActionName("ViewCart")]
        [HttpGet]
        public async Task<ActionResult> ViewCartAsync()
        {
            // Check whether the user has logged in
            if (Session["customer"] == null)
            {
                // If not, then get them to log in
                Session["ReturnData"] = new { ReturnURL = "ViewCart", Controller = "ShoppingCart" };
                return View("Login");
            }

            // Retrieve the shopping cart for the customer
            var shoppingCart = GetShoppingCartForCustomer(Session["customer"] as Customer);

            // Initialize recommendations - as we may not have any order items
            shoppingCart.Recommendations = new List<Product>();
            
            // Get some recommendations
            if (shoppingCart.OrderItems.Count > 0)
            {
                foreach (OrderItem lineItem in shoppingCart.OrderItems)
                {
                    shoppingCart.Recommendations = await Recommendations.GetReccomendationsAsync(lineItem.ProductID);
                    // Break when we have some recommendations to show
                    if (shoppingCart.Recommendations.Count() > 0) break;
                }
            }
            
            // Display the shopping cart
            return View(shoppingCart);
        }

        // Method called when the user wishes to add a product to their shopping cart
        // The details of the product are cached in the session by the view - Session["selectedProduct"]
        [ActionName("AddItemToShoppingCart")]
        [HttpGet] // Must be a "GET" to support the redirect from the "Login" method
        public async Task<ActionResult> AddItemToShoppingCartAsync(int numRequired = 1)
        {
            // Check whether the user has logged in
            if (Session["customer"] == null)
            {
                // If not, then get them to log in
                Session["numRequired"] = numRequired;
                Session["ReturnData"] = new { ReturnURL = "AddItemToShoppingCart", Controller = "ShoppingCart" };
                return View("Login");
            }

            // Retrieve the shopping cart for the customer
            var shoppingCart = GetShoppingCartForCustomer(Session["customer"] as Customer);

            // Get the product details from the session
            var product = Session["selectedProduct"] as Product;

            // If the value of numRequired was previously cached, then the user has been asked to log in by this action
            // In this case, retrieve the cached value, otherwise continue to use the value passed in as the parameter
            if (Session["numRequired"] != null)
            {
                numRequired = (int)Session["numRequired"];
            }

            // Add the item to the shopping cart
            // First check to see whether the customer has already added this item to the cart previously
            var existingOrderItem = (from o in shoppingCart.OrderItems
                                     where o.ProductID == product.ProductID
                                     select o).FirstOrDefault();

            if (existingOrderItem != null)
            {
                // The item already exists in the shopping cart, so just update the order item
                existingOrderItem.NumberInCartOrOrdered += numRequired;
            }
            else
            {
                // Otherwise add a new order item to the shopping cart
                shoppingCart.OrderItems.Add(new OrderItem
                {
                    ProductID = product.ProductID,
                    ProductName = product.ProductName,
                    ProductNumber = product.ProductNumber,
                    Subcategory = product.Subcategory,
                    NumberInCartOrOrdered = numRequired
                });
            }

            // Save the shopping cart using the repository, and then cache it in the session
            // Set the TTL to 7 days. Note that TTL must be enabled at the collection level for this to work
            if (await Repository<ShoppingCartOrder>.UpsertItemAsync(shoppingCart, ttl: 60 * 60 * 24 * 7))
            {
                Session["shoppingCart"] = shoppingCart;

                // Inform the user that the item has been added to the cart
                TempData["itemMessage"] = "Item added to shopping cart";
            }
            else
            {
                // If the upsert failed, then inform the user that the item has not been added to the shopping cart
                TempData["itemMessage"] = "Item not added to shopping cart";
            }


            // Remove numRequired from the Session cache
            Session.Remove("numRequired");

            // Go back to the ViewCart page to enable the customer to view and update the shopping cart if necessary
            return RedirectToAction("ViewCart", "ShoppingCart");
        }

        // Method that updates the number required for the specified product in the customer's shopping cart
        [ActionName("EditShoppingCartItem")]
        [HttpPost]
        public async Task<ActionResult> EditShoppingCartItemAsync(string productID, int numRequired)
        {
            // Retrieve the customer's shopping cart from the session
            var shoppingCart = Session["shoppingCart"] as ShoppingCartOrder;

            // Check that the cart actually exists in the cache
            if (shoppingCart != null)
            {
                var existingOrderItem = (from o in shoppingCart.OrderItems
                                         where o.ProductID == productID
                                         select o).FirstOrDefault();

                // Sanity check to ensure that the item exists as an order line
                if (existingOrderItem != null)
                {
                    // Update the order item
                    existingOrderItem.NumberInCartOrOrdered = numRequired;

                    // Save the updated order
                    if (await Repository<ShoppingCartOrder>.UpsertItemAsync(shoppingCart, ttl: 60 * 60 * 24 * 7))
                    {
                        // Inform the user that the item has been changed
                        TempData["itemMessage"] = "Quantity updated";
                    }
                    else
                    {
                        // If the upsert failed, then inform the user that the item has not been changed
                        TempData["itemMessage"] = "Quantity not updated";
                    }
                }
                else
                {
                    TempData["itemMessage"] = "Item not found in shopping cart";
                }
            }
            else
            {
                // If the shopping cart was not found in cache, then something has gone wrong
                TempData["itemMessage"] = "Shopping cart not found. Please log in again";

                // Remove the customer data from the session. This will cause the customer to be prompted to log in again
                Session.Remove("customer");
            }

            // Go back to the ViewCart page
            return RedirectToAction("ViewCart", "ShoppingCart");
        }

        // Method that removes an order item from the customer's shopping cart
        [ActionName("DeleteShoppingCartItem")]
        [HttpPost]
        public async Task<ActionResult> DeleteShoppingCartItemAsync(string productID)
        {
            // Retrieve the customer's shopping cart from the session
            var shoppingCart = Session["shoppingCart"] as ShoppingCartOrder;

            // Check that the cart actually exists in the cache
            if (shoppingCart != null)
            {
                var existingOrderItem = (from o in shoppingCart.OrderItems
                                         where o.ProductID == productID
                                         select o).FirstOrDefault();

                // Sanity check to ensure that the item exists as an order line
                if (existingOrderItem != null)
                {
                    // Remove the order item
                    shoppingCart.OrderItems.Remove(existingOrderItem);

                    // Save the updated order
                    if (await Repository<ShoppingCartOrder>.UpsertItemAsync(shoppingCart, ttl: 60 * 60 * 24 * 7))
                    {
                        // Inform the user that the item has been removed
                        TempData["itemMessage"] = "Item removed";
                    }
                    else
                    {
                        // If the upsert failed, then inform the user that the item has not been changed
                        TempData["itemMessage"] = "Order not updated";
                    }
                }
                else
                {
                    TempData["itemMessage"] = "Item not found in shopping cart";
                }
            }
            else
            {
                // If the shopping cart was not found in cache, then something has gone wrong
                TempData["itemMessage"] = "Shopping cart not found. Please log in again";

                // Remove the customer data from the session. This will cause the customer to be prompted to log in again
                Session.Remove("customer");
            }

            // Go back to the ViewCart page
            return RedirectToAction("ViewCart", "ShoppingCart");
        }

        // Method that creates an order from the customer's shopping cart
        [ActionName("PlaceOrder")]
        [HttpPost]
        public async Task<ActionResult> PlaceOrderAsync()
        {
            // Retrieve the customer's shopping cart from the session
            var shoppingCart = Session["shoppingCart"] as ShoppingCartOrder;

            // Check that the cart actually exists in the cache
            if (shoppingCart != null)
            {
                // Create a dictionary for tracking whether backorders are created (if insufficient stock is currently available for any order item)
                var backorderDetails = new Dictionary<string, string>();

                try
                {
                    foreach (var item in shoppingCart.OrderItems)
                    {
                        // Use a stored procedure to check that sufficient stock is available for each item, allocate the stock for this order, or create a backorder if necessary
                        // The value returned from the stored procedure indicates how much of each item was allocated, the latest price (it might have changed since it was placed in the shopping cart), and whether a backorder was created for the item
                        var response = await Repository<Product>.ExecuteStoredProcAsync("CheckStockAvailable", item.Subcategory, item.ProductID, item.ProductName, item.NumberInCartOrOrdered, (Session["customer"] as Customer).CustomerID);
                        var responseData = JsonConvert.DeserializeAnonymousType(response, new { message = "", backorderid = "", allocated = 0, latestprice = 0.0M });

                        // Check for backordered items
                        if ((responseData as dynamic).backorderid != null)
                        {
                            backorderDetails.Add(item.ProductName, (responseData as dynamic).backorderid);
                            item.NumberOnBackorder = item.NumberInCartOrOrdered - (responseData as dynamic).allocated;
                            item.BackorderReference = (responseData as dynamic).backorderid;
                        }

                        // Update the order item with the most up to date cost of the item, and the number allocated
                        item.NumberInCartOrOrdered = (responseData as dynamic).allocated;
                        item.UnitCost = (responseData as dynamic).latestprice;
                        item.LineItemTotalCost = (responseData as dynamic).allocated * (responseData as dynamic).latestprice;
                    }

                    // Mark the order as a confirmed order
                    shoppingCart.IsShoppingCartOrOrder = Constants.ORDER;

                    // Save the order to the database
                    if (await Repository<ShoppingCartOrder>.UpsertItemAsync(shoppingCart, preTriggers: new List<string> { "CompleteOrderDetails" }))
                    {
                        StringBuilder message = new StringBuilder();
                        message.Append("Order placed.");
                        foreach (var backorder in backorderDetails)
                        {
                            message.Append($"\\nBackorder created for {backorder.Key}: Reference {backorder.Value}");
                        }
                        TempData["itemMessage"] = message.ToString();

                        // Add recommendations to the engine
                        await Recommendations.AddProductRelationships(shoppingCart);

                        // Remove the shopping cart from the Session cache as it is no longer required
                        Session.Remove("shoppingCart");
                    }
                    else
                    {
                        TempData["itemMessage"] = "Order not placed";
                    }

                }
                catch (DocumentClientException dce)
                {
                    // In the event of an exception, return to the ViewCart display and show the error message
                    Regex errMsgPattern = new Regex(@".*(?<error>Error:.*)\\r\\nStack.*");
                    Match errMsgMatch = errMsgPattern.Match(dce.Message);
                    if (errMsgMatch.Success)
                    {
                        TempData["itemMessage"] = errMsgMatch.Groups["error"].Value;
                    }
                    else
                    {
                        TempData["itemMessage"] = dce.Message;
                    }
                    return RedirectToAction("ViewCart", "ShoppingCart");
                }
            }
            else
            {
                // If the shopping cart was not found in cache, then something has gone wrong
                TempData["itemMessage"] = "Shopping cart not found. Please log in again";

                // Remove the customer data from the session. This will cause them to be prompted to log in again
                Session.Remove("customer");
            }

            // Go to the Orders page to display the details of the customer's orders
            return RedirectToAction("ViewOrders", "Orders");
        }
    }
}