﻿using Adventure_Works.Models;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Adventure_Works.Controllers
{
    public class CustomerController : Controller
    {
        // Method that simulates customer authentication and logs the customer in
        [ActionName("Login")]
        [HttpPost]
        public async Task<ActionResult> LoginAsync(string customerID, string password)
        {
            // Use the repository to retrieve the details of the specified customer
            var customer = (await Repository<Customer>.GetItemsAsync(c => c.CustomerID == customerID)).FirstOrDefault();

            // Validation and authentication using the password etc should go here. Only validation is implemented in this example, the user can enter anything in the password field!
            if (customer == null) // No such customer
            {
                TempData["invalidUserOrPassword"] = "Invalid username or password";
                return View();
            }

            // If authentication is successful (it always is in this example), cache the customer details in the session
            Session["customer"] = customer;

            // Retrieve the current shopping cart for the customer (if there is one)
            var shoppingCart = (await Repository<ShoppingCartOrder>.GetItemsAsync(c => c.CustomerID == customerID && c.IsShoppingCartOrOrder == Constants.SHOPPINGCART)).FirstOrDefault();
            Session["shoppingCart"] = shoppingCart;

            // Return to the action that triggered the login
            var redirectData = Session["ReturnData"] as dynamic;
            return RedirectToAction(redirectData.ReturnURL, redirectData.Controller);
        }

        // Method that logs the customer out
        [ActionName("Logout")]
        [HttpGet]
        public ActionResult Logout(string customerID, string password)
        {
            // Remove the customer's details from the Session cache - this will trigger a login the next time the customer tries to create or browse orders
            Session["customer"] = null;

            // Remove the other data for the customer as well
            Session["shoppingCart"] = null;
            Session["orders"] = null;
            Session["backorders"] = null;

            // Display the "logged out" page
            return View("Loggedout");
        }
    }
}