﻿namespace Adventure_Works
{
    using Gremlin.Net.Driver;
    using Adventure_Works.Models;
    using Gremlin.Net.Structure.IO.GraphSON;
    using System.Configuration;
    using System.Threading.Tasks;
    using System.Collections.Generic;
    using System;
    using System.Threading;
    using System.Linq;

    /// <summary>
    /// Impliment a graph supported recommendation engine
    /// </summary>
    public static class Recommendations
    {
        /// <summary>
        /// Gremlin client to connect to, and execute, queries against.
        /// </summary>
        private static GremlinClient gClient;

        /// <summary>
        /// Connect to server and setup client connection
        /// </summary>
        /// <param name="collection">An application might want to have more than one graph, defaults to recommendations</param>
        public static void Initialize(string collection="recommendations")
        {
            var gremlinServer = new GremlinServer(
                hostname: ConfigurationManager.AppSettings["GremlinEndpoint"],
                port: 443,
                enableSsl: true,
                username: "/dbs/" + ConfigurationManager.AppSettings["Database"] + "/colls/" + collection,
                password: ConfigurationManager.AppSettings["GremlinKey"]);

            gClient = new GremlinClient(gremlinServer, new GraphSON2Reader(), new GraphSON2Writer(), GremlinClient.GraphSON2MimeType);
        }

        // Ensure a unique seed on each call for a random number
        public static class ThreadSafeRandom
        {
            [ThreadStatic] private static Random Local;

            public static Random ThisThreadsRandom
            {
                get { return Local ?? (Local = new Random(unchecked(Environment.TickCount * 31 + Thread.CurrentThread.ManagedThreadId))); }
            }
        }

        /// <summary>
        /// Impliments Durstenfields shuffle algorithm.
        /// </summary>
        /// <param name="list">An array of strings to randomize.</param>
        private static void Shuffle(string[] list)
        {
            int n = list.Count();
            while (n > 1)
            {
                n--;
                int k = ThreadSafeRandom.ThisThreadsRandom.Next(n + 1);
                string value = list[k];
                list[k] = list[n]; //swap values
                list[n] = value;
            }
        }

        /// <summary>
        /// Ask Gremlin to go get some recommendations.
        /// </summary>
        /// <param name="recProductID">ProductID to ask Gremlin for recommendations for.</param>
        /// <param name="depth">How far down into the graph should we look, defaults to a depth of 3.</param>
        /// <param name="numberReccomendation">How many products should be recommended, defaults to 5.</param>
        /// <returns>A list of recommended products.</returns>
        public static async Task<List<Product>> GetReccomendationsAsync(string recProductID, int depth=3, int numberReccomendations=5)
        {
            // Ask Gremlin to go get the list of product ids to recommend (default to a depth of 3)
            string query = $"g.V('{recProductID}').as('bought').repeat(out()).times({depth}).where(neq('bought')).dedup().values('id')";
       
            var response = await gClient.SubmitAsync<object>(query);
            List<Product> results = new List<Product>();

            // If there are recommendations, randomize them and return the required number
            if (response.Count > 0)
            { 
                string[] productIDs = response.Cast<string>().ToArray(); // Cast Gremlin results as an array of strings
                Shuffle(productIDs);

                // Loop through the recommended randomised product ids
                for (int i=0; i < numberReccomendations && i < productIDs.Count(); i++)
                {
                    // Go get the full product document from Cosmos DB
                    var products = await Repository<Product>.GetItemsAsync(p => p.ProductID == productIDs[i]);
                    results.Add(products.FirstOrDefault());
                }
            }

            // The list of products to show on the product page
            return results;
        }

        /// <summary>
        /// When a shopping cart is checked out, add all the items to our recommendation graph with links between all the products.
        /// </summary>
        /// <param name="basket">The completed shopping order to add to the graph.</param>
        /// <returns>Nothing</returns>
        public static async Task AddProductRelationships(ShoppingCartOrder basket)
        {
            string query = "";

            // For each item in the shopping basket add relationships in the graph
            foreach (OrderItem p in basket.OrderItems)
            {
                // gremlin upserty command - check if the vertices exists, if not add it
                query = $"g.V().has('product', 'id', '{p.ProductID}').fold().coalesce(unfold(),addV('product').property('id', '{p.ProductID}')).property('name','{p.ProductName}')";
                
                // Need to loop through all other items in the basket to add links
                foreach (OrderItem link in basket.OrderItems)
                {
                    if (p.ProductID != link.ProductID)
                    {
                        // Customers who bought this also bought this
                        query += $".addE('bought').property('customerID','{basket.CustomerID}').to(g.V().has('product', 'id', '{link.ProductID}').fold().coalesce(unfold(),addV('product').property('id', '{link.ProductID}')).property('name','{link.ProductName}')).outV()";
                    }
                }

                //execute a single gremlin query to update the graph
                await gClient.SubmitAsync(query);
            }
        }
    }
}