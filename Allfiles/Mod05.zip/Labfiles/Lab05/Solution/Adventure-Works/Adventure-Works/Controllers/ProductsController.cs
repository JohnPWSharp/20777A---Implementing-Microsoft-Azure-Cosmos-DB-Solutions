﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Adventure_Works.Models;
using System.Threading.Tasks;


namespace Adventure_Works.Controllers
{
    public class ProductsController : Controller
    { 
        #region helper methods for retrieving and caching product category and subcategory data
        private async Task<IEnumerable<ProductCategoryData>> InitializeCategoryDataAsync()
        {
            // Retrieve the list of categories and subcategories from the document database
            var categoryData = await Repository<ProductCategoryData>.GetAllItemsAsync();
            Session["categoryData"] = categoryData;
            return categoryData;
        }

        private async Task<ProductCategoryViewModel> InitializeCategoriesAsync()
        {
            // Construct the ProductCategoryViewModel data using the data retrieved from the document database 
            var categoryData = Session["categoryData"] as IEnumerable<ProductCategoryData> ?? await Repository<ProductCategoryData>.GetAllItemsAsync();
            var distinctCategories = (from c in categoryData select c.Category).Distinct();
            var selectableCategories = new ProductCategoryViewModel { Categories = from c in distinctCategories select new SelectListItem { Text = c, Value = c } };
            Session["selectableCategories"] = selectableCategories;
            return selectableCategories;
        }

        private async Task<ProductSubcategoryViewModel> InitializeSubCategoriesAsync()
        {
            // Construct the ProductSubcategoryViewModel data using the data retrieved from the document database
            var categoryData = Session["categoryData"] as IEnumerable<ProductCategoryData> ?? await Repository<ProductCategoryData>.GetAllItemsAsync();
            var subcategoryData = (from c in categoryData select c.Subcategory);
            var selectableSubcategories = new ProductSubcategoryViewModel { Subcategories = from s in subcategoryData select new SelectListItem { Text = s, Value = s } };
            Session["selectableSubcategories"] = selectableSubcategories;
            return selectableSubcategories;
        }
        #endregion

        // Initial, default action for the form
        [ActionName("FindProducts")]
        [HttpGet]
        public async Task<ActionResult> FindProductsAsync()
        {
            // Build and display an initial view model containing just the list of categories and subcategories (don't display all products by default as there could be a lot of them)
            return View(new ProductViewModel
            {
                Products = new List<Product>(),
                SelectableCategories = Session["selectableCategories"] as ProductCategoryViewModel ?? await InitializeCategoriesAsync(),
                SelectableSubcategories = Session["selectableSubcategories"] as ProductSubcategoryViewModel ?? await InitializeSubCategoriesAsync()
            });
        }

        // Method called as POST request from the various search buttons on the form
        [ActionName("FindProducts")]
        [HttpPost]
        public async Task<ActionResult> FindProductsAsync(ProductViewModel productViewModel)
        {
            // Construct a view model that matches the search criteria specified by the user

            IEnumerable<Product> products = null;

            if (productViewModel.SelectableCategories != null)
            {
                // User is searching by category
                products = await Repository<Product>.GetItemsAsync(p => p.Category == productViewModel.SelectableCategories.CategoryName);
            }
            else if (productViewModel.SelectableSubcategories != null)
            {
                // User is searching by subcategory
                products = await Repository<Product>.GetItemsAsync(p => p.Subcategory == productViewModel.SelectableSubcategories.SubcategoryName);
            }
            else
            {
                // User is searching by product name, model name, or product number
                products = await Repository<Product>.GetItemsAsync(p =>
                    p.ProductName.Contains(productViewModel.SearchString) ||
                    p.Model.Contains(productViewModel.SearchString) ||
                    p.ProductNumber.Contains(productViewModel.SearchString));
            }

            // Construct a new view model containing the results and display it
            return View(new ProductViewModel
            {
                Products = products,
                SelectableCategories = Session["selectableCategories"] as ProductCategoryViewModel ?? await InitializeCategoriesAsync(),
                SelectableSubcategories = Session["selectableSubcategories"] as ProductSubcategoryViewModel ?? await InitializeSubCategoriesAsync()
            });
        }

        // Method called to display the details of the specified product
        [ActionName("GetProductDetails")]
        [HttpGet]
        public async Task<ActionResult> GetProductDetailsAsync(string productID)
        {
            // Find the data for the specified product
            var products = await Repository<Product>.GetItemsAsync(p => p.ProductID == productID);

            // Go get the products to recommend
            var recommendedProducts = await Recommendations.GetReccomendationsAsync(productID);

            products.First().Recommendations = recommendedProducts;

            // Display the details of the product
            return View(products.First());
        }        
    }
}