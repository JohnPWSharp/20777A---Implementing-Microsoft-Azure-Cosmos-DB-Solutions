﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace MigrateProductData
{
    class Program
    {
        static void Main(string[] args)
        {
            DataLoader dataLoader = new DataLoader();
            dataLoader.DoLoad().Wait();
        }
    }

    internal class DataLoader
    {
        private DocumentClient client;
        private string endpointUrl;
        private string primaryKey;
        private string database;
        private string collection;
        private string sqlConnectionString;
        private string blobStorageConnectionString;
        private CloudBlobClient blobClient;
        private string blobContainer;

        internal async Task DoLoad()
        {
            // Retrieve the configuration settings
            this.endpointUrl = ConfigurationManager.AppSettings["EndpointUrl"];
            this.primaryKey = ConfigurationManager.AppSettings["PrimaryKey"];
            this.database = ConfigurationManager.AppSettings["Database"];
            this.collection = ConfigurationManager.AppSettings["Collection"];
            this.sqlConnectionString = ConfigurationManager.AppSettings["SQLConnectionString"];
            this.blobStorageConnectionString = ConfigurationManager.AppSettings["BlobStorageConnectionString"];
            this.blobContainer = ConfigurationManager.AppSettings["BlobContainer"];

            // Create a client to connect to the Cosmos DB database
            this.client = new DocumentClient(new Uri(endpointUrl), primaryKey);

            // Delete and recreate collection
            await this.client.CreateDatabaseIfNotExistsAsync(new Database { Id = database });
            try
            {
                await client.DeleteDocumentCollectionAsync(
                    UriFactory.CreateDocumentCollectionUri(database, collection));
            }
            catch (DocumentClientException e)
            {
                if (e.StatusCode != HttpStatusCode.NotFound)
                    throw;
            }

            var sales = await client.CreateDocumentCollectionIfNotExistsAsync(
                UriFactory.CreateDatabaseUri(database),
                new DocumentCollection { Id = collection },
                new RequestOptions { OfferThroughput = 400, PartitionKey = new PartitionKey("/subcategory") });

            // Connect to Azure Blob Storage
            if (!CloudStorageAccount.TryParse(this.blobStorageConnectionString, out CloudStorageAccount storageAccount))
            {
                Console.WriteLine("Invalid storage connection string");
                return;
            }
            this.blobClient = storageAccount.CreateCloudBlobClient();

            // Get the data to use to create the product documents
            var reader = GetData();

            Console.WriteLine("Starting import");
            var s = new Stopwatch();
            s.Start();

            // Iterate through the rows retrieved and create a document for each row
            while (reader.Read())
            {
                var productDocument = new Product
                {
                    ProductID = reader["ProductID"].ToString(),
                    ProductName = reader["Name"].ToString(),
                    ProductNumber = reader["ProductNumber"].ToString(),
                    Color = reader["Color"].ToString(),
                    ListPrice = Decimal.Parse(reader["ListPrice"].ToString()),
                    Size = $"{reader["Size"].ToString()} {reader["SizeUnit"].ToString()}",
                    Weight = $"{reader["Weight"].ToString()} {reader["WeightUnit"].ToString()}",                    
                    QuantityInStock = Int32.Parse(reader["Quantity"].ToString() == "" ? "0" : reader["Quantity"].ToString()),
                    Model = reader["ModelName"].ToString(),
                    Description = reader["Description"].ToString(),
                    ProductCategory = new ProductCategoryData
                    {
                        Subcategory = reader["SubcategoryName"].ToString(),
                        Category = reader["CategoryName"].ToString(),
                    },
                    Documentation = new ProductDocumentData
                    {
                        DocumentTitle = reader["Title"].ToString(),
                        DocumentSummary = reader["DocumentSummary"].ToString(),
                        Document = await UploadDataToBlobStorageAsync(reader["Document"], reader["DocumentFileName"].ToString())
                    },
                    Images = new ProductImageData
                    {
                        Diagram = await UploadDataToBlobStorageAsync(reader["Diagram"], reader["ModelName"].ToString()),
                        Thumbnail = await UploadDataToBlobStorageAsync(reader["ThumbnailPhoto"], reader["ThumbnailPhotoFileName"].ToString()),
                        LargePhoto = await UploadDataToBlobStorageAsync(reader["LargePhoto"], reader["LargePhotoFileName"].ToString())
                    }
                };

                // Upload the document to the collection in Cosmos DB
                if (await UploadDocumentToCosmosDB(productDocument))
                {
                    //Console.WriteLine($"Added document {productDocument.ProductID} for {productDocument.ProductName}: {productDocument.Description}");
                }
                else
                {
                    Console.WriteLine($"Upload failed for {productDocument.ProductID}: {productDocument.ProductName}");
                }
            }
            reader.Close();

            Console.WriteLine($"Documents created in: {s.ElapsedMilliseconds}ms");
            Console.ReadKey();
        }

        // Create a data reader to retrieve the product data from SQL Server
        private IDataReader GetData()
        {
            // Query that fetches the data for each product from the various tables in SQL Server
            string query = @"SELECT p.ProductID, p.Name, p.ProductNumber, p.Color, p.ListPrice, p.Size, pum.Name As SizeUnit, 
                                    p.Weight, pw.Name As WeightUnit, psc.Name As SubcategoryName, pc.Name As CategoryName, i.Quantity, 
									d.Title, d.DocumentSummary, d.Document, d.FileName AS DocumentFileName, pm.Name AS ModelName, ill.Diagram, 
									ph.ThumbnailPhoto, ph.ThumbnailPhotoFileName, ph.LargePhoto, ph.LargePhotoFileName, pds.Description
                             FROM Production.Product p
							 LEFT JOIN Production.ProductSubcategory psc
							 ON p.ProductSubCategoryID = psc.ProductSubcategoryID
							 LEFT JOIN Production.ProductCategory pc
							 ON psc.ProductCategoryID = pc.ProductCategoryID
                             LEFT JOIN(SELECT ProductID, SUM(Quantity) AS Quantity FROM Production.ProductInventory GROUP BY ProductID) AS i
                             ON p.ProductID = i.ProductID
							 LEFT JOIN Production.UnitMeasure pum
							 ON p.SizeUnitMeasureCode = pum.UnitMeasureCode
                             LEFT JOIN Production.UnitMeasure pw
							 ON p.WeightUnitMeasureCode = pw.UnitMeasureCode
							 LEFT JOIN  Production.ProductDocument pd
                             ON p.ProductID = pd.ProductID
                             LEFT JOIN Production.Document d
                             ON pd.DocumentNode = d.DocumentNode
                             LEFT JOIN Production.ProductModel pm
                             ON p.ProductModelID = pm.ProductModelID
                             LEFT JOIN Production.ProductModelIllustration pmi
                             ON pm.ProductModelID = pmi.ProductModelID
                             LEFT JOIN Production.Illustration ill
                             ON pmi.IllustrationID = ill.IllustrationID
                             LEFT JOIN Production.ProductProductPhoto ppp
                             ON P.ProductID = ppp.ProductID
                             LEFT JOIN Production.ProductPhoto ph
                             ON ppp.ProductPhotoID = ph.ProductPhotoID
                             LEFT JOIN Production.ProductModelProductDescriptionCulture pmdc
                             ON pm.ProductModelID = pmdc.ProductModelID AND pmdc.CultureID = 'en'
                             LEFT JOIN Production.ProductDescription pds
                             ON pmdc.ProductDescriptionID = pds.ProductDescriptionID";
            try
            {
                SqlConnection connection = new SqlConnection(sqlConnectionString);
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader = command.ExecuteReader();
                return reader;
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        // Upload the blob (image or document) to Azure blob storage, and return the URL 
        internal async Task<string> UploadDataToBlobStorageAsync(object data, string name)
        {
            // If the data is NULL, return an empty string  
            if (string.Compare(data.GetType().Name, "DBNull") == 0)
            {
                return string.Empty;
            }

            // Otherwise cast the data into a byte array
            var byteData = data as byte[];

            // If the cast failed, the data probably contains a string, so use GetBytes to convert it into a byte array
            if (byteData == null)
            {
                byteData = Encoding.ASCII.GetBytes(data.ToString());
            }

            // Get a reference to the blob containerin Azure storage
            var cloudBlobContainer = this.blobClient.GetContainerReference(this.blobContainer);

            // Create a reference to a new blob in this container. The blob will hold the data being uploaded
            var blockBlob = cloudBlobContainer.GetBlockBlobReference(name);

            // Upload the data to the blob
            await blockBlob.UploadFromByteArrayAsync(byteData, 0, byteData.Length);

            // Return the URI of the new blob as a string
            return blockBlob.Uri.ToString();
        }

        // Upload the specified document to Cosmos DB and return an indication of whether the upload was successful
        internal async Task<bool> UploadDocumentToCosmosDB(Product productDocument)
        {
            try
            {
                Uri productCollection = UriFactory.CreateDocumentCollectionUri(this.database, this.collection);
                var response = await this.client.CreateDocumentAsync(productCollection, productDocument);
                return (response.StatusCode == HttpStatusCode.Created);
            }
            catch (DocumentClientException dce)
            {

                return false;
            }
        }        
    }
}
