﻿using Newtonsoft.Json;

namespace MigrateProductData
{
    internal class ProductCategoryData
    {
        [JsonProperty("subcategory")]
        internal string Subcategory { get; set; }

        [JsonProperty("category")]
        internal string Category { get; set; }
    }

    internal class ProductDocumentData
    {
        [JsonProperty("documenttitle")]
        internal string DocumentTitle { get; set; }

        [JsonProperty("documentsummary")]
        internal string DocumentSummary { get; set; }

        [JsonProperty("document")]
        internal string Document { get; set; }
    }

    internal class ProductImageData
    {
        [JsonProperty("diagram")]
        internal string Diagram { get; set;  }

        [JsonProperty("thumbnail")]
        internal string Thumbnail { get; set; }

        [JsonProperty("largephoto")]
        internal string LargePhoto { get; set; }
    }

    internal class Product
    {
        [JsonProperty("id")]
        internal string ProductID { get; set; }

        [JsonProperty("productname")]
        internal string ProductName { get; set; }

        [JsonProperty("productnumber")]
        internal string ProductNumber { get; set; }

        [JsonProperty("color")]
        internal string Color { get; set; }

        [JsonProperty("listprice")]
        public decimal ListPrice { get; set; }

        [JsonProperty("size")]
        internal string Size { get; set; }

        [JsonProperty("weight")]
        internal string Weight { get; set; }

        [JsonProperty("quantityinstock")]
        internal int QuantityInStock { get; set; }

        [JsonProperty("model")]
        internal string Model { get; set; }

        [JsonProperty("description")]
        internal string Description { get; set; }

        [JsonProperty("productcategory")]
        internal ProductCategoryData ProductCategory { get; set; }

        [JsonProperty("documentation")]
        internal ProductDocumentData Documentation { get; set; }

        [JsonProperty("images")]
        internal ProductImageData Images { get; set; }
    }
}
