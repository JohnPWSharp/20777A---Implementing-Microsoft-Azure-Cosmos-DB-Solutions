﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace MigrateProductData
{
    class Program
    {
        static void Main(string[] args)
        {
            DataLoader dataLoader = new DataLoader();
            dataLoader.DoLoad().Wait();
        }
    }

    internal class DataLoader
    {
        private string sqlConnectionString;
        private string blobStorageConnectionString;
        private CloudBlobClient blobClient;
        private string blobContainer;

        internal async Task DoLoad()
        {
            // Retrieve the configuration settings
            this.sqlConnectionString = ConfigurationManager.AppSettings["SQLConnectionString"];
            this.blobStorageConnectionString = ConfigurationManager.AppSettings["BlobStorageConnectionString"];
            this.blobContainer = ConfigurationManager.AppSettings["BlobContainer"];

            // Connect to Azure Blob Storage
            if (!CloudStorageAccount.TryParse(this.blobStorageConnectionString, out CloudStorageAccount storageAccount))
            {
                Console.WriteLine("Invalid storage connection string");
                return;
            }
            this.blobClient = storageAccount.CreateCloudBlobClient();

            // Get the data to use to create the product documents
            var reader = GetData();

            Console.WriteLine("Starting import");
            var s = new Stopwatch();
            s.Start();

            // Iterate through the rows retrieved and create a document for each row
            while (reader.Read())
            {
                await UploadDataToBlobStorageAsync(reader["Document"], reader["DocumentFileName"].ToString());
                await UploadDataToBlobStorageAsync(reader["Diagram"], reader["ModelName"].ToString());
                await UploadDataToBlobStorageAsync(reader["ThumbnailPhoto"], reader["ThumbnailPhotoFileName"].ToString());
                await UploadDataToBlobStorageAsync(reader["LargePhoto"], reader["LargePhotoFileName"].ToString());
            }
            reader.Close();

            Console.WriteLine($"Blobs uploaded: {s.ElapsedMilliseconds}ms");
            Console.WriteLine($"Blob upload completed, press any key to close.");
            Console.ReadKey();
        }

        // Create a data reader to retrieve the product data from SQL Server
        private IDataReader GetData()
        {
            // Query that fetches the data for each product from the various tables in SQL Server
            string query = @"SELECT p.ProductID, p.Name, p.ProductNumber, p.Color, p.ListPrice, p.Size, pum.Name As SizeUnit, 
                                    p.Weight, pw.Name As WeightUnit, psc.Name As SubcategoryName, pc.Name As CategoryName, i.Quantity, 
									d.Title, d.DocumentSummary, d.Document, d.FileName AS DocumentFileName, pm.Name AS ModelName, ill.Diagram, 
									ph.ThumbnailPhoto, ph.ThumbnailPhotoFileName, ph.LargePhoto, ph.LargePhotoFileName, pds.Description
                             FROM Production.Product p
							 LEFT JOIN Production.ProductSubcategory psc
							 ON p.ProductSubCategoryID = psc.ProductSubcategoryID
							 LEFT JOIN Production.ProductCategory pc
							 ON psc.ProductCategoryID = pc.ProductCategoryID
                             LEFT JOIN(SELECT ProductID, SUM(Quantity) AS Quantity FROM Production.ProductInventory GROUP BY ProductID) AS i
                             ON p.ProductID = i.ProductID
							 LEFT JOIN Production.UnitMeasure pum
							 ON p.SizeUnitMeasureCode = pum.UnitMeasureCode
                             LEFT JOIN Production.UnitMeasure pw
							 ON p.WeightUnitMeasureCode = pw.UnitMeasureCode
							 LEFT JOIN  Production.ProductDocument pd
                             ON p.ProductID = pd.ProductID
                             LEFT JOIN Production.Document d
                             ON pd.DocumentNode = d.DocumentNode
                             LEFT JOIN Production.ProductModel pm
                             ON p.ProductModelID = pm.ProductModelID
                             LEFT JOIN Production.ProductModelIllustration pmi
                             ON pm.ProductModelID = pmi.ProductModelID
                             LEFT JOIN Production.Illustration ill
                             ON pmi.IllustrationID = ill.IllustrationID
                             LEFT JOIN Production.ProductProductPhoto ppp
                             ON P.ProductID = ppp.ProductID
                             LEFT JOIN Production.ProductPhoto ph
                             ON ppp.ProductPhotoID = ph.ProductPhotoID
                             LEFT JOIN Production.ProductModelProductDescriptionCulture pmdc
                             ON pm.ProductModelID = pmdc.ProductModelID AND pmdc.CultureID = 'en'
                             LEFT JOIN Production.ProductDescription pds
                             ON pmdc.ProductDescriptionID = pds.ProductDescriptionID";
            try
            {
                SqlConnection connection = new SqlConnection(sqlConnectionString);
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader = command.ExecuteReader();
                return reader;
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        // Upload the blob (image or document) to Azure blob storage, and return the URL 
        internal async Task<string> UploadDataToBlobStorageAsync(object data, string name)
        {
            // If the data is NULL, return an empty string  
            if (string.Compare(data.GetType().Name, "DBNull") == 0)
            {
                return string.Empty;
            }

            // Otherwise cast the data into a byte array
            var byteData = data as byte[];

            // If the cast failed, the data probably contains a string, so use GetBytes to convert it into a byte array
            if (byteData == null)
            {
                byteData = Encoding.ASCII.GetBytes(data.ToString());
            }

            // Get a reference to the blob containerin Azure storage
            var cloudBlobContainer = this.blobClient.GetContainerReference(this.blobContainer);

            // Create a reference to a new blob in this container. The blob will hold the data being uploaded
            var blockBlob = cloudBlobContainer.GetBlockBlobReference(name);

            // Upload the data to the blob
            await blockBlob.UploadFromByteArrayAsync(byteData, 0, byteData.Length);

            // Return the URI of the new blob as a string
            return blockBlob.Uri.ToString();
        }      
    }
}
