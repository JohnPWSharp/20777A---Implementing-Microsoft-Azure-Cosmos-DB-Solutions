﻿namespace Adventure_Works
{
    using Gremlin.Net.Driver;
    using Adventure_Works.Models;
    using Gremlin.Net.Structure.IO.GraphSON;
    using System.Configuration;
    using System.Threading.Tasks;
    using System.Collections.Generic;
    using System;
    using System.Threading;
    using System.Linq;

    /// <summary>
    /// Impliment a graph supported recommendation engine
    /// </summary>
    public static class Recommendations
    {
        /// <summary>
        /// Gremlin client to connect to, and execute, queries against.
        /// </summary>
        private static GremlinClient gClient;

        /// <summary>
        /// Connect to server and setup client connection
        /// </summary>
        /// <param name="collection">An application might want to have more than one graph, defaults to recommendations</param>
        public static void Initialize(string collection="recommendations")
        {
            var gremlinServer = new GremlinServer(
                hostname: ConfigurationManager.AppSettings["GremlinEndpoint"],
                port: 443,
                enableSsl: true,
                username: "/dbs/" + ConfigurationManager.AppSettings["Database"] + "/colls/" + collection,
                password: ConfigurationManager.AppSettings["GremlinKey"]);

            gClient = new GremlinClient(gremlinServer, new GraphSON2Reader(), new GraphSON2Writer(), GremlinClient.GraphSON2MimeType);
        }

        #region helper methods to shuffle an array

        // Ensure a unique seed on each call for a random number
        public static class ThreadSafeRandom
        {
            [ThreadStatic] private static Random Local;

            public static Random ThisThreadsRandom
            {
                get { return Local ?? (Local = new Random(unchecked(Environment.TickCount * 31 + Thread.CurrentThread.ManagedThreadId))); }
            }
        }

        /// <summary>
        /// Impliments Durstenfields shuffle algorithm.
        /// </summary>
        /// <param name="list">An array of strings to randomize.</param>
        private static void Shuffle(string[] list)
        {
            int n = list.Count();
            while (n > 1)
            {
                n--;
                int k = ThreadSafeRandom.ThisThreadsRandom.Next(n + 1);
                string value = list[k];
                list[k] = list[n]; //swap values
                list[n] = value;
            }
        }

        #endregion

        /// <summary>
        /// Ask Gremlin to go get some recommendations.
        /// </summary>
        /// <param name="recProductID">ProductID to ask Gremlin for recommendations for.</param>
        /// <param name="depth">How far down into the graph should we look, defaults to a depth of 3.</param>
        /// <param name="numberReccomendation">How many products should be recommended, defaults to 5.</param>
        /// <returns>A list of recommended products.</returns>
        public static async Task<List<Product>> GetReccomendationsAsync(string recProductID, int depth=3, int numberReccomendations=5)
        {
            // TODO: Ask Gremlin to go get the list of product ids to recommend (default to a depth of 3)

            List<Product> results = new List<Product>();

            // TODO: If there are recommendations, randomize them and return the required number


            // The list of products to show on the product page
            return results;
        }

        /// <summary>
        /// When a shopping cart is checked out, add all the items to our recommendation graph with links between all the products.
        /// </summary>
        /// <param name="basket">The completed shopping order to add to the graph.</param>
        /// <returns>Nothing</returns>
        public static async Task AddProductRelationships(ShoppingCartOrder basket)
        {
            string query = "";

            // For each item in the shopping basket add relationships in the graph
            foreach (OrderItem p in basket.OrderItems)
            {
                // TODO: gremlin upsert command - check if the vertices exists, if not add it


                // TODO: Need to loop through all other items in the basket to add edges


                //execute a single gremlin query to update the graph
                await gClient.SubmitAsync(query);
            }
        }
    }
}